# Carbonation-strength benchmark: reproducibility package

This is the public numerical and code package for version `v1.2.0` of the carbonation-cured-concrete provenance and transportability audit. It has no DOI. Version 1.2.0 corrects the pressure-audit classification of two already-retained ambient-pressure records. It changes the primary cohort from 39 to 41 records, from four to five source reports, and the 28-day descriptive subset from five to seven records. No training input, model configuration, seed, fitted estimator, or stored prediction is changed.

The archive preserves numerical outputs, code, figures, and source locations needed to verify reported calculations. It does not redistribute the publisher spreadsheet, article full text, or quoted passages from source literature. `C1_PUBLIC_PRESSURE_CORRECTION_20260929.md` records the public correction scope, and the release-root provenance record maps each updated file to its reviewed local source.

## Verification and execution

The supplied numerical results can be checked without fitting models:

    python _shared/revision_20260921/C1/verify_reproduction_outputs.py
    python _shared/revision_20260921/C1/schema_alignment_sensitivity.py

The verifier recomputes the reported metrics from retained per-row seed predictions. It does not refit a model, access the web, or require omitted source materials. A successful run prints `passed: true`.

The retained Figures 1–3 can be regenerated from included numerical results:

    python C1_crossdb_audit/manuscript/make_figures.py --internal-only

Corrected DCE figures are included at `_shared/revision_20260921/C1/figures/`: `Fig1.*`, `Figure4_revised.*`, and `Figure5_decision_v13.*`. Their public rendering scripts are included beside those assets.

The current density-sensitivity record is versioned `v2`: `density_sensitivity.py` and the three `density_sensitivity_v2_*` outputs. The unversioned density outputs from the earlier 39-record primary cohort are intentionally excluded. The included v2 outputs use the corrected 41-record cohort; regenerating them requires the omitted publisher spreadsheet.

To refit, obtain the omitted 198-row publisher spreadsheet from its cited provider under the applicable terms and place it at the documented path. Use the recorded package versions in `requirements-frozen.txt`. TabPFN also requires its normal model weights; no credentials or downloaded weights are redistributed here.

## Public-release redactions and third-party material

The package omits literature-text quotation fields, including `evidence`, `pressure_excerpt`, `column_decoding_evidence`, and `source_evidence`. It retains numeric values, row identifiers, DOIs, source locations, cohort flags, scripts, and concise author-derived notes. The UCI Concrete Compressive Strength CSV is retained solely for transfer pretraining; see `THIRD_PARTY_NOTICES.md`. No new license is granted by this package.
