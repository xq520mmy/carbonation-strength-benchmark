#!/usr/bin/env python3
"""Render revised C1 Figures 4-5 from the pressure-audited seed rerun."""
from pathlib import Path
import json
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
P=HERE/'rerun_primary_explicit_pressure.json'
j=json.loads(P.read_text())
rows=j['selected_rec_ids']
pred=np.asarray(j['runs']['ET300 raw rescaled (recommended)']['pred_mean'])
# External rows are reconstructed from the frozen AB result in the same order.
old=json.loads((HERE.parents[2]/'C1_crossdb_audit/external_validation/results/extval_tierAB.json').read_text())['external_rows']
d=pd.DataFrame([r for r in old if str(r['rec_id']) in set(rows)])
d=d.set_index(d.rec_id.astype(str)).loc[rows].reset_index(drop=True)
y=d.CS.astype(float).to_numpy(); labs=d.lab_id.astype(str).to_numpy()

fig,ax=plt.subplots(1,2,figsize=(11,4.4),constrained_layout=True)
for lab in sorted(set(labs)):
    m=labs==lab; ax[0].scatter(y[m],pred[m],s=42,label=lab,alpha=.85)
lo=min(y.min(),pred.min())-1; hi=max(y.max(),pred.max())+1
ax[0].plot([lo,hi],[lo,hi],'k--',lw=1,label='equality'); ax[0].set(xlim=(lo,hi),ylim=(lo,hi),xlabel='Measured compressive strength (MPa)',ylabel='Predicted compressive strength (MPa)',title='(a) Pressure-audited primary cohort (n=41)')
ax[0].legend(fontsize=7,loc='upper left',frameon=False)
cols=['C','CA','FA','W','blast furnace slag','fly ash','W/B','CCU-steam curing time','T','CC','P']
labels=['C','CA','FA','W','slag','ash','W/B','steam','time','CO₂','P']
project=HERE.parents[2]/'C1_crossdb_audit'
import sys; sys.path.insert(0,str(project/'model_experiments'))
import common as C
train=C._df[cols]; count=[]
for c in cols:
    x=d[c].astype(float); count.append(int(((x<train[c].min())|(x>train[c].max())).sum()))
ax[1].bar(range(len(cols)),count,color='#4477aa'); ax[1].set_xticks(range(len(cols)),labels,rotation=45,ha='right'); ax[1].set_ylabel('Rows outside stored-input range'); ax[1].set_title('(b) Stored-input range departures, primary cohort')
fig.savefig(HERE/'figures'/'Figure4_revised.png',dpi=300)
fig.savefig(HERE/'figures'/'Figure4_revised.pdf')
plt.close(fig)

scores=[.957,.825,.347,j['runs']['ET300 raw rescaled (recommended)']['all']['r2']['mean'],json.loads((HERE/'rerun_strict_numeric_point.json').read_text())['runs']['ET300 raw rescaled (recommended)']['all']['r2']['mean']]
labels=['Random\n5-fold','LOSO','Internal\nstrict','Mixed-age\nprimary (41)','Mixed-age\nstrict P (24)','Legacy A\n(73)','Legacy A+B\n(106)']
legacy=json.loads((HERE/'rerun_legacy_A_complete.json').read_text())['runs']['ET300 raw rescaled (recommended)']['all']['r2']['mean']
allc=json.loads((HERE/'rerun_legacy_all_complete.json').read_text())['runs']['ET300 raw rescaled (recommended)']['all']['r2']['mean']
fig,ax=plt.subplots(figsize=(10.2,4.5),constrained_layout=True)
x=np.arange(7)
ax.scatter(x[:3],scores[:3],s=58,color='#4477aa',label='Internal protocols')
ax.scatter(x[3:5],scores[3:],marker='D',s=58,color='#228833',label='Mixed-age external stress tests')
ax.scatter(x[5:],[legacy,allc],marker='s',s=58,color='#999999',label='Legacy cohort sensitivities')
ax.axvline(2.5,color='.7',lw=.8,ls=':');ax.axvline(4.5,color='.7',lw=.8,ls=':')
ax.axhline(0,color='.4',lw=.8); ax.axhline(.65,color='#cc6677',ls='--',lw=1,label='Working external criterion')
ax.set(xticks=x,xticklabels=labels,ylabel='R², ExtraTrees raw-rescaled',title='Figure 5. Evaluation and pressure-evidence sensitivity')
ax.legend(frameon=False,fontsize=8,loc='lower left'); ax.set_ylim(-1.12,1.05)
fig.savefig(HERE/'figures'/'Figure5_revised.png',dpi=300)
fig.savefig(HERE/'figures'/'Figure5_revised.pdf')
