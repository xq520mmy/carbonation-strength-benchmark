#!/usr/bin/env python3
"""Combine C1's evidence-flow map with the existing Figure 1 result scatter."""
from pathlib import Path

import matplotlib.image as mpimg
import matplotlib.patches as patches
import matplotlib.pyplot as plt


HERE = Path(__file__).resolve().parent
INPUT = HERE / "Fig1_original.png"


def box(ax, x, y, w, h, title, lines, color):
    rect = patches.FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.012,rounding_size=0.02",
        linewidth=1.0, edgecolor=color, facecolor="#ffffff"
    )
    ax.add_patch(rect)
    ax.text(x + w / 2, y + h - 0.045, title, ha="center", va="top",
            fontsize=9.3, fontweight="bold", color=color)
    ax.text(x + w / 2, y + h / 2 - 0.02, "\n".join(lines), ha="center", va="center",
            fontsize=8.2, linespacing=1.25)


def arrow(ax, x1, y1, x2, y2, color="#5d6d7e"):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="->", lw=1.2, color=color,
                                shrinkA=2, shrinkB=2))


fig = plt.figure(figsize=(10.8, 11.0), constrained_layout=True)
gs = fig.add_gridspec(2, 1, height_ratios=[1.0, 1.55])
ax = fig.add_subplot(gs[0])
ax.set_axis_off()
ax.set(xlim=(0, 1), ylim=(0, 1))

ax.text(0.01, 0.985, "(a) Evidence flow and evaluable cohorts", fontsize=11,
        fontweight="bold", va="top")
box(ax, 0.03, 0.53, 0.22, 0.30, "Shared benchmark", [
    "198 rows", "84 distinct input vectors", "105 confirmed or probable", "source matches; 93 untraced"
], "#2d6ea3")
box(ax, 0.39, 0.53, 0.22, 0.30, "Grouped internal evaluation", [
    "3 quantitative source blocks", "143 held-out rows", "fixed ExtraTrees vs", "random-forest baseline"
], "#2d6ea3")
box(ax, 0.75, 0.53, 0.22, 0.30, "External audit", [
    "258 extracted records", "41 publications", "152 lack defensible", "kg/m³ conversion"
], "#228833")
box(ax, 0.37, 0.09, 0.25, 0.27, "Primary stress test", [
    "41 records; 4 source clusters", "numerical pressure or", "explicit ambient condition", "7 records at 28 days"
], "#228833")
box(ax, 0.70, 0.09, 0.25, 0.27, "Strict-pressure sensitivity", [
    "24 records; 3 source clusters", "numerical pressure point", "only 2 records at 28 days"
], "#228833")
arrow(ax, 0.25, 0.68, 0.39, 0.68, "#2d6ea3")
arrow(ax, 0.86, 0.53, 0.50, 0.36, "#228833")
arrow(ax, 0.86, 0.53, 0.83, 0.36, "#228833")
ax.text(0.675, 0.42, "Pressure-evidence screening", ha="center", va="center",
        fontsize=8.0, color="#3d566e")
ax.text(0.03, 0.025,
        "Arrows show record-selection and evaluation relationships, not a causal sequence. "
        "The external cohorts are mixed-age stress tests, not target-matched 28-day validation.",
        fontsize=8.0, color="#3d566e")

ax2 = fig.add_subplot(gs[1])
ax2.imshow(mpimg.imread(INPUT))
ax2.set_axis_off()
ax2.set_title("(b) Random five-fold versus leave-one-study-out performance", loc="left",
              fontsize=11, fontweight="bold", pad=7)

for ext in ("png", "pdf"):
    fig.savefig(HERE / f"Fig1.{ext}", dpi=300)
