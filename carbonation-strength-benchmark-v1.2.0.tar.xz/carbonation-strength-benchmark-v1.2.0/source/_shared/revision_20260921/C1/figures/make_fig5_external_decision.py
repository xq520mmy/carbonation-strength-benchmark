#!/usr/bin/env python3
"""Plot the fixed C1 external decision comparison from frozen rerun JSON.

This is a presentation-only replacement for the former cross-population
scatterplot. It does not refit, select, or change any model or cohort.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MODEL = "ET300 raw rescaled (recommended)"
COHORTS = (
    ("Primary pressure-evidence", "rerun_primary_explicit_pressure.json", 41, 4, 7),
    ("Strict numerical pressure", "rerun_strict_numeric_point.json", 24, 3, 2),
)
BLUE = "#0072B2"
ORANGE = "#D55E00"


def load():
    values = []
    for name, filename, n, groups, age28 in COHORTS:
        record = json.loads((ROOT / filename).read_text())
        assert record["external_rows"] == n
        assert record["n_labs"] == groups
        model = record["runs"][MODEL]["all"]
        baseline = record["training_mean_baseline"]["all"]
        assert baseline["n"] == n
        values.append(
            {
                "name": name,
                "n": n,
                "groups": groups,
                "age28": age28,  # retained pressure-audit count, Table 6
                "model_r2": model["r2"]["mean"],
                "model_r2_seed_sd": model["r2"]["sd"],
                "baseline_r2": baseline["r2"],
                "model_rmse": model["rmse"]["mean"],
                "model_rmse_seed_sd": model["rmse"]["sd"],
                "baseline_rmse": baseline["rmse"],
            }
        )
    assert np.isclose(values[0]["model_r2"], -0.081857, atol=1e-5)
    assert np.isclose(values[1]["baseline_rmse"], 11.354022942829097)
    return values


def main():
    values = load()
    labels = [
        f"{v['name']}\n{v['n']} rows · {v['groups']} groups\n{v['age28']} at 28 days"
        for v in values
    ]
    y = np.array([1.0, 0.0])
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11.5})
    fig, (ax_r2, ax_rmse) = plt.subplots(1, 2, figsize=(8.4, 4.0))
    fig.subplots_adjust(left=0.35, right=0.975, top=0.72, bottom=0.22, wspace=0.30)
    fig.suptitle("Figure 5. External stress test against a fixed training-mean baseline", fontsize=13.4, y=0.96)

    for ax, field, model_label, baseline_label, xlim, xlabel in (
        (ax_r2, "r2", "model_r2", "baseline_r2", (-1.02, 0.82), "R² (higher is better)"),
        (ax_rmse, "rmse", "model_rmse", "baseline_rmse", (9.0, 16.5), "RMSE, MPa (lower is better)"),
    ):
        for yi, v in zip(y, values):
            model = v[model_label]
            baseline = v[baseline_label]
            ax.plot([model, baseline], [yi, yi], color="#B6B6B6", linewidth=1.5, zorder=1)
            ax.scatter(model, yi, marker="D", s=80, color=BLUE, zorder=3)
            ax.scatter(baseline, yi, marker="o", s=92, facecolors="white", edgecolors=ORANGE, linewidths=2.4, zorder=3)
            ax.text(model, yi + 0.16, f"{model:+.3f}" if field == "r2" else f"{model:.2f}",
                    color=BLUE, ha="center", va="bottom", fontsize=11.5)
            ax.text(baseline, yi - 0.17, f"{baseline:+.3f}" if field == "r2" else f"{baseline:.2f}",
                    color=ORANGE, ha="center", va="top", fontsize=11.5)
        ax.set_xlim(*xlim)
        ax.set_ylim(-0.42, 1.45)
        ax.set_yticks(y, labels if ax is ax_r2 else ["", ""])
        ax.tick_params(axis="y", length=0, pad=12)
        ax.set_xlabel(xlabel, fontsize=11.5, labelpad=7)
        ax.grid(axis="x", color="#E2E2E2", linewidth=0.8)
        ax.set_axisbelow(True)
        for spine in ("top", "right", "left"):
            ax.spines[spine].set_visible(False)
    ax_r2.axvline(0.65, color="#8B4A62", linestyle="--", linewidth=1.2, zorder=2)
    ax_r2.text(0.65, 1.39, "working criterion 0.65", color="#8B4A62",
               ha="right", va="top", rotation=90, fontsize=10.5)

    handles = [
        plt.Line2D([0], [0], marker="D", linestyle="none", color=BLUE,
                   markerfacecolor=BLUE, markersize=8, label="Fixed ExtraTrees · ten-seed mean"),
        plt.Line2D([0], [0], marker="o", linestyle="none", color=ORANGE,
                   markerfacecolor="white", markeredgewidth=2, markersize=9,
                   label="Constant training mean"),
    ]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.65, 0.87),
               frameon=False, ncol=2, fontsize=11)
    fig.text(0.5, 0.05,
             "Mixed measurement ages; source groups are author-merged and are not proven independent laboratories.",
             ha="center", va="bottom", fontsize=10.5, color="#444444")
    fig.savefig(HERE / "Figure5_decision_v13.pdf", metadata={"Title": "C1 external stress-test decision comparison"})
    fig.savefig(HERE / "Figure5_decision_v13.png", dpi=300)
    plt.close(fig)


if __name__ == "__main__":
    main()
