# C1 pressure evidence audit and frozen-prediction recomputation

> **Current output status, 29 September 2026.** This public report replaces the stale 39-record primary-cohort statements in the prior release. Use `rerun_seed_predictions.csv`, `rerun_*.json`, `ROOT_NUMERICAL_VERIFICATION.json`, and `C1_PUBLIC_PRESSURE_CORRECTION_20260929.md` for the corrected frozen-output record. No model was refit.

## What was audited

`pressure_audit_rows.csv` covers the 106 records previously used in external evaluation. It retains source and laboratory identifiers, source locations, pressure status, existing pressure fields, and cohort membership. Source quotations are not distributed. `pressure_audit_sources.csv` records the source-level decisions.

The corrected audit has 46 explicit numerical-pressure records, 17 explicit ambient-pressure records, and 43 records with no located pressure or ambient condition. Two records from `10.3390/constrmater4020020` are now explicit ambient under the existing 0.1-MPa convention; their retained locator is recorded in the row-level audit.

## Fixed cohorts

| Cohort | Rule | Rows | Source reports | Laboratory clusters | 28-day rows |
|---|---|---:|---:|---:|---:|
| Primary explicit pressure | Existing exact numerical pressure, or explicit ambient under the existing 0.1-MPa convention | 41 | 5 | 4 | 7 |
| Strict numerical point | Existing exact numerical curing pressure only | 24 | 3 | 3 | 2 |
| Legacy A | Original `A_complete` | 73 | 11 | 7 | 21 |
| Legacy all complete | Original A+B | 106 | 15 | 10 | 42 |
| Numerical range only | Explicit range without an existing point value | 22 | 1 | 1 | 11 |

The primary and strict cohorts are selected from the source-evidence rule and the pre-existing pressure field, independently of predictive performance.

## Corrected primary results

For the fixed ExtraTrees raw-rescaled configuration, the 41-record primary per-seed result is R² −0.081857 ± 0.032113 and RMSE 13.102087 ± 0.194730 MPa. The fixed training-mean comparator is R² −0.027951 and RMSE 12.772764 MPa. The cross-study 90% interval covers 36/41 records and the random-five-fold interval covers 13/41.

The seven-record age-28 subset is descriptive: ExtraTrees R² −1.087 ± 0.073 and RMSE 19.38 ± 0.34 MPa; the fixed comparator is R² −0.010 and RMSE 13.48 MPa. This source-audit correction does not constitute independent physical validation.
