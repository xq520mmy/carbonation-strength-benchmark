#!/usr/bin/env python3
"""Read-only audit of the C1 2,200 kg/m³ rescaling predicate and scope."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
PORTFOLIO = HERE.parents[2]
C1 = PORTFOLIO / "C1_crossdb_audit"
TRAIN = C1 / "probe/data/scirep_MOESM1.xlsx"
PROV = C1 / "probe/row_provenance.json"
EXTERNAL = C1 / "external_validation/extracted_data.csv"
COMMON = C1 / "model_experiments/common.py"
M1 = C1 / "model_experiments/results/m1_baseline_fe.json"
PRIMARY = HERE / "recomputed_primary_explicit_pressure.json"
OUTPUT = HERE / "UNIT_ASSUMPTION_AUDIT.json"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scopes(frame: pd.DataFrame, mass: list[str], aggregate: list[str], complete: pd.Series) -> dict:
    total = frame[mass].sum(axis=1, skipna=False)
    aggregate_total = frame[aggregate].sum(axis=1, skipna=False)
    low = complete & (total < 1200)
    rescale = low & (aggregate_total > 0)
    return {
        "rows_examined": int(len(frame)),
        "complete_rows": int(complete.sum()),
        "mass_total_lt_1200": int(low.sum()),
        "rescale_predicate": int(rescale.sum()),
        "low_total_not_rescaled": int((low & ~rescale).sum()),
        "rescale_rows": frame.index[rescale].tolist(),
        "low_not_rescaled_rows": frame.index[low & ~rescale].tolist(),
        "rescale_mass_totals": sorted({float(x) for x in total[rescale]}),
        "rescale_factors": sorted({float(2200.0 / x) for x in total[rescale]}),
    }


def main() -> None:
    train = pd.read_excel(TRAIN)
    prov = json.loads(PROV.read_text(encoding="utf-8"))["rows"]
    train_mass = ["C", "CA", "FA", "W", "blast furnace slag", "fly ash"]
    train_scope = scopes(
        train, train_mass, ["CA", "FA", "blast furnace slag"],
        pd.Series(True, index=train.index),
    )
    train_scope["rescale_rows_1based"] = [i + 1 for i in train_scope.pop("rescale_rows")]
    train_scope["low_not_rescaled_rows_1based"] = [
        i + 1 for i in train_scope.pop("low_not_rescaled_rows")
    ]
    train_scope["rescale_provenance"] = [
        {
            "row": i + 1,
            "study_cluster": prov[i]["study_cluster"],
            "confidence": prov[i]["confidence"],
            "source_ref_numbers": prov[i]["source_ref_numbers"],
        }
        for i in range(len(train))
        if i + 1 in train_scope["rescale_rows_1based"]
    ]

    external = pd.read_csv(EXTERNAL)
    ext_mass = ["C", "CA", "FA", "W", "slag", "fly_ash"]
    ext_complete_columns = ext_mass + ["W_B", "steam_h", "T_h", "CC", "P_MPa_model", "CS_MPa"]
    ext_scope = scopes(
        external, ext_mass, ["CA", "FA", "slag"],
        external[ext_complete_columns].notna().all(axis=1),
    )
    ext_scope["rescale_record_ids"] = external.loc[
        ext_scope.pop("rescale_rows"), "rec_id"
    ].astype(str).tolist()
    ext_scope["low_not_rescaled_record_ids"] = external.loc[
        ext_scope.pop("low_not_rescaled_rows"), "rec_id"
    ].astype(str).tolist()
    ext_scope["complete_rows_by_tier"] = {
        str(k): int(v)
        for k, v in external.loc[
            external[ext_complete_columns].notna().all(axis=1), "tier"
        ].value_counts(dropna=False).items()
    }

    # The paper's primary window table is a pressure-audited primary subset,
    # whose stored rows retain the original 11 columns.  Compare that exact
    # calculation with a training-only application of the rescale rule.
    cols_train = train_mass + ["W/B", "CCU-steam curing time", "T", "CC", "P"]
    primary = pd.DataFrame(json.loads(PRIMARY.read_text(encoding="utf-8"))["external_rows"])
    primary = primary[cols_train]
    primary = primary.apply(pd.to_numeric, errors="coerce")
    train_rescaled = train.copy()
    train_total = train[train_mass].sum(axis=1)
    train_rescale = (train_total < 1200) & (
        train[["CA", "FA", "blast furnace slag"]].sum(axis=1) > 0
    )
    train_rescaled[train_mass] = train_rescaled[train_mass].mul(
        (2200.0 / train_total).where(train_rescale, 1.0), axis=0
    )

    def window(scope_train: pd.DataFrame) -> dict:
        in_window = pd.Series(True, index=primary.index)
        outside: dict[str, int] = {}
        ranges: dict[str, list[float]] = {}
        for column in cols_train:
            low, high = float(scope_train[column].min()), float(scope_train[column].max())
            ranges[column] = [low, high]
            in_column = primary[column].between(low, high)
            outside[column] = int((~in_column).sum())
            in_window &= in_column
        return {"n_primary": int(len(primary)), "n_all_columns_inside": int(in_window.sum()),
                "outside_by_column": outside, "training_ranges": ranges}

    window_comparison = {
        "definition": "columnwise comparison against stored raw input columns; no model-derived features",
        "stored_training_columns": window(train),
        "training_columns_after_2200_rescale": window(train_rescaled),
    }

    m1 = json.loads(M1.read_text(encoding="utf-8"))["runs"]
    random_split_check = {
        "ExtraTrees_raw_flag": {
            "source_key": "ET300|raw|none",
            "r2_mean": m1["ET300|raw|none"]["rand"]["all198"]["r2"]["mean"],
            "rmse_mean": m1["ET300|raw|none"]["rand"]["all198"]["rmse"]["mean"],
        },
        "ExtraTrees_raw_rescale": {
            "source_key": "ET300|raw|none|rescale",
            "r2_mean": m1["ET300|raw|none|rescale"]["rand"]["all198"]["r2"]["mean"],
            "rmse_mean": m1["ET300|raw|none|rescale"]["rand"]["all198"]["rmse"]["mean"],
        },
    }

    report = {
        "scope": "read-only; no training, external scoring, or source files modified",
        "code_rule": "rescale iff six-component total < 1200 and CA + FA + blast-furnace-slag > 0; multiply six mass columns by 2200/total",
        "source_hashes": {str(p.relative_to(PORTFOLIO)): digest(p) for p in (TRAIN, PROV, EXTERNAL, COMMON, M1, PRIMARY)},
        "training": train_scope,
        "external_complete_case_pipeline": ext_scope,
        "primary_window_comparison": window_comparison,
        "random_fivefold_check": random_split_check,
        "interpretation": {
            "raw_flag_mode": "For fs='raw', flag mode returns the unchanged 11 raw columns before density_h or unit_normalized is appended.",
            "constant_status": "2,200 kg/m³ is an implementation assumption. Seven suspected rows carry a different 2,200-total normalisation, but their provenance does not establish it as the ref20 source volume or density.",
            "window_status": f"For the {len(primary)}-row primary cohort, rescaling changes the training minima for C (100 to 172) and W (56 to 63), but leaves the all-column count ({window_comparison['stored_training_columns']['n_all_columns_inside']}) and every per-column outside count unchanged.",
            "random_split_status": "The historical results round ExtraTrees raw flag to 0.958 and raw rescale to 0.957; prose reversing those labels is inconsistent with the result file and Table S6.1.",
        },
    }
    OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()
