# Density-sensitivity record (v2)

The public v2 density-sensitivity outputs use the corrected 41-record explicit-pressure primary cohort. The distributed files are `density_sensitivity.py`, `density_sensitivity_v2_predictions.csv`, `density_sensitivity_v2_summary.csv`, and `density_sensitivity_v2_summary.json`.

These versioned files supersede the unversioned density outputs from the prior 39-record primary cohort; those historical outputs are not included in this release. The supplied results are retained numerical provenance outputs. Running the analysis from source requires the publisher spreadsheet and audited external input material, neither of which is redistributed here.
