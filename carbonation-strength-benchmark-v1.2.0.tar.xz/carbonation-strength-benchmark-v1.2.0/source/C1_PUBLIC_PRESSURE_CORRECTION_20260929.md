# Public pressure-audit correction — 29 September 2026

Version `v1.2.0` replaces the stale `v1.1.0` primary-pressure cohort files. The correction classifies `EXT-0209` and `EXT-0210` as explicit ambient-pressure carbonation records under the existing 0.1-MPa convention. The retained source location is `10.3390/constrmater4020020`, `external_validation/text/10_3390_constrmater4020020.txt:1462-1470`; no source quotation is distributed.

The primary cohort now has 41 records from five source reports and four author-merged laboratory clusters; seven records are 28-day measurements. The strict numerical-pressure sensitivity remains 24 records, three clusters, and two 28-day records. Across all 106 audited rows, the status counts are 46 explicit numerical, 17 explicit ambient, and 43 unreported or unlocated.

For the fixed recommended ExtraTrees configuration, the 41-record primary per-seed result is R² −0.081857 ± 0.032113 and RMSE 13.102087 ± 0.194730 MPa. The fixed training-mean comparator has R² −0.027951 and RMSE 12.772764 MPa. The seven-record age-28 subset is descriptive: R² −1.087 ± 0.073 and RMSE 19.38 ± 0.34 MPa.

Only the pressure-audit tables, primary-cohort rerun outputs, and dependent schema/input-range diagnostics were updated. Frozen predictions, the strict cohort, and both legacy cohorts are unchanged. This is a source-audit correction and does not provide independent physical validation.
