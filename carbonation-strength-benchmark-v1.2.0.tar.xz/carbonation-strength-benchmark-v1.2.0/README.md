# Carbonation-strength benchmark v1.2.0

This release corrects the stale pressure-audit cohort published in `v1.1.0`. The public numerical archive updates the primary cohort to 41 records, five source reports, four laboratory clusters, and seven age-28 records. See `PUBLIC_RELEASE_CHANGES_v1.2.0.md` for the exact scope. Historical `v1.1.0` assets remain unchanged. No DOI is asserted.

The archive contains code, figures, numerical outputs, source locations, cohort decisions, and concise author-derived notes. It does not redistribute the 198-row publisher spreadsheet, article full text, or quoted passages from source literature.

The density-sensitivity files in this release are the corrected versioned v2 record for the 41-record primary cohort. Historical unversioned density outputs from the prior 39-record cohort are excluded.

## Verify and extract

First compare the downloaded files with `SHA256SUMS.txt`. Then extract the archive:

```sh
python unpack.py carbonation-strength-benchmark-v1.2.0.tar.xz --sha256 <archive-sha256>
```

From the extracted `carbonation-strength-benchmark-v1.2.0/source/` directory, run:

```sh
python _shared/revision_20260921/C1/verify_reproduction_outputs.py
python _shared/revision_20260921/C1/schema_alignment_sensitivity.py
```

The verifier uses retained predictions and never refits an estimator or retrieves literature. `THIRD_PARTY_NOTICES.md` covers the included UCI transfer-pretraining CSV. Users must determine applicable permissions before reuse.
