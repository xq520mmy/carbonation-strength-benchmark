#!/usr/bin/env python3
"""Refit frozen C1 external models once and score fixed pressure cohorts.

The 198-row training table, model factories, feature engineering, unit rule,
and seeds are imported unchanged from the project. This script writes only its
own directory. It deliberately selects cohorts before any fit.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[2]/"C1_crossdb_audit"
EV=PROJECT/"external_validation"
sys.path.insert(0,str(EV/"scripts"))
import run_extval as R
import common as C

AUDIT=HERE/"pressure_audit_rows.csv"
OLD=EV/"results"/"extval_tierAB.json"
COHORTS={
    "primary_explicit_pressure":"cohort_primary_explicit_pressure",
    "strict_numeric_point":"cohort_strict_numeric_point",
    "legacy_A_complete":"cohort_legacy_A_complete",
    "legacy_all_complete":"cohort_legacy_all_complete",
}

def metric(y,p):
    y=np.asarray(y,float); p=np.asarray(p,float)
    return {"n":int(len(y)),"r2":float(r2_score(y,p)) if len(y)>1 and np.var(y)>0 else None,
            "rmse":float(math.sqrt(mean_squared_error(y,p))),"mae":float(mean_absolute_error(y,p)),
            "bias":float(np.mean(p-y))}

def aggregate(y,P,mask):
    vals=[metric(y[mask],p[mask]) for p in P]
    out={}
    for k in ("r2","rmse","mae","bias"):
        x=[z[k] for z in vals if z[k] is not None]
        out[k]={"mean":float(np.mean(x)) if x else None,
                "sd":float(np.std(x,ddof=1)) if len(x)>1 else 0.0,
                "n_seeds":len(x)}
    return out

def main():
    started=time.time()
    audit=pd.read_csv(AUDIT)
    wanted=audit.set_index(audit.rec_id.astype(str))
    ext=R.load_external(("A_complete","B_P_imputed_ambient"),False).reset_index(drop=True)
    ids=ext.rec_id.astype(str).tolist()
    if set(ids)!=set(wanted.index) or len(ids)!=106: raise SystemExit("Audit/external record identity mismatch")
    old=json.loads(OLD.read_text())
    old_rows=old["external_rows"]
    if ids != [str(x["rec_id"]) for x in old_rows]: raise SystemExit("External order differs from frozen tierAB JSON")
    a=wanted.loc[ids].reset_index(drop=True)
    # Explicitly validate the target and model pressure used for every rerun row.
    if not np.allclose(pd.to_numeric(ext.CS,errors="coerce"),pd.to_numeric(a.CS_MPa,errors="coerce")): raise SystemExit("CS mismatch")
    if not np.allclose(pd.to_numeric(ext.P,errors="coerce"),pd.to_numeric(a.P_MPa_model,errors="coerce")): raise SystemExit("P mismatch")
    y=ext.CS.to_numpy(float)
    rawtrain=C._df
    pred={}
    long=[]
    for name,cfg in R.CONFIGS.items():
        print(f"{name}",flush=True)
        Xtr=C.make_features(rawtrain,"raw",cfg["harm"])
        Xte=C.make_features(ext,"raw",cfg["harm"])
        ps=[]
        for seed in cfg["seeds"]:
            model=cfg["mk"](seed)
            model.fit(Xtr,C.Y)
            p=np.asarray(model.predict(Xte),float)
            ps.append(p)
            long.extend({"configuration":name,"seed":int(seed),"rec_id":ids[i],"prediction_mpa":float(v)} for i,v in enumerate(p))
        pred[name]=np.asarray(ps)
    # Stacking weights were fitted only on the frozen 198 training rows in the
    # original protocol. Reuse those frozen weights; do not refit them on any
    # pressure cohort. These two configurations are deterministic combinations
    # of the newly rerun base-model predictions.
    stack_names=R.STACK_CANDS
    weights=np.array([old["stack_weights"][n] for n in stack_names],float)
    stack=np.column_stack([pred[n].mean(axis=0) for n in stack_names]) @ weights
    uniform=np.column_stack([pred[n].mean(axis=0) for n in stack_names]).mean(axis=1)
    pred["stack-NNLS"]=stack[None,:]
    pred["uniform-mean of 4 candidates"]=uniform[None,:]
    long.extend({"configuration":"stack-NNLS","seed":0,"rec_id":ids[i],"prediction_mpa":float(v)} for i,v in enumerate(stack))
    long.extend({"configuration":"uniform-mean of 4 candidates","seed":0,"rec_id":ids[i],"prediction_mpa":float(v)} for i,v in enumerate(uniform))
    configs={**R.CONFIGS,
             "stack-NNLS":{"harm":"rescale","seeds":[0]},
             "uniform-mean of 4 candidates":{"harm":"rescale","seeds":[0]}}
    pd.DataFrame(long).to_csv(HERE/"rerun_seed_predictions.csv",index=False)
    # Pre-existing calibration q is valid to reuse because it was fitted solely
    # on the frozen 198-row train set, independently of external membership.
    qrows=old["conformal"]
    all_outputs={}
    for cohort,flag in COHORTS.items():
        member=a[flag].astype(bool).to_numpy()
        age=pd.to_numeric(a.cs_age_d,errors="coerce").eq(28).to_numpy()
        for label,mask in [(cohort,member),(cohort+"_age28",member & age)]:
            inwin=np.array([bool(r["_inwin"]) for r in old_rows]) & mask
            strict=np.array([bool(r["_strict"]) for r in old_rows]) & mask
            rows=[]
            for i in np.flatnonzero(mask):
                rows.append(dict(ext.iloc[i]))
            runs={}
            for name,P in pred.items():
                run={"harm":configs[name]["harm"],"n_seeds":int(P.shape[0]),
                     "all":aggregate(y,P,mask),"in_window":aggregate(y,P,inwin) if inwin.any() else None,
                     "strict":aggregate(y,P,strict) if strict.any() else None,
                     "pred_mean":P[:,mask].mean(axis=0).tolist(),
                     "by_study":{}}
                labs=ext.lab_id.astype(str).to_numpy()
                for lab in sorted(set(labs[mask])):
                    m=mask & (labs==lab); run["by_study"][lab]=metric(y[m],P.mean(axis=0)[m])
                runs[name]=run
            base=np.full(len(y),float(np.mean(C.Y)))
            conf=[]
            for q in qrows:
                name=q["model"]
                if name not in pred: continue
                pm=pred[name].mean(axis=0); qq=float(q["q"])
                conf.append({"model":name,"alpha":q["alpha"],"calib":q["calib"],"q":qq,"width":2*qq,"nominal":q["nominal"],
                             "coverage_all":float(np.mean(np.abs(y[mask]-pm[mask])<=qq)) if mask.any() else None,
                             "coverage_in_window":float(np.mean(np.abs(y[inwin]-pm[inwin])<=qq)) if inwin.any() else None,
                             "coverage_strict":float(np.mean(np.abs(y[strict]-pm[strict])<=qq)) if strict.any() else None})
            out={"protocol":"PRESSURE_AUDIT_PROTOCOL.md","cohort":cohort,"age28_only":label.endswith("_age28"),
                 "frozen_model_rerun":True,"training_rows":198,"external_rows":int(mask.sum()),
                 "n_sources":int(a.loc[mask,"source_key"].nunique()),"n_labs":int(a.loc[mask,"lab_id"].nunique()),
                 "n_in_window":int(inwin.sum()),"n_strict":int(strict.sum()),
                 "seed_definitions":{k:list(map(int,v["seeds"])) for k,v in configs.items()},
                 "pressure_status_counts":a.loc[mask,"pressure_status"].value_counts().to_dict(),
                 "selected_rec_ids":[ids[i] for i in np.flatnonzero(mask)],"runs":runs,
                 "training_mean_baseline":{"constant_mpa":float(np.mean(C.Y)),"all":metric(y[mask],base[mask]),
                    "in_window":metric(y[inwin],base[inwin]) if inwin.any() else None,
                    "strict":metric(y[strict],base[strict]) if strict.any() else None},"conformal":conf,
                 "elapsed_seconds":time.time()-started}
            path=HERE/f"rerun_{label}.json"; path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n")
            all_outputs[label]=out
    # Compare same-row legacy runs with the historical seed aggregates.
    check={"prediction_csv":"rerun_seed_predictions.csv","comparisons":{}}
    for cohort,oldtag in [("legacy_A_complete","tierA"),("legacy_all_complete","tierAB")]:
        now=all_outputs[cohort]; prior=json.loads((EV/"results"/f"extval_{oldtag}.json").read_text())
        c={"same_row_order":now["selected_rec_ids"]==[str(r["rec_id"]) for r in prior["external_rows"]],"metrics":{}}
        for name in configs:
            c["metrics"][name]={}
            for k in ("r2","rmse","mae","bias"):
                x=now["runs"][name]["all"][k]["mean"]; z=prior["runs"][name]["all"][k]["mean"]
                c["metrics"][name][k]={"rerun_mean":x,"old_mean":z,"difference":x-z}
        check["comparisons"][cohort]=c
    (HERE/"rerun_legacy_reproduction_check.json").write_text(json.dumps(check,indent=2)+"\n")
    print(f"done in {time.time()-started:.1f}s",flush=True)

if __name__=="__main__": main()
