# C1 pressure evidence audit and frozen-prediction recomputation

> **Current output status, 21 September 2026.** The historical mean-prediction recomputation described below has been superseded for manuscript tables by an actual rerun of the unchanged model configurations and seeds. Use `rerun_seed_predictions.csv`, `rerun_*.json`, and `ROOT_NUMERICAL_VERIFICATION.json`. The rerun reproduces the legacy per-seed aggregate metrics to within 2.4 × 10⁻⁷. For ExtraTrees, primary R² is −0.225 ± 0.040 and RMSE 12.97 ± 0.21 MPa; strict numerical-pressure R² is −0.755 ± 0.042 and RMSE 14.41 ± 0.17 MPa. The earlier values below summarize the mean prediction, a different aggregation. Their lack-of-seed-SD limitation no longer applies to the new rerun outputs. The audit cohorts themselves are unchanged.

## What was audited

`pressure_audit_rows.csv` is a row-level audit of all 106 records previously
used in external evaluation (`A_complete` or `B_P_imputed_ambient`). It has one
row for every `rec_id`, its source/laboratory identifiers, the retained source
location (without source quotation), pressure status, existing pressure fields, and
membership in every predeclared cohort. `pressure_audit_sources.csv` gives the
same decision once per source. The protocol was written before reading any
recomputed performance result in `PRESSURE_AUDIT_PROTOCOL.md`.

The source audit found 46 rows with an explicit numerical curing pressure, 15
with an explicit ambient-pressure curing condition, and 45 for which no curing
pressure or explicit ambient condition was located in the retained full text.
This last label is deliberately an *unlocated* label, not a claim that the
source never reports pressure.

Twenty-two of the 46 numerical rows come from `10.3390/su18115676`; the row-level audit retains the source locator but no quoted source text. The source-reported curing-pressure range is treated as explicit numerical range evidence, but the frozen data contain no record-specific pressure point and the original analysis did not define a gauge-to-absolute conversion. It is listed as `explicit_numeric` but excluded from the scorable primary and strict cohorts; no midpoint was invented after observing predictions.

The main correction is that 34 legacy tier-A rows from seven sources had been
given 0.1 MPa without a located pressure/ambient passage. The retained text
does specify the other chamber conditions for each of those sources. Examples
that guard against false positive pressure evidence are recorded in the audit:
the 0–35-atm conditions in `10.3390/ma18040904` are adsorption tests, and the
high-pressure gold spraying in `10.3390/ma17246191` is SEM preparation, not
carbonation curing.

## Fixed cohorts

| Cohort | Rule | Rows | Sources | Laboratory clusters | 28-day rows |
|---|---|---:|---:|---:|---:|
| Primary explicit pressure | Existing exact numerical pressure, or explicit ambient condition under the existing 0.1-MPa convention | 39 | 4 | 4 | 5 |
| Strict numerical point | Existing exact numerical curing pressure only | 24 | 3 | 3 | 2 |
| Legacy A | Original `A_complete` | 73 | 11 | 7 | 21 |
| Legacy all complete | Original A+B | 106 | 15 | 10 | 42 |
| Numerical range only | Explicit range but no existing point value | 22 | 1 | 1 | 11 |

The first two cohorts are selected solely by the source evidence rule and
pre-existing pressure field. They are not selected for a favorable score.

## Recomputed external results

The `recomputed_*.json` files contain the full Table-10 model matrix,
training-mean baseline, window/strict subsets, per-cluster errors, conformal
coverage, selected row IDs, and source provenance for every scorable cohort and
the matching age-28 descriptive subset. They reuse the stored mean predictions
from the frozen original external-evaluation JSONs, so no model, feature,
training row, fold, seed, or hyperparameter was changed or tuned.

For the recommended ExtraTrees raw-rescaled model, metrics of the frozen mean
prediction are:

| Cohort | n | Clusters | R² | RMSE (MPa) | Training-mean R² | Training-mean RMSE (MPa) |
|---|---:|---:|---:|---:|---:|---:|
| Primary explicit pressure | 39 | 4 | -0.224 | 12.97 | -0.054 | 12.03 |
| Strict numerical point | 24 | 3 | -0.754 | 14.40 | -0.090 | 11.35 |
| Legacy A | 73 | 7 | +0.008 | 18.46 | -0.001 | 18.55 |
| Legacy all complete | 106 | 10 | -0.374 | 20.80 | -0.005 | 18.56 |

The age-28 subsets are too small to support a stable R² interpretation (n=5
for primary and n=2 for strict numerical); their values are retained in the
JSON only as descriptive sensitivity outputs.

## Legacy continuity check and limitation

`legacy_reproduction_check.json` confirms that legacy A (73) and legacy A+B
(106) reuse exactly the original external-row sequence and stored predictions.
For the recommended model, the metric of the reused mean prediction differs
from the original reported mean-across-seeds by only +0.0012 R² / -0.0097 MPa
RMSE for A and +0.0015 R² / -0.0105 MPa RMSE for A+B. This small difference is
expected: the old JSON retained only the mean prediction, whereas Table 10
reported the mean of metrics evaluated separately across stochastic seeds.
Seed-level prediction vectors were not retained, so no honest seed SD can be
reconstructed from these frozen result files. The original per-seed aggregate
values are copied into the legacy recomputation JSONs for traceability; a
future seed-SD rerun would require an explicit new execution of the unchanged
prediction script, not an inferred variance.

## Commands and outputs

```sh
PY=work/pub_portfolio_20260916/C1_crossdb_audit/model_experiments/.venv/bin/python
$PY work/pub_portfolio_20260916/_shared/revision_20260921/C1/build_pressure_audit.py
$PY work/pub_portfolio_20260916/_shared/revision_20260921/C1/run_pressure_cohorts.py --all
$PY work/pub_portfolio_20260916/_shared/revision_20260921/C1/run_pressure_cohorts.py --all --age28
```

The project virtual environment is used only because it is the frozen model
environment containing the packages needed to read the original model data; the
recomputation script does not fit or predict with any estimator. All outputs
are confined to this revision directory.
