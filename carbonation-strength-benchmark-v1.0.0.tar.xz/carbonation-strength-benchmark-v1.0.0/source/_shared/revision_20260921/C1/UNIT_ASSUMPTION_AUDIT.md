# C1 unit-assumption audit

**Scope.** Read-only audit of the 2,200 kg/m³ rescale operation, its source
provenance, its training and external-test reach, the raw-feature flag, the
random-five-fold sentence in S6.3, and the range-window display. No model was
run and no original source, experiment output, generator, or manuscript was
changed. The companion [`UNIT_ASSUMPTION_AUDIT.json`](UNIT_ASSUMPTION_AUDIT.json)
is a reproducible count/range record; it hashes all inputs used.

## Finding 1 — the former batch-volume wording was false (resolved in current final; protect against stale drafts)

**Severity: must remain corrected.** `model_experiments/common.py:117-129`
implements the following rule:

```
rescale iff total(C, CA, FA, W, blast furnace slag, fly ash) < 1200
           and CA + FA + blast furnace slag > 0;
then multiply all six mass columns by 2200 / recorded_total.
```

Thus this is not a conversion using a source-reported batch volume. For each
triggering record the recorded total is 1,018 kg and the multiplier is
`2200/1018 = 2.1611001965`.

The provenance for rows 17--24 and 42--48 (`probe/row_provenance.json:449`
and analogous entries) identifies the source recipe as 1.6 kg cement, 0.9 kg
water, 5.5 kg coarse aggregate, and 8.3 kg fine aggregate: a 16 kg batch
scaled by 62.5 to a nominal 1,000 kg. It does **not** give a batch volume or
a measured 2,200 kg/m³ density. Rows 181--187 happen to have a six-component
total of 2,200 kg/m³, but their provenance (`row_provenance.json:4138` and
following) calls that a different, *suspected* normalisation from another
report; it is not evidence that 2,200 is the source volume or density for the
15 confirmed records.

`manuscript/C1_final_REVISED.md:100` now accurately calls 2,200 kg/m³ an
implementation assumption and states the exact predicate. Do not restore the
former “using the source's reported batch volume” wording retained in the
older `C1_submission_draft.md:83` and build copy.

**Direct replacement if a short statement is needed elsewhere:**

> Under *rescaling*, rows with a recorded six-component mass total below
> 1,200 kg and a positive recorded aggregate total have all six mass columns
> multiplied by 2,200 divided by their recorded total. The 2,200 kg/m³ total
> is an assumed conversion constant, not a recovered source batch volume or a
> measured density.

The generic unit listing at `C1_final_REVISED.md:84` should also avoid saying
unqualifiedly that every stored mass is kg/m³. Suggested replacement for the
mass part of that sentence:

> The eleven stored input columns comprise recorded cement, coarse aggregate,
> fine aggregate, water, blast-furnace slag and fly-ash masses (nominal
> kg/m³, except for the 15 mass-normalised records described in Section 3.3),
> followed by water-to-binder ratio, steam pre-curing duration, carbonation
> duration T (h), carbon-dioxide volume fraction CC and carbonation pressure P
> (MPa).

## Finding 2 — exact scope and raw-flag behavior

**Severity: reporting clarification.** The code/data audit finds:

| Scope | Rows with total < 1,200 | Rows actually rescaled | Notes |
|---|---:|---:|---|
| 198-row training table | 17 | 15 | The 15 are all confirmed `SHAO_DOE_BLOCK`, ref. 20, rows 17--24 and 42--48; rows 195--196 total 633 but have no recorded aggregate, so they are not rescaled. |
| 106 complete external rows entering the historical model pipeline | 0 | 0 | 73 tier-A and 33 tier-B complete records; no external complete case is changed. |

For `fs="raw"`, `make_features()` copies the 11 raw columns and returns at
`common.py:132-136`, before it constructs `density_h` and
`unit_normalized` at lines 142--176. Therefore **raw flagging makes no input
change at all**: raw `flag` is numerically the same as raw `off`; only
`rescale` changes raw inputs. The two rows 195--196 receive the density flag
only in density-containing feature sets, not in raw models.

The current final's line 100 correctly says this. Tables and prose should not
imply that “raw flagged” adds a binary predictor.

## Finding 3 — S6.3 reverses the random-five-fold rescale comparison

**Severity: numerical correction required.** The source result file
`model_experiments/results/m1_baseline_fe.json` gives:

| Configuration | Result key | random 5-fold R² | RMSE [MPa] |
|---|---|---:|---:|
| ExtraTrees raw, flag (unchanged raw inputs) | `ET300|raw|none` | 0.957890996 | 3.85284 |
| ExtraTrees raw, rescale | `ET300|raw|none|rescale` | 0.957251645 | 3.88223 |

Table S6.1 rounds these correctly to 0.958 (flag) and 0.957 (rescale).
However, `C1_final_REVISED.md:233` and the corresponding supplementary
paragraph (`C1_supplementary_submission_draft.md:477`) reverse their labels.

**Replace that last sentence with:**

> Under random splitting, random five-fold R² is 0.957 ± 0.004 with assumed
> rescaling and 0.958 ± 0.004 with flagging, which leaves the eleven raw
> columns unchanged.

## Finding 4 — the range display is an observed-record range, not a physical process window

**Severity: reporting clarification required; no table/figure rerun required.**
`external_validation/scripts/run_extval.py:98-113` and
`make_figs.py:38-57` calculate the range/window from the **stored raw eleven
columns** in the 198-row xlsx, before the optional 2,200 transformation. The
current Table 12 and Fig. 4 call it a “process window,” which overstates what
the calculation establishes when 15 source records have a different mass
normalisation.

I recomputed the 39-row pressure-audited primary cohort using the same stored
columns and using a rescaled training table. Rescaling changes the training
minimum for cement from 100 to 172 kg/m³ and for water from 56 to 63 kg/m³,
but it changes **none** of the reported cohort counts: 12/39 are inside all
eleven column ranges; outside counts remain cement 12, T 20, CC 15, and zero
for every other column. Thus a terminology/definition change is sufficient.

**Suggested replacement for Table 12's caption and nearby sentence:**

> Twelve of the 39 primary records lie inside the observed 198-row ranges on
> all eleven stored input columns. These are columnwise record ranges, not a
> physical process window or evidence that all stored masses share a common
> unit. Applying the assumed 2,200 kg/m³ rescaling to the 15 training records
> does not change the inside/outside counts for this cohort.
>
> **Table 12.** Observed-record range overlap for the 39-record primary
> cohort. “Outside” is defined against columnwise minima and maxima of the 198
> stored raw input records, before optional rescaling.

Use the same “stored-input ranges” wording in the Fig. 4 caption.

## Slag semantics

No conflicting manuscript statement was found in the current final. The
code's `binder = C + fly ash` and `agg = CA + FA + blast furnace slag`
(`common.py:145-157`) agree with the provenance metadata and final line 100:
the 1,502 kg/m³ *blast-furnace slag* field in the McGill lightweight-masonry
rows denotes expanded-slag lightweight aggregate, not a supplementary
cementitious material. The generic column label should retain that caveat near
any physical interpretation.

## Sensitivity decision

The existing flag-versus-rescale ablation is a useful sensitivity to applying
the transformation at all, and no external-data sensitivity is needed because
zero external complete cases trigger it. It does **not** test sensitivity to
the unverified *choice of 2,200*. If the rescaled configuration remains the
recommended/main result or the manuscript calls its values approximate kg/m³,
add a pre-specified alternative-constant sensitivity (for example, two
plausible fixed totals) before submission, without selecting among constants
by outer-fold performance. If no such rerun is added, retain the current
careful framing: an operational assumption with a flag-versus-rescale
ablation, not a recovered physical conversion.
