"""Recompute every reported external per-seed metric from archived row predictions."""
from pathlib import Path
import csv,json,math,hashlib
import numpy as np
HERE=Path(__file__).resolve().parent
P=HERE.parents[2]/'C1_crossdb_audit'
old=json.loads((P/'external_validation/results/extval_tierAB.json').read_text())
y_by={str(r['rec_id']):float(r['CS']) for r in old['external_rows']}
with (HERE/'rerun_seed_predictions.csv').open() as f:pred=list(csv.DictReader(f))
lookup={}
for r in pred:
    key=(r['configuration'],int(r['seed']))
    lookup.setdefault(key,{})[r['rec_id']]=float(r['prediction_mpa'])
def metrics(y,p):
    e=p-y
    return {'r2':1-np.sum(e*e)/np.sum((y-y.mean())**2),'rmse':np.sqrt(np.mean(e*e)), 'mae':np.mean(np.abs(e)), 'bias':np.mean(e)}
count=0;cohort_count=0
for file in sorted(HERE.glob('rerun_*.json')):
    j=json.loads(file.read_text())
    if 'selected_rec_ids' not in j or 'runs' not in j:continue
    cohort_count+=1
    ids=j['selected_rec_ids'];y=np.array([y_by[str(i)] for i in ids])
    for model,run in j['runs'].items():
        seeds=sorted(s for name,s in lookup if name==model)
        vals=[metrics(y,np.array([lookup[(model,seed)][str(i)] for i in ids])) for seed in seeds]
        for metric in ['r2','rmse','mae','bias']:
            v=np.array([x[metric] for x in vals])
            expected=run['all'][metric]
            assert np.isclose(v.mean(),expected['mean'],atol=1e-10,rtol=1e-10),(file.name,model,metric,'mean')
            assert np.isclose(v.std(ddof=1) if len(v)>1 else 0,expected['sd'],atol=1e-10,rtol=1e-10),(file.name,model,metric,'sd')
            assert len(v)==expected['n_seeds']
            count+=1
    base=j['training_mean_baseline']
    check=metrics(y,np.full(len(y),base['constant_mpa']))
    for metric,value in check.items():
        assert np.isclose(value,base['all'][metric],atol=1e-10,rtol=1e-10),(file.name,'baseline',metric)
print(json.dumps({'passed':True,'model_metric_aggregates_checked':count,'row_predictions':len(pred),'cohort_files':cohort_count}))
