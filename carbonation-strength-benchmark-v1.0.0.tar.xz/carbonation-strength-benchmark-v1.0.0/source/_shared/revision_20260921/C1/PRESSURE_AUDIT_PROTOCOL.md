# C1 pressure-evidence audit protocol

## Scope and frozen inputs

This audit covers every row currently assigned `A_complete` or
`B_P_imputed_ambient` in
`C1_crossdb_audit/external_validation/extracted_data.csv` (106 rows). It does
not alter that file, the training data, features, folds, model code,
hyperparameters, seeds, unit harmonisation, stacking weights, or conformal
calibration. The source is the locally retained full text; the extraction
evidence is only a locator aid.

## Status rule, fixed before any model results are examined

Each row inherits the status established for its source experiment:

* `explicit_numeric`: the source explicitly gives the **carbonation-curing**
  pressure as a numerical point or range. A pressure for adsorption,
  porosimetry, a mechanical test, a gas cylinder rating, or a cited study is
  not evidence for this status.
* `explicit_ambient`: the source explicitly says that the carbonation-curing
  chamber/process operated at ambient/atmospheric pressure. This is encoded as
  0.1 MPa only where the existing extraction already uses that deterministic
  convention.
* `unreported_or_unlocated`: no located source passage gives a carbonation
  curing pressure or an explicit ambient operating condition. This status means
  “not located in the retained source”, never that the paper proves pressure
  was absent.

The public audit records the source location and a concise non-verbatim audit note for every row; cited source excerpts are not distributed. Where an
article gives only a numerical **range** (rather than the pressure used for a
particular record), the status remains `explicit_numeric`, but
`pressure_point_usable_for_frozen_predictor=false`: no midpoint, gauge-to-
absolute conversion, or other new numerical imputation is introduced.

## Cohorts, fixed independently of predictive performance

All cohorts require the 11 existing model inputs and the observed strength to
be non-missing. They are selected only from the status and pre-existing model
pressure field:

1. `primary_explicit_pressure`: exact numerical pressure already present in
   `P_MPa_model`, or `explicit_ambient` with the existing 0.1-MPa convention.
   This is the primary reported cohort.
2. `strict_numeric_point`: `explicit_numeric` with an exact pre-existing
   `P_MPa_model`; it excludes ambient and numerical ranges without a point.
3. `legacy_A_complete`: the original `A_complete` cohort, reproduced without
   changing a row, for comparison only.
4. `legacy_all_complete`: original `A_complete` plus
   `B_P_imputed_ambient`, for comparison only.

The `explicit_numeric` range-only records are listed separately. They are not
scored until authors pre-specify a physically justified value/transform and
apply it without reference to outcomes.

For each scorable cohort, the frozen external-evaluation program is reused
unchanged and its full model matrix, training-mean baseline, in-window/strict
subsets, laboratory-cluster metrics, and conformal calculations are written to
new JSON files. The same age-28 filter is then applied as a descriptive
sensitivity, without reselecting a model.

## Reproducibility command

Run from the repository root with the frozen project model environment (it is
the environment that contains the existing scikit-learn/LightGBM/TabPFN stack;
this reuse script does not fit any of them):

```sh
work/pub_portfolio_20260916/C1_crossdb_audit/model_experiments/.venv/bin/python \
  work/pub_portfolio_20260916/_shared/revision_20260921/C1/run_pressure_cohorts.py --all
```

The command reads only the frozen project inputs and this revision directory,
and writes only `work/pub_portfolio_20260916/_shared/revision_20260921/C1/`.
