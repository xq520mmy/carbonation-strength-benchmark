#!/usr/bin/env python3
"""Fixed 2,000/2,200/2,400 kg/m³ C1 ExtraTrees sensitivity; see protocol."""
from __future__ import annotations
import csv, hashlib, json, os, platform, subprocess, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

sys.dont_write_bytecode = True
HERE=Path(__file__).resolve().parent; PORT=HERE.parents[2]; P=PORT/'C1_crossdb_audit'
DATA=P/'probe/data/scirep_MOESM1.xlsx'; PROV=P/'probe/row_provenance.json'; COMMON=P/'model_experiments/common.py'
M1=P/'model_experiments/results/m1_baseline_fe.json'; M10=P/'model_experiments/results/m10_strict_mcgill.json'
PRIMARY=HERE/'rerun_primary_explicit_pressure.json'; EXTSTRICT=HERE/'rerun_strict_numeric_point.json'; PRROWS=HERE/'recomputed_primary_explicit_pressure.json'; ESROWS=HERE/'recomputed_strict_numeric_point.json'; PROTOCOL=HERE/'DENSITY_SENSITIVITY_PROTOCOL.md'
PCSV=HERE/'density_sensitivity_predictions.csv'; SCSV=HERE/'density_sensitivity_summary.csv'; SJSON=HERE/'density_sensitivity_summary.json'
RAW=['C','CA','FA','W','blast furnace slag','fly ash','W/B','CCU-steam curing time','T','CC','P']; MASS=RAW[:6]; AGG=['CA','FA','blast furnace slag']
CONSTS=[2000.,2200.,2400.]; SEEDS=list(range(10)); FOLDS=['TAIWAN_LEE_WANG','SHAO_DOE_BLOCK','MCGILL_LAB']; ADDED=np.array([26,34,35,36,37,85,87,88,89,90,175,176,177,178,179])
TOL=1e-10

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def msd(v):
    a=np.asarray(v,float); return {'mean':float(a.mean()),'sd':float(a.std(ddof=1)) if len(a)>1 else 0.,'n_seeds':len(a)}
def met(y,p): return {'n':len(y),'r2':float(r2_score(y,p)),'rmse':float(np.sqrt(mean_squared_error(y,p))),'mae':float(mean_absolute_error(y,p)),'bias':float(np.mean(p-y))}
def aggregate(v): return {'n_rows':int(v[0]['n']),**{k:msd([x[k] for x in v]) for k in ('r2','rmse','mae','bias')}}

def transform(df, constant):
    d=df[RAW].copy().astype(float); total=d[MASS].sum(axis=1); active=(total<1200)&(d[AGG].sum(axis=1)>0)
    factor=pd.Series(1.,index=d.index); factor.loc[active]=constant/total.loc[active]; d[MASS]=d[MASS].mul(factor,axis=0)
    return d,active.to_numpy()

def source_digest():
    code="""import hashlib,sys;sys.dont_write_bytecode=True;sys.path.insert(0,sys.argv[1]);import common;x=common.make_features(common._df,'raw','rescale').to_numpy(dtype='float64',copy=True);print(hashlib.sha256(x.tobytes(order='C')).hexdigest())"""
    env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
    o=subprocess.run([sys.executable,'-c',code,str(P/'model_experiments')],check=True,text=True,capture_output=True,env=env).stdout.strip().splitlines()
    if len(o)!=1 or len(o[0])!=64: raise RuntimeError('unexpected common.py digest output')
    return o[0]

def blocks(prov):
    cl=np.array([(x['study_cluster'] or '') for x in prov])
    rows=lambda n:{i+1 for i,v in enumerate(cl) if v==n}
    extra={34,39,40,41,64,65,87,*range(188,199)}|set(range(1,17))|set(range(28,34))
    b={'TAIWAN_LEE_WANG':rows('TAIWAN_LEE_WANG'),'SHAO_DOE_BLOCK':rows('SHAO_DOE_BLOCK'),'MCGILL_LAB':rows('MCGILL_LWCMU')|rows('MCGILL_LIU_WETMIX')|extra}
    if {k:len(v) for k,v in b.items()}!={'TAIWAN_LEE_WANG':45,'SHAO_DOE_BLOCK':22,'MCGILL_LAB':76}: raise RuntimeError('fold reconstruction failed')
    return {k:np.array(sorted(v-1 for v in x),int) for k,x in b.items()}

def predict(x,y,tr,te,seed): return ExtraTreesRegressor(n_estimators=300,random_state=seed,n_jobs=1).fit(x.iloc[tr],y[tr]).predict(x.iloc[te])
def get_external(path):
    d=json.loads(path.read_text()); r=pd.DataFrame(d['external_rows']);
    if r[RAW].isna().any().any() or r.CS.isna().any(): raise RuntimeError(f'bad external cohort {path.name}')
    return r[RAW].astype(float),r.CS.to_numpy(float),r.rec_id.astype(str).tolist()
def required_new():
    old=[str(x) for x in (PCSV,SCSV,SJSON) if x.exists()]
    if old: raise RuntimeError('refusing overwrite: '+', '.join(old))

def main():
    required_new(); start=time.monotonic(); train=pd.read_excel(DATA)
    if list(train.columns)!=RAW+['CS'] or len(train)!=198: raise RuntimeError('unexpected training schema')
    y=train.CS.to_numpy(float); n=np.arange(198); b=blocks(json.loads(PROV.read_text())['rows']); primary_rows=np.sort(np.concatenate([b[x] for x in FOLDS]))
    ext1=get_external(PRROWS); ext2=get_external(ESROWS)
    x2200,active=transform(train,2200.); local=hashlib.sha256(x2200.to_numpy(dtype=np.float64).tobytes(order='C')).hexdigest(); source=source_digest()
    if local!=source: raise RuntimeError('private 2200 transform differs from common.make_features raw/rescale')
    if active.sum()!=15: raise RuntimeError('unexpected training rescale count')
    oldm1=json.loads(M1.read_text())['runs']['ET300|raw|none|rescale']['loso']['pooled']
    oldm10=json.loads(M10.read_text())['runs']['ET300 raw rescale (leaf=1)']['loso']['pooled143_comparable']
    oldext={'external_primary_39':json.loads(PRIMARY.read_text())['runs']['ET300 raw rescaled (recommended)']['all'],'external_strict_pressure_24':json.loads(EXTSTRICT.read_text())['runs']['ET300 raw rescaled (recommended)']['all']}
    allrows=[]; results={}
    for constant in CONSTS:
        x,_=transform(train,constant); xe1,ae1=transform(ext1[0],constant); xe2,ae2=transform(ext2[0],constant)
        if ae1.any() or ae2.any(): raise RuntimeError('external rescale predicate unexpectedly active')
        out={k:[] for k in ('primary_loso_143','strict_comparable_loso_143','external_primary_39','external_strict_pressure_24')}
        for seed in SEEDS:
            pp=np.full(198,np.nan)
            for fold in FOLDS:
                te=b[fold]; tr=np.setdiff1d(n,te,assume_unique=True); pp[te]=predict(x,y,tr,te,seed)
            out['primary_loso_143'].append(met(y[primary_rows],pp[primary_rows]))
            allrows += [dict(constant=constant,evaluation='primary_loso_143',seed=seed,row_identifier=i+1,row_kind='training_row_1based',y_true=y[i],prediction=pp[i]) for i in primary_rows]
            sp=pp.copy(); st=np.unique(np.r_[b['MCGILL_LAB'],ADDED]); tr=np.setdiff1d(n,st,assume_unique=True); sp[st]=predict(x,y,tr,st,seed)
            out['strict_comparable_loso_143'].append(met(y[primary_rows],sp[primary_rows]))
            allrows += [dict(constant=constant,evaluation='strict_comparable_loso_143',seed=seed,row_identifier=i+1,row_kind='training_row_1based',y_true=y[i],prediction=sp[i]) for i in primary_rows]
            model=ExtraTreesRegressor(n_estimators=300,random_state=seed,n_jobs=1).fit(x,y); p1=model.predict(xe1);p2=model.predict(xe2)
            out['external_primary_39'].append(met(ext1[1],p1));out['external_strict_pressure_24'].append(met(ext2[1],p2))
            allrows += [dict(constant=constant,evaluation='external_primary_39',seed=seed,row_identifier=i,row_kind='external_rec_id',y_true=t,prediction=q) for i,t,q in zip(ext1[2],ext1[1],p1)]
            allrows += [dict(constant=constant,evaluation='external_strict_pressure_24',seed=seed,row_identifier=i,row_kind='external_rec_id',y_true=t,prediction=q) for i,t,q in zip(ext2[2],ext2[1],p2)]
        results[str(int(constant))]={k:{'per_seed':v,'summary':aggregate(v)} for k,v in out.items()}
    expected={'primary_loso_143':oldm1,'strict_comparable_loso_143':oldm10,**oldext}; checks={}
    for ev,old in expected.items():
        new=results['2200'][ev]['summary']
        for metric in ('r2','rmse','mae'):
            delta=float(new[metric]['mean'])-float(old[metric]['mean']); checks[f'{ev}.{metric}']={'old_mean':old[metric]['mean'],'new_mean':new[metric]['mean'],'delta':delta,'pass':abs(delta)<=TOL}
    failed=[k for k,v in checks.items() if not v['pass']]
    if failed: raise RuntimeError('2200 baseline reproduction failed: '+', '.join(failed))
    fields=['constant','evaluation','seed','row_identifier','row_kind','y_true','prediction']
    with PCSV.open('x',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(allrows)
    table=[]
    for c,evs in results.items():
        for ev,item in evs.items():
            r={'constant':c,'evaluation':ev,'n_rows':item['summary']['n_rows']}
            for m in ('r2','rmse','mae','bias'):r[m+'_mean']=item['summary'][m]['mean'];r[m+'_sd']=item['summary'][m]['sd']
            table.append(r)
    with SCSV.open('x',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
    payload={'protocol':str(PROTOCOL.relative_to(PORT)),'constants':CONSTS,'seeds':SEEDS,'model':{'class':'ExtraTreesRegressor','n_estimators':300,'n_jobs':1,'target_transform':'none','raw_columns':RAW},'source_hashes':{str(z.relative_to(PORT)):digest(z) for z in (DATA,PROV,COMMON,M1,M10,PRIMARY,EXTSTRICT,PRROWS,ESROWS,PROTOCOL,Path(__file__))},'environment':{'python':sys.version.replace('\n',' '),'platform':platform.platform(),'numpy':np.__version__,'pandas':pd.__version__},'transformation_validation':{'private_2200_sha256':local,'common_raw_rescale_sha256':source,'byte_identical':True,'training_rescale_rows':int(active.sum()),'external_rescale_rows':0},'strict_added_rows_1based':[int(z+1) for z in ADDED],'baseline_reproduction':checks,'results':results,'output_files':{'predictions':str(PCSV.relative_to(PORT)),'summary_csv':str(SCSV.relative_to(PORT))},'elapsed_seconds':time.monotonic()-start}
    with SJSON.open('x',encoding='utf-8') as f:json.dump(payload,f,indent=2);f.write('\n')
    print(json.dumps({'status':'passed','elapsed_seconds':payload['elapsed_seconds'],'outputs':payload['output_files']}))
if __name__=='__main__': main()
