# Fixed-density sensitivity protocol

## Purpose and status

This is a limited, retrospective operational sensitivity analysis of the
2,200 kg/m³ mass-rescaling constant used in the C1 raw-feature ExtraTrees
configuration. It does not estimate a physical density, recover an omitted
batch volume, validate the converted units, tune a constant, or supply new
independent evidence. The source corpus and all evaluation cohorts were
previously observed.

## Frozen design

* Constants: **2,000, 2,200, and 2,400 kg/m³**. They are fixed operational
  perturbations of 2,200 by ±200 kg/m³, not an asserted plausible range of
  true density.
* Model: `ExtraTreesRegressor(n_estimators=300, random_state=seed, n_jobs=1)`
  on the eleven raw input columns and the untransformed target. No estimator
  parameter, seed, fold, feature, cohort, or scoring rule is selected from
  these results.
* Seeds: `0, 1, ..., 9`, matching the historical `ET300|raw|none|rescale`
  configuration.
* Transformation: make a private copy of the six mass columns. If their
  recorded total is below 1,200 and `CA + FA + blast furnace slag > 0`, multiply
  all six by `constant / recorded_total`; otherwise leave every raw feature
  unchanged. This implementation is independent of `common.py` and does not
  import the original project code.
* The original flag treatment is **not altered**. It remains a separate
  unchanged-raw-input comparator and is not a fourth density constant.
* All source tables, historical outputs, manuscript files, generators and
  figures are read-only. Results live only in this directory. Python is run
  with `PYTHONDONTWRITEBYTECODE=1` and the runner never imports original C1
  modules, preventing source-tree `__pycache__` writes.

## Required equivalence check

Before fitting, the runner compares the private 2,200 transformation with
`common.make_features(training_df, "raw", "rescale")` indirectly, using an
isolated subprocess that imports the source module under
`PYTHONDONTWRITEBYTECODE=1` and serializes no source data. It compares the
SHA-256 digest of the contiguous float64 198×11 matrix; with fixed dtype,
shape and column order, equality is a byte-level elementwise equality. Any
mismatch stops the runner before fitting.

## Fixed evaluation sets

1. **Primary LOSO-143.** The historical three quantitative fold definitions:
   Taiwan (45), Shao (22), and original McGill (76), pooled on the 143 scored
   rows.
2. **Strict comparable LOSO-143.** Taiwan and Shao retain their historical
   fits. For the original 76 McGill scored rows only, the fit excludes the
   original 76 plus the fixed 15 `U_MISC_putative` rows, precisely as
   `m10_strict_mcgill.py`; metrics are again pooled on the same 143 scored
   rows. The 15 added rows are not silently added to the reported denominator.
3. **External primary pressure cohort (39 rows).** The frozen
   `primary_explicit_pressure` membership.
4. **External strict numerical-pressure cohort (24 rows).** The frozen
   `strict_numeric_point` membership.

For both external cohorts, each seed fits all 198 transformed training records
and scores the frozen external rows. The transform is applied independently to
external feature rows too; the audit established that none of the complete
external rows triggers it. No external score affects fitting or any decision.

## Outputs and validation

The runner writes one CSV of seed-level, row-level predictions for each
constant and evaluation protocol, plus an aggregate JSON and CSV. Every row
contains only row/record identifiers, seed, constant, evaluation name,
prediction and observed target. The JSON records SHA-256 hashes of all inputs,
source configuration values, predicate counts, exact fold membership,
environment versions, per-seed metrics and mean/SD summaries.

At 2,200, the runner verifies the primary LOSO-143 result against historical
M1 and the strict comparable LOSO-143 result against historical M10 within a
predeclared floating tolerance of `1e-10` per aggregate mean. It also compares
the new external aggregate to the existing frozen 2,200 seed-level rerun
artifact when present. A failure stops the run and is reported rather than
being normalized away. `n_jobs=1` is fixed to coexist with other active work;
it changes throughput only.
