# Carbonation-strength benchmark: reproducibility package

This is the public numerical and code package for version `v1.0.0` of the carbonation-cured-concrete provenance and transportability audit. It has **no DOI**. The archive preserves numerical outputs, code, figures, and source locations needed to verify the reported calculations; it does not redistribute the publisher spreadsheet, article full text, or quoted passages from source literature.

The public-release redactions and original-to-derived SHA-256 mapping are recorded in `PUBLIC_RELEASE_CHANGES.md` and `PUBLIC_RELEASE_ORIGINAL_SHA256.json` at the release root. Third-party dataset attribution is in `THIRD_PARTY_NOTICES.md`. No new license is granted by this package; users must determine permissions for code and data before reuse.

## Verification and execution

The supplied numerical results can be checked without fitting models:

    python _shared/revision_20260921/C1/verify_reproduction_outputs.py

The retained Figures 1--3 can be regenerated from included numerical results:

    python C1_crossdb_audit/manuscript/make_figures.py --internal-only

The `--internal-only` switch stops before superseded historical external figures. Use the revised plotting script below for the submitted Figures 4--5; do not substitute historical Figures 4--5, whose source-data dependencies are excluded from this package.

To refit, obtain the 198-row publisher spreadsheet from its cited provider using the information in `C1_crossdb_audit/probe/data/README.md`, independently verify any access/checksum information, and place it at the indicated path. Use the recorded package versions in `requirements-frozen.txt`. TabPFN also requires its corresponding model weights under the package's normal model-access mechanism; no credentials or downloaded weights are redistributed here.

    python _shared/revision_20260921/C1/rerun_frozen_seed_predictions.py
    python _shared/revision_20260921/C1/make_revised_figs.py

The relative directory hierarchy is intentional. Original model code and saved internal/legacy external outputs are preserved. The frozen rescaling rule assumes a total of 2,200 kg/m³ for selected normalized rows; it is not a measured density. The pressure audit defines primary and sensitivity cohorts before selecting predictions. Re-running models overwrites rerun outputs in this staging copy only; keep the included manifest as the record of the reviewed outputs.

`C1_crossdb_audit/experiment/fingerprint_check.py` reproduces the descriptive-statistic fingerprint after the original xlsx is placed in `C1_crossdb_audit/probe/data/`. `C1_crossdb_audit/manuscript/build_S2.py` is included as the archived transcription checker and requires the original xlsx plus the cited source PDFs and layout-preserving text files in `C1_crossdb_audit/probe/`; those materials are not redistributed here. The script retains a prominent warning that its generated labels predate the final manuscript alignment, so its output must not replace the submitted supplement without applying the recorded mapping.

## Map to the revised manuscript

| Manuscript item | Source |
|---|---|
| Main Table 1; supplementary S1–S2 | `experiment/fingerprint_check.json`, source-location transcription in the manuscript supplement |
| Main Table 2; study provenance | `probe/row_provenance.json` and `model_experiments/common.py` |
| Main Tables 3–5; supplementary S6 | `model_experiments/results/m1_*.json` through `m10_*.json` |
| Main Table 6; pressure cohorts | `_shared/revision_20260921/C1/pressure_audit_rows.csv` and sources CSV |
| Main Table 7; supplementary S7 | `_shared/revision_20260921/C1/rerun_*.json`, `rerun_seed_predictions.csv` |
| Supplementary Table S8.1 | `_shared/revision_20260921/C1/density_sensitivity.py`, `DENSITY_SENSITIVITY_PROTOCOL.md`, `density_sensitivity_summary.csv`, `density_sensitivity_summary.json`, and `density_sensitivity_predictions.csv` |
| Figures 1–3 | original internal results and `manuscript/make_figures.py --internal-only`; figure labels aligned to the fixed-model interpretation |
| Figures 4–5 | `_shared/revision_20260921/C1/make_revised_figs.py` |

Project-relative paths in this table are beneath `C1_crossdb_audit/` unless explicitly starting with `_shared/`. Source PDFs/full-text extracts and the publisher spreadsheet are deliberately omitted; source evidence is identified by DOI and retained locations. Source retrieval and extraction cannot be reproduced from this numerical package alone without obtaining the cited publications.
