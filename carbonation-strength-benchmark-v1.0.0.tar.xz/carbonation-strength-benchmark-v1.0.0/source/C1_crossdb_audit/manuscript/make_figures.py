#!/usr/bin/env python3
"""Figures 1-5 for C1_final.md.

Reads ONLY results already on disk (no experiment is re-run) and writes
manuscript/figures/fig{1,2,3,5}.{png,pdf} from model_experiments/results/*.json
and fig4_external_validation.{pdf,png} from external_validation/results/*.json.
Run with the model_experiments venv:
    model_experiments/.venv/bin/python manuscript/make_figures.py
CPU only, matplotlib Agg, no network.
"""

# ---- Fig. 1 -------------------------------------------------------------
import json, os
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=str(Path(__file__).resolve().parents[1])
RES=os.path.join(ROOT,"model_experiments","results"); OUT=os.path.join(ROOT,"manuscript","figures")
os.makedirs(OUT, exist_ok=True)
L=lambda n: json.load(open(os.path.join(RES,n+".json")))
M1,M2,M4,M5,M6,M7=(L(x) for x in ["m1_baseline_fe","m2_lgbm","m4_tabpfn","m5_gp_mixed","m6_uci_transfer","m7_groupdro"])
r=lambda M,k: M["runs"][k]
plt.rcParams.update({"font.size":7.5,"axes.labelsize":8,"xtick.labelsize":7.5,"ytick.labelsize":7.5,
 "legend.fontsize":7,"axes.spines.top":False,"axes.spines.right":False,
 "figure.dpi":400,"savefig.dpi":400,"savefig.bbox":"tight","font.family":"sans-serif"})
PTS=[("RF, no harmonisation (baseline)",r(M1,"RF300|raw|none"),(-0.003,0.0,"right")),
     ("RF",r(M1,"RF300|raw|none|rescale"),(-0.003,0.0,"right")),
     ("ET (fixed)",r(M1,"ET300|raw|none|rescale"),(-0.004,0.022,"right")),
     ("ET, no harmonisation",r(M1,"ET300|raw|none"),None),
     ("ET, physics features",r(M1,"ET300|phys_d|none|rescale"),(-0.003,0.0,"right")),
     ("HGB",r(M1,"HGB|raw|none|rescale"),(-0.003,-0.004,"right")),
     ("HGB, no harmonisation",r(M1,"HGB|raw|none"),(0.002,0.008,"left")),
     ("LGBM-mono",r(M2,"LGBM-mono|raw|none|rescale|nested"),(0.003,0.006,"left")),
     ("LGBM",r(M2,"LGBM|raw|none|rescale|nested"),None),
     ("TabPFN",r(M4,"TabPFN|raw|none|flag"),(0.003,-0.006,"left")),
     ("GP, study-block kernel",r(M5,"GP-block(study)|ratio_d|log"),(0.004,0.0,"left")),
     ("ET + UCI feature",r(M6,"1|ET raw + uci_pred"),None),
     ("ET, study-balanced",r(M7,"ET|balanced 1/sqrt(n_g)"),None),
     ("Ridge, physics features",r(M1,"Ridge|phys_d|none"),(0.005,0.0,"left"))]
fig,ax=plt.subplots(figsize=(4.7,3.3))
xs=[];ys=[]
for nm,d,lab in PTS:
    x=d["rand"]["all198"]["r2"]["mean"]; y=d["loso"]["pooled"]["r2"]["mean"]; xs.append(x); ys.append(y)
    star=nm.startswith("ET (fixed")
    ax.scatter(x,y,s=90 if star else 22,marker="*" if star else "o",zorder=4,
               color="#c0392b" if star else "#2c3e50",edgecolor="white" if star else "none",linewidth=0.5)
    if lab:
        dx,dy,ha=lab
        ax.annotate(nm,(x+dx,y+dy),ha=ha,va="center",fontsize=6.4,color="#34495e",zorder=5)
ax.plot([0.3,1.0],[0.3,1.0],ls=":",lw=0.8,color="#b2bec3",zorder=1)
ax.annotate("equal performance",(0.905,0.925),rotation=41,fontsize=6.0,color="#95a5a6",ha="center")
# range brackets over the dense group (all tree/foundation models, harmonised or not)
grp=[(x,y) for (nm,d,_),x,y in zip(PTS,xs,ys) if "Ridge" not in nm and "GP" not in nm]
gx=[p[0] for p in grp]; gy=[p[1] for p in grp]
ax.axvspan(min(gx),max(gx),color="#3498db",alpha=0.07,zorder=0)
ax.axhspan(min(gy),max(gy),color="#3498db",alpha=0.07,zorder=0)
ax.annotate(f"random-split range {max(gx)-min(gx):.3f}",(sum(gx)/len(gx),0.225),
            fontsize=6.4,color="#2471a3",ha="center")
ax.annotate(f"LOSO range\n{max(gy)-min(gy):.3f}",(0.638,(min(gy)+max(gy))/2),
            fontsize=6.4,color="#2471a3",ha="center",va="center")
ax.set_xlabel("Random five-fold $R^2$  (all 198 rows, literature protocol)")
ax.set_ylabel("Leave-one-study-out pooled $R^2$  (143 held-out rows)")
ax.set_xlim(0.60,1.005); ax.set_ylim(0.18,1.005)
ax.grid(alpha=0.16,lw=0.5); ax.set_axisbelow(True)
fig.savefig(os.path.join(OUT,"fig1_protocol_scatter.png")); fig.savefig(os.path.join(OUT,"fig1_protocol_scatter.pdf"))
print("range x", min(gx), max(gx), "=> ", round(max(gx)-min(gx),3))
print("range y", min(gy), max(gy), "=> ", round(max(gy)-min(gy),3))

# ---- Figs. 2 and 3 ------------------------------------------------------

CP = json.load(open(os.path.join(RES,'m8_ensemble_conformal.json')))['conformal_pooled']
M8={'conformal_pooled':CP}
M3=L('m3_extratrees'); M10=L('m10_strict_mcgill')
import numpy as np
# ---------------------------------------------------------------- Fig. 2
# conformal: empirical coverage and mean width, two calibration regimes

models = ["ET300 raw", "HGB raw", "LGBM-mono raw", "TabPFN raw"]
short = {"ET300 raw": "ET", "HGB raw": "HGB", "LGBM-mono raw": "LGBM-mono",
         "TabPFN raw": "TabPFN", "stack-NNLS": "stack"}
def get(m, c, a, k):
    for r in CP:
        if r["model"] == m and r["calib"] == c and abs(r["alpha"] - a) < 1e-9:
            return r[k]
    return None

fig, axes = plt.subplots(1, 2, figsize=(6.2, 2.7))
import numpy as np
xs = np.arange(len(models))
w = 0.36
for ax, key, a in ((axes[0], "coverage", 0.1), (axes[1], "width", 0.1)):
    v_logo = [get(m, "LOGO", a, key) for m in models]
    v_rand = [get(m, "random5fold", a, key) for m in models]
    ax.bar(xs - w / 2, v_logo, w, color="#2c3e50", label="cross-study calibration")
    ax.bar(xs + w / 2, v_rand, w, color="#e67e22", label="random-split calibration")
    ax.set_xticks(xs)
    ax.set_xticklabels([short[m] for m in models], rotation=20, ha="right")
    ax.grid(axis="y", alpha=0.18, lw=0.5)
    ax.set_axisbelow(True)
    print(f"  Fig2 {key}: LOGO={['%.2f' % x for x in v_logo]} rand={['%.2f' % x for x in v_rand]}")
axes[0].axhline(0.9, ls="--", lw=0.9, color="#c0392b")
axes[0].annotate("nominal 0.90", (len(models) - 0.45, 0.915), fontsize=6.6,
                 color="#c0392b", ha="right")
axes[0].set_ylabel("Empirical coverage on held-out studies")
axes[0].set_ylim(0, 1.12)
axes[1].set_ylabel("Mean interval width (MPa)")
axes[1].set_ylim(0, 52)
axes[0].set_title("(a) Coverage of nominal 90% intervals", loc="left")
axes[1].set_title("(b) Width of the same intervals", loc="left")
axes[0].legend(loc="lower center", frameon=False, ncol=1)
fig.savefig(os.path.join(OUT, "fig3_conformal.png"))
fig.savefig(os.path.join(OUT, "fig3_conformal.pdf"))
plt.close(fig)


# ---- Fig. 3 ----
MAIN={"RF300 raw flag (原基线)":r(M1,"RF300|raw|none"),"RF300 raw rescale":r(M1,"RF300|raw|none|rescale"),
 "ET300 raw rescale (leaf=1)":r(M3,"B|ET min_samples_leaf=1"),"ET300 raw rescale leaf=3":r(M3,"B|ET min_samples_leaf=3"),
 "ET300 raw rescale leaf=5":r(M3,"B|ET min_samples_leaf=5"),"ET300 raw rescale max_features=1/3":r(M3,"A|ET max_features=1/3"),
 "HGB raw rescale":r(M1,"HGB|raw|none|rescale"),"LGBM-mono raw rescale":r(M2,"LGBM-mono|raw|none|rescale|fixed"),
 "ET300 phys_d rescale":r(M1,"ET300|phys_d|none|rescale"),"ET300 ratio_d rescale":r(M1,"ET300|ratio_d|none"),
 "TabPFN raw rescale":r(M4,"TabPFN|raw|none|rescale"),"TabPFN phys_d rescale":r(M4,"TabPFN|phys_d|none|rescale")}
NICE={"RF300 raw flag (原基线)":"RF, no harmonisation (baseline)","RF300 raw rescale":"RF",
 "ET300 raw rescale (leaf=1)":"ET, leaf 1 (fixed)","ET300 raw rescale leaf=3":"ET, leaf 3",
 "ET300 raw rescale leaf=5":"ET, leaf 5","ET300 raw rescale max_features=1/3":"ET, max_features 1/3",
 "HGB raw rescale":"HGB","LGBM-mono raw rescale":"LGBM-mono","ET300 phys_d rescale":"ET, physics features",
 "ET300 ratio_d rescale":"ET, ratio features","TabPFN raw rescale":"TabPFN","TabPFN phys_d rescale":"TabPFN, physics features"}
rows=[]
for k,v in M10["runs"].items():
    mn=MAIN.get(k)
    if mn is None: continue
    rows.append((NICE[k],mn["loso"]["pooled"]["r2"]["mean"],v["loso"]["pooled143_comparable"]["r2"]["mean"]))
rows.sort(key=lambda t:-t[1])
fig,ax=plt.subplots(figsize=(4.9,3.2))
ys=np.arange(len(rows))[::-1]
for y,(n,a,b) in zip(ys,rows):
    ax.plot([a,b],[y,y],color="#cfd6da",lw=1.2,zorder=1)
    ax.scatter(a,y,s=24,color="#2c3e50",zorder=3)
    ax.scatter(b,y,s=24,color="#c0392b",marker="D",zorder=3)
ax.set_yticks(ys); ax.set_yticklabels([t[0] for t in rows])
ax.axvline(0,color="#7f8c8d",lw=0.8)
ax.scatter([],[],s=24,color="#2c3e50",label="primary fold definition")
ax.scatter([],[],s=24,color="#c0392b",marker="D",label="strict fold definition (+15 rows held out)")
ax.legend(loc="lower left",bbox_to_anchor=(0.0,1.01),ncol=2,frameon=False,handletextpad=0.3,columnspacing=1.2)
ax.set_xlabel("Leave-one-study-out pooled $R^2$  (same 143 scored rows)")
ax.set_xlim(-0.30,0.95); ax.set_ylim(-0.8,len(rows)-0.2)
ax.grid(axis="x",alpha=0.16,lw=0.5); ax.set_axisbelow(True)
fig.savefig(os.path.join(OUT,"fig2_strict_sensitivity.png")); fig.savefig(os.path.join(OUT,"fig2_strict_sensitivity.pdf"))
print("ok", len(rows))

import sys
if "--internal-only" in sys.argv:
    raise SystemExit(0)

# ---- Fig. 4: external validation -----------------------------------------
# Regenerated here (it used to be copied from external_validation/, which is a
# 292 mm-wide working figure whose type falls below 7 pt once scaled to a
# two-column width).  Source of every number: external_validation/results/
# extval_tierA.json, plus the 198 training rows via model_experiments/common.py.
# Vector PDF + 600 dpi PNG at exactly 190 mm; Okabe-Ito colours with marker
# redundancy so the panel survives greyscale printing.
import sys
import pandas as pd
_RC = dict(plt.rcParams)
EV = os.path.join(ROOT, "external_validation")
sys.path.insert(0, os.path.join(ROOT, "model_experiments"))
import common as C                                    # noqa: E402  (198 training rows)

JX = json.load(open(os.path.join(EV, "results", "extval_tierA.json")))
XROWS = pd.DataFrame(JX["external_rows"])
REC = "ET300 raw rescaled (recommended)"
xpred = np.asarray(JX["runs"][REC]["pred_mean"], float)
xmeas = pd.to_numeric(XROWS["CS"], errors="coerce").values
xlab = XROWS["lab_id"].astype(str).values
xr2 = JX["runs"][REC]["all"]["r2"]["mean"]
xrmse = JX["runs"][REC]["all"]["rmse"]["mean"]
N_EXT, N_IN = JX["n_external_complete"], JX["n_in_window"]

# --- assertions: every number printed on Fig. 4 against the result file and
#     against the Fig. 4 caption / Sections 6.1 and 6.3 of C1_final.md.
assert len(xmeas) == len(xpred) == len(XROWS) == N_EXT == 73, (len(xmeas), N_EXT)
assert set(XROWS["tier"]) == {"A_complete"}, set(XROWS["tier"])
assert abs(xr2 - 0.007) < 5e-4, xr2                      # "+0.007" (Section 6, Table 8)
assert abs(xrmse - 18.5) < 5e-2, xrmse                   # "RMSE 18.5 MPa"
assert abs(xmeas.min() - 5.79) < 5e-3 and abs(xmeas.max() - 65.9) < 5e-3, \
    (xmeas.min(), xmeas.max())                           # "5.8 to 65.9 MPa"
assert abs(xmeas.mean() - 31.61) < 5e-3, xmeas.mean()    # "external strength mean 31.61"
assert abs(xpred.min() - 28.91) < 5e-3, xpred.min()      # lower end of the predicted band
assert N_IN == 12, N_IN                                  # "only 12 of 73 rows"
assert int((XROWS["_inwin"].astype(str).str.lower().isin(["true", "1"])).sum()) == N_IN
assert C._df.shape == (198, 12) and list(C.RAW_COLS) == list(C._df.columns[:11])
N_OUT = {c: JX["window"][c]["n_outside"] for c in C.RAW_COLS}
assert N_OUT == {"C": 12, "CA": 5, "FA": 0, "W": 0, "blast furnace slag": 0,
                 "fly ash": 0, "W/B": 0, "CCU-steam curing time": 10,
                 "T": 41, "CC": 34, "P": 0}, N_OUT
# Section 6.2: carbonation duration 1-48 h in training against 672 h externally;
# CO2 volume fraction down to 0.05 against a training minimum of 0.20; steam
# pre-curing to 8 h against a training maximum of 4 h.
assert (C._df["T"].min(), C._df["T"].max()) == (1, 48), (C._df["T"].min(), C._df["T"].max())
assert abs(pd.to_numeric(XROWS["T"], errors="coerce").max() - 672) < 1e-9
assert abs(C._df["CC"].min() - 0.20) < 1e-9 and \
    abs(pd.to_numeric(XROWS["CC"], errors="coerce").min() - 0.05) < 1e-9
assert C._df["CCU-steam curing time"].max() == 4 and \
    pd.to_numeric(XROWS["CCU-steam curing time"], errors="coerce").max() == 8
LABS = sorted(set(xlab), key=lambda L: (-(xlab == L).sum(), L))
assert sum((xlab == L).sum() for L in LABS) == N_EXT and len(LABS) == 7, LABS
print(f"  Fig4 n={N_EXT} R2={xr2:+.4f} RMSE={xrmse:.2f} in-window={N_IN} labs={len(LABS)}")
print(f"  Fig4 predicted band {xpred.min():.2f}-{xpred.max():.2f} MPa, "
      f"measured {xmeas.min():.2f}-{xmeas.max():.2f} MPa")

MM = 1 / 25.4
OKABE = ["#0072B2", "#D55E00", "#009E73", "#E69F00", "#CC79A7", "#56B4E9", "#000000"]
MARK = ["o", "s", "^", "D", "v", "P", "X"]
plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "mathtext.fontset": "custom", "mathtext.default": "regular",
    "mathtext.rm": "Arial", "mathtext.it": "Arial:italic", "mathtext.bf": "Arial:bold",
    "font.size": 7.5, "axes.labelsize": 8.0, "axes.titlesize": 8.0,
    "xtick.labelsize": 7.0, "ytick.labelsize": 7.0, "legend.fontsize": 7.0,
    "axes.linewidth": 0.6, "axes.spines.top": False, "axes.spines.right": False,
    "savefig.dpi": 600, "figure.dpi": 200, "savefig.bbox": None,
    "pdf.fonttype": 42, "ps.fonttype": 42,
})
fig, axx = plt.subplots(1, 2, figsize=(190 * MM, 88 * MM), constrained_layout=True,
                        gridspec_kw=dict(width_ratios=[1.0, 1.08]))

# (a) measured against predicted, coloured by laboratory cluster
ax = axx[0]
hi = max(xmeas.max(), xpred.max()) * 1.08
ax.plot([0, hi], [0, hi], "-", lw=0.9, color="0.25", zorder=2)
for d in (10, -10):
    ax.plot([0, hi], [d, hi + d], "--", lw=0.7, color="0.55", zorder=2)
for i, L in enumerate(LABS):
    m = xlab == L
    ax.scatter(xmeas[m], xpred[m], s=20, marker=MARK[i], facecolor=OKABE[i],
               edgecolor="black", linewidth=0.35, alpha=0.9, zorder=4,
               label=f"{L} ($\\mathit{{n}}$ = {int(m.sum())})")
ax.set_xlim(0, hi); ax.set_ylim(0, hi)
ax.set_aspect("equal", adjustable="box")
ax.set_xlabel("Measured compressive strength [MPa]")
ax.set_ylabel("Predicted compressive strength [MPa]")
ax.annotate(f"$\\mathit{{n}}$ = {N_EXT},  $\\mathit{{R}}^2$ = {xr2:+.3f},  RMSE = {xrmse:.1f} MPa",
            (0.035, 0.965), xycoords="axes fraction", va="top", fontsize=7.5)
ax.annotate("equality", (0.62 * hi, 0.62 * hi), rotation=45, rotation_mode="anchor",
            ha="left", va="bottom", fontsize=7.0, color="0.25")
ax.annotate("$\\pm$10 MPa", (0.14 * hi, 0.14 * hi + 10), rotation=45,
            rotation_mode="anchor", ha="left", va="bottom", fontsize=7.0, color="0.55")
ax.legend(loc="lower right", frameon=False, handletextpad=0.25, labelspacing=0.3,
          borderaxespad=0.3)
ax.grid(alpha=0.16, lw=0.5); ax.set_axisbelow(True)
ax.set_title("(a) External records, ExtraTrees fixed from this paper", loc="left")

# (b) position of each external row within the range spanned by the 198 rows
ax = axx[1]
PRETTY = {"C": "Cement (C)", "CA": "Coarse aggregate (CA)", "FA": "Fine aggregate (FA)",
          "W": "Water (W)", "blast furnace slag": "Blast-furnace slag",
          "fly ash": "Fly ash", "W/B": "Water/binder (W/B)",
          "CCU-steam curing time": "Steam pre-curing [h]",
          "T": "Carbonation duration $\\mathit{T}$ [h]",
          "CC": "CO$_2$ volume fraction (CC)",
          "P": "Carbonation pressure $\\mathit{P}$ [MPa]"}
for k, col in enumerate(C.RAW_COLS):
    lo, hi_ = float(C._df[col].min()), float(C._df[col].max())
    ax.plot([0, 1], [k, k], color="0.25", lw=4.2, solid_capstyle="butt", zorder=3,
            label="range of the 198 rows" if k == 0 else None)
    ev = pd.to_numeric(XROWS[col], errors="coerce").values
    pos = np.clip((ev - lo) / (hi_ - lo) if hi_ > lo else np.zeros_like(ev), -0.35, 1.35)
    ax.scatter(pos, np.full(len(pos), k) + 0.30, s=11, marker="o", facecolor="none",
               edgecolor="#D55E00", linewidth=0.6, alpha=0.85, zorder=4,
               label="external rows" if k == 0 else None)
    ax.text(1.62, k + 0.15, f"{N_OUT[col]:d}", fontsize=7.0, va="center", ha="right",
            color="#D55E00" if N_OUT[col] else "0.45")
ax.text(1.62, -1.02, "rows\noutside", fontsize=7.0, va="center", ha="right", color="0.3")
ax.axvline(0, color="0.7", lw=0.6, zorder=1); ax.axvline(1, color="0.7", lw=0.6, zorder=1)
ax.set_yticks(range(len(C.RAW_COLS)))
ax.set_yticklabels([PRETTY[c] for c in C.RAW_COLS])
ax.set_ylim(len(C.RAW_COLS) + 0.8, -1.6)
ax.set_xlim(-0.5, 1.68)
ax.set_xticks([0, 0.5, 1.0])
ax.set_xticklabels(["0\n(minimum)", "0.5", "1\n(maximum)"])
ax.set_xlabel("Position within the range spanned by the 198 training rows")
ax.text(-0.45, len(C.RAW_COLS) + 0.4,
        f"only {N_IN} of {N_EXT} external rows are inside on all eleven variables",
        fontsize=7.0, va="center", ha="left")
ax.legend(loc="upper left", bbox_to_anchor=(0.0, 1.0), frameon=False, ncol=2,
          handletextpad=0.35, columnspacing=1.0, borderaxespad=0.2)
ax.grid(axis="x", alpha=0.16, lw=0.5); ax.set_axisbelow(True)
ax.set_title("(b) Process-window overlap", loc="left")

fig.savefig(os.path.join(OUT, "fig4_external_validation.pdf"))
fig.savefig(os.path.join(OUT, "fig4_external_validation.png"))
plt.close(fig)
plt.rcParams.update(_RC)
print("  wrote fig4_external_validation.pdf / .png (190 mm wide)")

# ---- Fig. 5: the collapse across protocols ----
plt.rcParams.update({"font.size":7.5,"axes.labelsize":8,"xtick.labelsize":7.2,"ytick.labelsize":7.5,
 "legend.fontsize":7,"axes.spines.top":False,"axes.spines.right":False,
 "figure.dpi":400,"savefig.dpi":400,"savefig.bbox":"tight","font.family":"sans-serif"})
steps=["Random\nfive-fold","LOSO,\nprimary folds","LOSO, selection\nalso held out","LOSO,\nstrict folds","External\nstudies\n(tier A)","External\nstudies\n(tier A+B)"]
rec=[0.957,0.825,None,0.347,0.007,-0.376]          # recommended ExtraTrees
base=[0.953,0.497,None,-0.166,-0.045,-0.253]       # RF baseline
best=[0.965,0.856,0.573,0.574,0.142,-0.220]        # best available at each step
x=list(range(len(steps)))
fig,ax=plt.subplots(figsize=(5.4,3.1))
ax.axhspan(0.65,1.05,color="#27ae60",alpha=0.06,zorder=0)
ax.axhline(0.65,ls="--",lw=0.9,color="#27ae60",zorder=1)
ax.annotate("pre-specified criterion  $R^2$ = 0.65",(5.42,0.675),fontsize=6.4,color="#1e8449",ha="right")
ax.axhline(0.0,lw=0.9,color="#7f8c8d",zorder=1)
ax.annotate("a constant predictor",(-0.3,0.035),fontsize=6.4,color="#7f8c8d",ha="left")
def series(v,c,m,lab,lw=1.6,ls="-"):
    xs=[i for i,y in enumerate(v) if y is not None]; ys=[y for y in v if y is not None]
    ax.plot(xs,ys,ls,color=c,lw=lw,marker=m,ms=5,zorder=3,label=lab,clip_on=False)
series(best,"#95a5a6","^","best configuration available",1.1,"--")
series(rec,"#c0392b","o","recommended ExtraTrees (fixed)")
series(base,"#2c3e50","s","random-forest baseline")
for i,y in enumerate(rec):
    if y is None: continue
    off={0:(0,10,"center","bottom"),1:(0,10,"center","bottom"),3:(0,11,"center","bottom"),4:(-9,6,"right","center"),5:(-9,-4,"right","center")}.get(i,(0,10,"center","bottom"))
    ax.annotate(f"{y:+.3f}".replace("-","−"),(i,y),textcoords="offset points",xytext=off[:2],ha=off[2],va=off[3],fontsize=6.6,color="#c0392b",fontweight="bold",zorder=6)
ax.axvspan(3.5,5.5,color="#e67e22",alpha=0.07,zorder=0)
ax.annotate("data from outside\nthe shared table",(4.5,-0.60),fontsize=6.6,color="#b9770e",ha="center")
ax.set_xticks(x); ax.set_xticklabels(steps)
ax.set_ylabel("$R^2$ on the rows being scored")
ax.set_xlim(-0.35,5.45); ax.set_ylim(-0.72,1.05)
ax.grid(axis="y",alpha=0.16,lw=0.5); ax.set_axisbelow(True)
ax.legend(loc="lower left",bbox_to_anchor=(0.0,-0.02),frameon=False)
fig.savefig(os.path.join(OUT,"fig5_collapse.png")); fig.savefig(os.path.join(OUT,"fig5_collapse.pdf"))
print("ok")
