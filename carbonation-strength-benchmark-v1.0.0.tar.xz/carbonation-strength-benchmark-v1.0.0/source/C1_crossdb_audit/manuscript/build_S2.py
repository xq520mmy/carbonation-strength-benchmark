# ============================================================================
# SUPERSEDED — DO NOT RE-RUN WITHOUT RE-APPLYING THE 2026-09-19 RELABELLING.
#
# This script generated the supplement as it stood on 2026-09-17, using the
# audit-era citation numbers [9]/[10]/[11]/[12] and the project-internal labels
# CSCM2025 / Buildings2026 / SciRep2026 / IJCSM2026, and writing to
# S2_full_statistics.md + S2_transcription_log.md.
#
# On 2026-09-19 the supplement was aligned with the current manuscript:
#   file   S2_full_statistics.md  ->  S1_full_statistics.md   (internal S2.x -> S1.x)
#   label  CSCM2025    [9]        ->  [4]   Chu et al.,        Case Stud. Constr. Mater. 22 (2025) e04589
#   label  Buildings2026 [10]     ->  [5]   Wang et al.,       Buildings 16 (2025) 89
#   label  SciRep2026  [11]       ->  [6]   Alsharedah & Wani, Sci. Rep. (2026), in press
#   label  IJCSM2026   [12]       ->  [7]   Han et al.,        Int. J. Concr. Struct. Mater. 20 (2026) 86
#   xref   "Section 3.2" -> "Section 3.1";  Table 1 footnote marker "†" -> "a"
#
# Re-running this file as-is would overwrite the aligned supplement with the
# stale one. Its value now is the mechanical check that every transcribed token
# appears on its cited pdftotext line; if that check must be re-run, apply the
# mapping above to its output before shipping. See REVISION_NOTES_REFRAME.md 6b.
# ============================================================================

# Build S2_full_statistics.md and S2_transcription_log.md.
# Printed values below were transcribed by hand from the PDFs (verified against 200-dpi page renders).
# Every transcribed token is re-checked mechanically against the cited `pdftotext -layout -f N -l N` line
# before anything is written. Computed columns come straight from pandas (the only computation permitted).
import subprocess, sys, textwrap
from pathlib import Path
import pandas as pd

ROOT = str(Path(__file__).resolve().parents[1])
SRC  = f"{ROOT}/probe/sources"
XLSX = f"{ROOT}/probe/data/scirep_MOESM1.xlsx"
OUT_S2  = f"{ROOT}/manuscript/S2_full_statistics.md"
OUT_LOG = f"{ROOT}/manuscript/S2_transcription_log.md"

# ----------------------------------------------------------------------------------------------
# 1. Transcribed printed values.  Row keys = xlsx column names.  Values are STRINGS exactly as printed.
#    page = PDF page index (1-based, as pdftotext -f/-l counts it); line = line number within that page's
#    `pdftotext -layout` output; txt = line number in the pre-extracted probe/sources/<paper>.txt.
# ----------------------------------------------------------------------------------------------
PAPERS = {
  "CSCM2025": dict(
    pdf="cscm.pdf", txt="cscm.txt", page=2, folio="2",
    table="Table 1 'Input and output variables in the dataset.'",
    header_line=56, header="Type / Variable / Unit / Label / Max. / Min. / Mean / SD", txt_header=128,
    stats=["Max", "Min", "Mean", "SD"],
    rows={  # key: (variable as printed, unit as printed, label as printed, {stat: printed}, page-line, txt-line)
      "C":   ("Cement",               "kg/m³", "C",   {"Max":"719",   "Min":"100",    "Mean":"354.3", "SD":"171.8"}, 58, 130),
      "CA":  ("Coarse aggregate",     "kg/m³", "CA",  {"Max":"1600",  "Min":"0",      "Mean":"481.3", "SD":"460.4"}, 59, 131),
      "FA":  ("Fine aggregate",       "kg/m³", "FA",  {"Max":"2227",  "Min":"0",      "Mean":"881.3", "SD":"570.2"}, 60, 132),
      "W/B": ("Water-binder ratio",   "-",     "W/B", {"Max":"0.699", "Min":"0.160",  "Mean":"0.464", "SD":"0.143"}, 61, 133),
      "T":   ("CO2 curing duration",  "h",     "T",   {"Max":"48",    "Min":"1",      "Mean":"6.4",   "SD":"7.4"},   62, 134),
      "P":   ("CO2 pressure",         "MPa",   "P",   {"Max":"0.8",   "Min":"0.0014", "Mean":"0.207", "SD":"0.166"}, 63, 135),
      "CC":  ("CO2 concentration",    "%",     "CC",  {"Max":"100",   "Min":"20",     "Mean":"84.5",  "SD":"28.6"},  64, 136),
      "CS":  ("Compressive strength", "MPa",   "CS",  {"Max":"81.89", "Min":"1.61",   "Mean":"32.23", "SD":"18.79"}, 65, 137),
    }),
  "Buildings2026": dict(
    pdf="buildings.pdf", txt="buildings.txt", page=7, folio="7 of 17",
    table="Table 1. 'Input and output variables in the dataset.'",
    header_line=45, header="Type / Variable / Unit / Label / Max. / Min. / Mean / SD", txt_header=398,
    stats=["Max", "Min", "Mean", "SD"],
    rows={
      "C":   ("Cement",               "kg/m³", "C",   {"Max":"719",   "Min":"100",    "Mean":"354.3", "SD":"171.18"}, 46, 399),
      "CA":  ("Coarse aggregate",     "kg/m³", "CA",  {"Max":"1600",  "Min":"0",      "Mean":"481.3", "SD":"460.4"},  47, 400),
      "FA":  ("Fine aggregate",       "kg/m³", "FA",  {"Max":"2227",  "Min":"0",      "Mean":"881.3", "SD":"570.2"},  48, 401),
      "W/B": ("Water–binder ratio",   "-",     "W/B", {"Max":"0.699", "Min":"0.160",  "Mean":"0.464", "SD":"0.143"},  49, 402),
      "T":   ("CO2 curing time",      "h",     "T",   {"Max":"48",    "Min":"1",      "Mean":"6.4",   "SD":"7.4"},    50, 403),
      "P":   ("CO2 pressure",         "MPa",   "P",   {"Max":"0.8",   "Min":"0.0014", "Mean":"0.207", "SD":"0.166"},  51, 404),
      "CC":  ("CO2 concentration",    "%",     "CC",  {"Max":"100",   "Min":"20",     "Mean":"84.5",  "SD":"28.6"},   52, 405),
      "CS":  ("Compressive strength", "MPa",   "CS",  {"Max":"81.89", "Min":"1.61",   "Mean":"32.23", "SD":"18.79"},  54, 407),
    }),
  "SciRep2026": dict(
    pdf="scirep.pdf", txt="scirep.txt", page=12, folio="11; manuscript line 232",
    table="Table 2: 'Detailed description and statistical characteristics'",
    header_line=9, header="Variables / Mean / Std / Min / Max / Skewness", txt_header=635,
    stats=["Mean", "SD", "Min", "Max", "Skewness"],
    rows={
      "C":                     ("C (kg/m³)",                  None, None, {"Mean":"354.275","SD":"172.218","Min":"100.000","Max":"719.000", "Skewness":"0.874"},  10, 636),
      "CA":                    ("CA (kg/m³)",                 None, None, {"Mean":"481.330","SD":"461.530","Min":"0.000",  "Max":"1600.000","Skewness":"0.294"},  11, 637),
      "FA":                    ("FA (kg/m³)",                 None, None, {"Mean":"881.336","SD":"571.633","Min":"0.000",  "Max":"2227.000","Skewness":"0.201"},  12, 638),
      "W/B":                   ("W/B",                        None, None, {"Mean":"0.464",  "SD":"0.143",  "Min":"0.160",  "Max":"0.699",   "Skewness":"0.451"},  13, 639),
      "W":                     ("W (kg/m³)",                  None, None, {"Mean":"153.746","SD":"63.183", "Min":"56.000", "Max":"252.000", "Skewness":"0.048"},  14, 640),
      "P":                     ("P (%)",                      None, None, {"Mean":"0.207",  "SD":"0.166",  "Min":"0.001",  "Max":"0.800",   "Skewness":"1.302"},  15, 641),
      "blast furnace slag":    ("blast furnace slag (kg/m³)", None, None, {"Mean":"212.525","SD":"524.996","Min":"0.000",  "Max":"1510.000","Skewness":"2.074"},  16, 642),
      "fly ash":               ("fly ash (kg/m³)",            None, None, {"Mean":"0.909",  "SD":"9.022",  "Min":"0.000",  "Max":"90.000",  "Skewness":"9.873"},  17, 643),
      "CCU-steam curing time": ("CCU-steam curing time (h)",  None, None, {"Mean":"0.051",  "SD":"0.424",  "Min":"0.000",  "Max":"4.000",   "Skewness":"8.756"},  18, 644),
      "T":                     ("T (h)",                      None, None, {"Mean":"6.384",  "SD":"7.437",  "Min":"1.000",  "Max":"48.000",  "Skewness":"2.706"},  19, 645),
      "CC":                    ("CC (%)",                     None, None, {"Mean":"0.845",  "SD":"0.286",  "Min":"0.200",  "Max":"1.000",   "Skewness":"-1.620"}, 20, 646),
      "CS":                    ("CS (MP)a",                   None, None, {"Mean":"32.229", "SD":"18.840", "Min":"1.610",  "Max":"81.890",  "Skewness":"0.707"},  21, 647),
    }),
}

IJCSM = dict(
  pdf="ijcsm.pdf", txt="ijcsm.txt", page=4, folio="Page 4 of 16",
  table="Table 1 'Database used for LSBoost model training'",
  header_lines="23–24", header="(blank) / Unit / Minimum / Maximum / Average / Standard deviation", txt_header="193–194",
  rows=[  # (type, variable as printed, unit, Minimum, Maximum, Average, SD, page-line, txt-line)
    ("Input",  "Steinour formula",              "%",     "24.3", "97.6", "49.7",  "11.8",  26, 196),
    ("Input",  "w/b",                           "–",     "0.3",  "0.7",  "0.5",   "0.1",   27, 197),
    ("Input",  "s/b",                           "–",     "1",    "3",    "2.2",   "0.8",   28, 198),
    ("Input",  "RH for pre-conditioning",       "%",     "50",   "99",   "63.5",  "13.5",  29, 199),
    ("Input",  "Duration for pre-conditioning", "hours", "6",    "288",  "43.7",  "75.0",  30, 200),
    ("Input",  "CO2 concentration",             "%",     "0",    "99.9", "31.0",  "40.1",  31, 201),
    ("Input",  "CO2 pressure",                  "MPa",   "0",    "0.41", "0.02",  "0.08",  32, 202),
    ("Input",  "RH for CO2 curing",             "%",     "0",    "98",   "39.2",  "35.9",  33, 203),
    ("Input",  "CO2 curing duration",           "hours", "0",    "2160", "166.5", "354.4", 34, 204),
    ("Input",  "Curing age",                    "days",  "2",    "91",   "20.9",  "21.0",  35, 205),
    ("Output", "Compressive strength",          "MPa",   "1.7",  "97.9", "31.7",  "16.8",  36, 206),
    ("Output", "CO2 uptake",                    "%",     "0",    "56.6", "9.5",   "13.9",  37, 207),
  ])

# Row order for the main table (SciRep2026's order = the superset; CS last).
ORDER = ["C","CA","FA","W/B","W","P","blast furnace slag","fly ash","CCU-steam curing time","T","CC","CS"]
ROWNAME = {
  "C":"C — cement (kg/m³)", "CA":"CA — coarse aggregate (kg/m³)", "FA":"FA — fine aggregate (kg/m³)",
  "W/B":"W/B — water–binder ratio (–)", "W":"W — water (kg/m³)", "P":"P — CO2 pressure",
  "blast furnace slag":"blast furnace slag (kg/m³)", "fly ash":"fly ash (kg/m³)",
  "CCU-steam curing time":"CCU-steam curing time (h)", "T":"T — CO2 curing duration/time (h)",
  "CC":"CC — CO2 concentration", "CS":"CS — 28-day compressive strength (MPa)"}

# ----------------------------------------------------------------------------------------------
# 2. Mechanical re-check of every transcribed token against the cited pdftotext line.
# ----------------------------------------------------------------------------------------------
def page_lines(pdf, page):
    out = subprocess.run(["pdftotext","-layout","-f",str(page),"-l",str(page),f"{SRC}/{pdf}","-"],
                         capture_output=True, text=True, check=True).stdout
    return out.split("\n")

problems = []
checked = 0
for name, P in PAPERS.items():
    lines = page_lines(P["pdf"], P["page"])
    for key, (var, unit, label, vals, ln, txtln) in P["rows"].items():
        toks = lines[ln-1].split()
        for stat, v in vals.items():
            checked += 1
            if v not in toks:
                problems.append(f"{name} {key} {stat}={v!r} not found on page {P['page']} line {ln}: {lines[ln-1].strip()!r}")
lines = page_lines(IJCSM["pdf"], IJCSM["page"])
for (typ, var, unit, mn, mx, av, sd, ln, txtln) in IJCSM["rows"]:
    toks = lines[ln-1].split()
    for v in (mn, mx, av, sd):
        checked += 1
        if v not in toks:
            problems.append(f"IJCSM2026 {var} {v!r} not found on page 4 line {ln}: {lines[ln-1].strip()!r}")
if problems:
    print("TRANSCRIPTION RE-CHECK FAILED:"); print("\n".join(problems)); sys.exit(1)
print(f"re-check OK: {checked} transcribed tokens each found on their cited pdftotext line")

# ----------------------------------------------------------------------------------------------
# 3. Computed values (the only computation permitted).
# ----------------------------------------------------------------------------------------------
df = pd.read_excel(XLSX)
assert df.shape == (198, 12), df.shape
assert list(df.columns) == ["C","CA","FA","W","blast furnace slag","fly ash","W/B","CCU-steam curing time","T","CC","P","CS"]
comp = pd.DataFrame({"Min": df.min(), "Max": df.max(), "Mean": df.mean(),
                     "SD0": df.std(ddof=0), "SD1": df.std(ddof=1)})
f4 = lambda x: f"{x:.4f}"
fp = lambda x: f"{x:.10g}"

# ----------------------------------------------------------------------------------------------
# 4. S2_full_statistics.md
# ----------------------------------------------------------------------------------------------
def cell(paper, key, stat):
    r = PAPERS[paper]["rows"].get(key)
    if r is None: return "n.r."
    v = r[3][stat]
    if paper == "Buildings2026" and key == "C" and stat == "SD": v += " [a]"
    if paper == "SciRep2026" and key == "P" and stat == "Min": v += " [e]"
    return v

def block(stat, title, note):
    hdr = f"| Variable | CSCM2025 [9] | Buildings2026 [10] | SciRep2026 [11] | Computed (ddof = 0) | Computed (ddof = 1) |\n|---|---:|---:|---:|---:|---:|\n"
    rows = []
    for k in ORDER:
        if stat == "SD":
            c0, c1 = f4(comp.loc[k,"SD0"]), f4(comp.loc[k,"SD1"])
        else:
            c0 = c1 = f4(comp.loc[k, stat])
        nm = ROWNAME[k]
        if k == "P": nm += " [c]"
        if k == "CC": nm += " [d]"
        rows.append(f"| {nm} | {cell('CSCM2025',k,stat)} | {cell('Buildings2026',k,stat)} | {cell('SciRep2026',k,stat)} | {c0} | {c1} |")
    return f"### {title}\n\n{note}\n\n{hdr}" + "\n".join(rows) + "\n"

s2 = []
s2.append(textwrap.dedent("""\
# Supplementary material S2 — Full descriptive statistics as printed by CSCM2025, Buildings2026 and SciRep2026, against values computed from the 198 primary records

Companion to Section 3.2 of the main text ("All minima, maxima and means agree exactly (full table in supplementary material)"). Table 1 of the main text shows four variables; this supplement shows every variable and every statistic that each of the three studies prints.

## How to read this table

* **Printed columns are transcriptions, not corrections.** Every value under CSCM2025, Buildings2026 and SciRep2026 is reproduced character-for-character from the published PDF, at the printed precision (trailing zeros kept: `0.160`, `719.000`), including typographical anomalies, which are footnoted rather than amended. Nothing printed has been rescaled, rounded or converted.
* **Computed columns** are the only calculated quantities on this page: `min`, `max`, `mean`, `std(ddof=0)` and `std(ddof=1)` of each column of `scirep_MOESM1.xlsx` (198 rows × 12 columns; pandas 2.3.3). They are shown to four decimal places; full-precision values and the exact code are in the transcription log (S2_transcription_log.md, Appendix D). For Max, Min and Mean the ddof setting has no effect, so the two computed columns are identical; both are kept so that every block has the same layout.
* **Computed values are in the units of the xlsx column**, which are not always the units the papers print (see notes [c] and [d]). No unit conversion has been applied on either side.
* **n.r.** = not reported: the variable does not appear in that study's descriptive-statistics table.
* Row order follows SciRep2026 Table 2 (the superset), with CS last. Row names are this supplement's neutral labels; the exact variable name, unit and label printed by each study are listed in Section S2.2.
* **None of the three studies states whether its standard deviation is the population form (ddof = 0) or the sample form (ddof = 1).** See note [i].

## S2.1 Sources

| Study | Table | Where in the PDF | Statistics printed (column headers as printed) | Variables printed |
|---|---|---|---|---|
| CSCM2025 [9] | Table 1, "Input and output variables in the dataset." | p. 2 | Max. / Min. / Mean / SD | 7 inputs + CS = 8 |
| Buildings2026 [10] | Table 1, "Input and output variables in the dataset." | p. 7 of 17 | Max. / Min. / Mean / SD | 7 inputs + CS = 8 |
| SciRep2026 [11] | Table 2, "Detailed description and statistical characteristics" | PDF page 12 of the "ARTICLE IN PRESS" file (printed folio 11; manuscript line 232) | Mean / Std / Min / Max / Skewness | 11 inputs + CS = 12 |

The 12 variables of SciRep2026 are exactly the 12 columns of its supplementary file `scirep_MOESM1.xlsx`. CSCM2025 and Buildings2026 print the same 8 of these 12 (C, CA, FA, W/B, T, P, CC, CS) and do not print W, blast furnace slag, fly ash or CCU-steam curing time.

## S2.2 Variable names, units and labels as printed

| Row in this supplement | xlsx column | CSCM2025 (Variable / Unit / Label) | Buildings2026 (Variable / Unit / Label) | SciRep2026 (Variables) |
|---|---|---|---|---|
""").rstrip("\n"))
for k in ORDER:
    def nm(paper):
        r = PAPERS[paper]["rows"].get(k)
        if r is None: return "n.r."
        if r[1] is None: return f"`{r[0]}`"
        return f"{r[0]} / {r[1]} / {r[2]}"
    s2.append(f"| {ROWNAME[k]} | `{k}` | {nm('CSCM2025')} | {nm('Buildings2026')} | {nm('SciRep2026')} |")
s2.append("")
s2.append("Notes on naming: CSCM2025 calls T \"CO2 curing duration\", Buildings2026 \"CO2 curing time\" [g]; SciRep2026 prints the unit of P as \"(%)\" [c], prints CC as a fraction under a \"(%)\" header [d], and prints the unit of CS as \"(MP)a\" [b].")
s2.append("")
s2.append("## S2.3 Main table — printed versus computed, one block per statistic\n")
s2.append(block("Max",  "S2.3.1 Maximum",            "CSCM2025 and Buildings2026 head this column \"Max.\"; SciRep2026 heads it \"Max\"."))
s2.append(block("Min",  "S2.3.2 Minimum",            "CSCM2025 and Buildings2026 head this column \"Min.\"; SciRep2026 heads it \"Min\"."))
s2.append(block("Mean", "S2.3.3 Mean",               "All three studies head this column \"Mean\"."))
s2.append(block("SD",   "S2.3.4 Standard deviation", "CSCM2025 and Buildings2026 head this column \"SD\"; SciRep2026 heads it \"Std\". No study states the ddof convention [i]. The two computed columns differ here and only here."))
# Skewness block: SciRep only, no computed counterpart.
s2.append("### S2.3.5 Skewness (SciRep2026 only)\n\nOnly SciRep2026 prints a skewness column. No computed counterpart is given: skewness is outside the set of statistics computed for this supplement [h].\n")
s2.append("| Variable | CSCM2025 [9] | Buildings2026 [10] | SciRep2026 [11] |\n|---|---:|---:|---:|")
for k in ORDER:
    s2.append(f"| {ROWNAME[k]} | n.r. | n.r. | {PAPERS['SciRep2026']['rows'][k][3]['Skewness']} |")
s2.append("")
s2.append(textwrap.dedent("""\
## S2.4 Notes

[a] **Buildings2026, Cement, SD: printed as `171.18`.** Transcribed as printed. For the same cell CSCM2025 prints `171.8`, and the value computed with ddof = 0 is 171.7824 (ddof = 1: 172.2178). The interpretation of this cell is given in the main text (Section 3.2, note †); this supplement records only what is printed. This is the only cell in which CSCM2025 and Buildings2026, which otherwise print identical tables, differ.

[b] **SciRep2026, CS: unit printed as `(MP)a`** (misplaced parenthesis for "(MPa)"). Transcribed as printed.

[c] **SciRep2026, P: unit printed as `(%)`.** CSCM2025 and Buildings2026 print the unit of P as `MPa`. The numbers printed by all three studies for P are on the same scale (e.g. mean 0.207), and the xlsx column `P` carries no unit metadata. Transcribed as printed; no interpretation applied.

[d] **CC scale.** CSCM2025 and Buildings2026 print CC in percent (Min `20`, Max `100`, Mean `84.5`, SD `28.6`, unit `%`). SciRep2026 prints CC as a fraction (Min `0.200`, Max `1.000`, Mean `0.845`, SD `0.286`) under the header `CC (%)`. The xlsx column `CC` is a fraction (0.2–1.0), so the computed CC values are on the fraction scale. No rescaling has been applied to any printed or computed value in this table.

[e] **SciRep2026, P, Min: printed as `0.001`** at three decimal places, where CSCM2025 and Buildings2026 print `0.0014` at four. Transcribed as printed. (SciRep2026 prints every statistic in Table 2 at three decimal places.)

[f] **n.r.**: W, blast furnace slag, fly ash and CCU-steam curing time are not present in the CSCM2025 or Buildings2026 tables. Neither study prints any statistic for them, so the cells are empty by construction, not illegible.

[g] T is named "CO2 curing duration" in CSCM2025 and "CO2 curing time" in Buildings2026; W/B is printed with a hyphen in CSCM2025 ("Water-binder ratio") and an en dash in Buildings2026 ("Water–binder ratio"). Units and labels are otherwise identical between the two.

[h] Skewness is printed by SciRep2026 only. It is transcribed in S2.3.5 for completeness but was not computed for this supplement, which restricts itself to min, max, mean and the two standard deviations.

[i] **Standard-deviation convention.** The full text of each of the three PDFs was searched for `ddof`, `sample standard`, `population standard`, `n-1` / `n − 1` / `(n-1)`, `Bessel` and `unbiased`. No study states which convention its SD column uses. The only hit (SciRep2026, manuscript line 551, "unbiased estimates of feature effects") concerns SHAP values, not the descriptive statistics. Buildings2026 introduces its table with "mean and standard deviation (SD)" (p. 7); CSCM2025 adds only "Note that label is the abbreviation of the variable." (p. 2); SciRep2026 introduces its table with "Descriptive statistics for all variables are summarized in Table 2." (manuscript lines 183–184). The convention is therefore inferable only from the printed values, which is the point made in Section 3.2 of the main text.

[j] **Legibility.** All 172 printed cells transcribed in this supplement (CSCM2025 32, Buildings2026 32, SciRep2026 60, IJCSM2026 48) were legible in the PDF text layer and in 200-dpi page renders; no cell is recorded as illegible.

## S2.5 IJCSM2026 [12] — negative control (its own statistics only; no comparison)

IJCSM2026 is the negative control of the main text: its variable set, units and sample sizes differ from the three studies above (n = 423 records for compressive strength and 131 for CO2 uptake, per its Section 2), and its table is listed here only so that the reader can see that none of its printed values coincides with the tables above. No computed column is given because no primary data for IJCSM2026 were obtained, and no cell of this table is compared with anything.

Source: IJCSM2026 Table 1, "Database used for LSBoost model training", p. 4 of 16. Column headers as printed: (blank) / Unit / Minimum / Maximum / Average / Standard deviation. The table does not state which of the two sample sizes each row refers to. IJCSM2026 likewise does not state a standard-deviation convention (same search as note [i]; no hits).

| Type | Variable (as printed) | Unit | Minimum | Maximum | Average | Standard deviation |
|---|---|---|---:|---:|---:|---:|
""").rstrip("\n"))
for (typ, var, unit, mn, mx, av, sd, ln, txtln) in IJCSM["rows"]:
    s2.append(f"| {typ} | {var} | {unit} | {mn} | {mx} | {av} | {sd} |")
s2.append("")
s2.append("## S2.6 Provenance\n\nEvery printed value above is traceable to a PDF page and line in `S2_transcription_log.md`, which also lists the file checksums, the extraction commands, the full-precision computed values and the code that produced them.\n")
open(OUT_S2, "w").write("\n".join(s2))

# ----------------------------------------------------------------------------------------------
# 5. S2_transcription_log.md
# ----------------------------------------------------------------------------------------------
log = []
log.append(textwrap.dedent("""\
# S2 transcription log — provenance of every printed value in S2_full_statistics.md

Purpose: let a reviewer re-check any single cell of S2 against the PDF in under a minute. For every printed value, this log gives (i) the PDF page (as counted by `pdftotext -f N -l N`, 1-based), (ii) the line number within the layout-preserving text of that page, and (iii) the line number in the pre-extracted whole-document text in `probe/sources/<paper>.txt`. Values were read from the PDF text layer and confirmed by eye against 200-dpi renders of the same pages (`pdftoppm -r 200`).

Transcription rule applied throughout: copy what is printed, at the printed precision, including trailing zeros and typographical anomalies; do not correct, round, rescale or convert; mark any unreadable cell "illegible" with its page. No cell needed that mark.

## A. Files, checksums and tools

| File | MD5 | Role |
|---|---|---|
| `probe/sources/cscm.pdf` | `5b07f64c4b1fd53e0dce932b9eaef1ce` | CSCM2025 [9], Chu et al., Case Stud. Constr. Mater. 22 (2025) e04589 |
| `probe/sources/buildings.pdf` | `64fba1f8b70c1ea7d83d650faf489b3b` | Buildings2026 [10], Buildings 2026, 16, 89 |
| `probe/sources/scirep.pdf` | `941aede516820be71b473e8ddfb76baa` | SciRep2026 [11], Sci. Rep. 2026, "ARTICLE IN PRESS" accepted-manuscript PDF (52 pages, manuscript line numbers in margin) |
| `probe/sources/ijcsm.pdf` | `db412ad9e6dea991ba19ac01466416eb` | IJCSM2026 [12], Han et al., Int J Concr Struct Mater (2026) 20:86 |
| `probe/data/scirep_MOESM1.xlsx` | `217f07283479db053eb9d8d7c674daf3` | Primary data, sheet `Sheet1`, 1 header row + 198 data rows × 12 columns; no missing values |

Tools: `pdftotext` / `pdftoppm` (poppler 26.06.0); Python 3 with pandas 2.3.3, numpy 2.0.2, openpyxl 3.1.5.

Page extraction command used for every citation below (replace `<pdf>` and `<N>`):

    pdftotext -layout -f <N> -l <N> probe/sources/<pdf> - | cat -n

The `.txt` line numbers refer to `probe/sources/<paper>.txt`, produced earlier with `pdftotext -layout <pdf> <paper>.txt` over the whole document; they are given as a convenience only. The PDF page + in-page line is the authoritative citation.

Locating the tables: the page index of each table was found by counting form feeds in the whole-document text (`awk 'BEGIN{p=1} /\\f/{p++} /<caption>/{print p}'`) and then confirmed by extracting that page alone and by rendering it.

## B. Per-value provenance

Each row below lists every printed value of one table row together with its location. A value is "found" when the exact printed token appears, whitespace-delimited, on the cited in-page line; this was re-checked mechanically by the build script (Appendix F) for all 172 tokens before the files were written.
"""))
for name, P in PAPERS.items():
    log.append(f"### B.{list(PAPERS).index(name)+1} {name} — {P['table']}\n")
    log.append(f"PDF page {P['page']} (printed folio {P['folio']}); header row at in-page line {P['header_line']} (`{P['header']}`), .txt line {P['txt_header']}. Statistics printed: {' / '.join(P['stats'])}.\n")
    stats = P["stats"]
    log.append("| Variable as printed | " + " | ".join(stats) + " | PDF page | in-page line | .txt line | render checked |")
    log.append("|---|" + "---:|"*len(stats) + "---:|---:|---:|---|")
    for key, (var, unit, label, vals, ln, txtln) in P["rows"].items():
        lab = var if unit is None else f"{var} / {unit} / {label}"
        log.append(f"| {lab} | " + " | ".join(f"`{vals[s]}`" for s in stats) + f" | {P['page']} | {ln} | {txtln} | yes |")
    log.append("")
log.append("Per-paper remarks:\n")
log.append(textwrap.dedent("""\
* CSCM2025: in the text layer the superscript "3" of the first `kg/m³` is emitted on its own line (in-page line 57; .txt line 129), so the Cement row reads `kg/m` followed by `C`. The PDF render shows `kg/m³`. Affects no numeric value.
* Buildings2026: the Output row's variable name "Compressive strength" is wrapped over in-page lines 53–55 (.txt 406–408); all four numbers of that row are on line 54 (.txt 407). The Cement SD reads `171.18` in both the text layer and the render (S2 note [a]).
* SciRep2026: the "ARTICLE IN PRESS" PDF has a cover/front matter offset, so PDF page 12 carries printed folio 11. The table caption carries manuscript line number 232. The text layer and the render agree on `CS (MP)a`, `P (%)`, and the fraction-scale CC row (S2 notes [b]–[d]). Skewness values were transcribed but not computed (S2 note [h]).
* Variable-count check: SciRep2026 Table 2 has 12 rows = 11 input variables + CS, matching the 12 columns of `scirep_MOESM1.xlsx` exactly (column order in the xlsx differs: C, CA, FA, W, blast furnace slag, fly ash, W/B, CCU-steam curing time, T, CC, P, CS).
"""))
log.append(f"### B.4 IJCSM2026 — {IJCSM['table']} (negative control)\n")
log.append(f"PDF page {IJCSM['page']} ({IJCSM['folio']}); header rows at in-page lines {IJCSM['header_lines']} (`{IJCSM['header']}`), .txt lines {IJCSM['txt_header']}.\n")
log.append("| Type | Variable as printed | Unit | Minimum | Maximum | Average | Standard deviation | PDF page | in-page line | .txt line | render checked |")
log.append("|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|")
for (typ, var, unit, mn, mx, av, sd, ln, txtln) in IJCSM["rows"]:
    log.append(f"| {typ} | {var} | {unit} | `{mn}` | `{mx}` | `{av}` | `{sd}` | 4 | {ln} | {txtln} | yes |")
log.append("")
log.append('Remark: in the text layer the row "RH for CO2 curing" carries a soft-hyphen control character before "CO2" (.txt line 203); the render reads "RH for CO2 curing". Affects no numeric value.\n')
log.append(textwrap.dedent("""\
## C. Standard-deviation convention search

Command (run on each of the four `.txt` files):

    grep -n -iE "ddof|sample standard|population standard|n-1|n − 1|\\(n ?[-−] ?1\\)|Bessel|unbiased" <paper>.txt

Hits: cscm.txt none; buildings.txt none; ijcsm.txt none; scirep.txt one — manuscript line 551, "…providing unbiased estimates of feature effects by evaluating localized…", which concerns SHAP, not Table 2. Additional context lines read for each table: CSCM2025 p. 2 "Note that label is the abbreviation of the variable." (.txt 139); Buildings2026 p. 7 "…including the type, name, unit, label, maximum and minimum values, and mean and standard deviation (SD)." (.txt 393–394); SciRep2026 manuscript lines 183–184 "Descriptive statistics for all variables are summarized in Table 2." (.txt 490–491); IJCSM2026 p. 4 "A summary of the ranges, averages, and standard deviations for each input parameter is presented in Table 1." (.txt 175–176). None states a ddof convention.

## D. Computed columns — code and full-precision output

The only computation performed for S2. Code, verbatim:

    import pandas as pd
    df = pd.read_excel("probe/data/scirep_MOESM1.xlsx")        # (198, 12), no NaN
    out = pd.DataFrame({"min": df.min(), "max": df.max(), "mean": df.mean(),
                        "std_ddof0": df.std(ddof=0), "std_ddof1": df.std(ddof=1)})

Output at 10 significant figures (S2 shows these rounded to four decimal places):

| xlsx column | min | max | mean | std (ddof = 0) | std (ddof = 1) |
|---|---:|---:|---:|---:|---:|
""").rstrip("\n"))
for k in df.columns:
    r = comp.loc[k]
    log.append(f"| `{k}` | {fp(r['Min'])} | {fp(r['Max'])} | {fp(r['Mean'])} | {fp(r['SD0'])} | {fp(r['SD1'])} |")
log.append("")
log.append("These values are identical, to full floating-point precision, to `per_column` in `public_release/experiment/fingerprint_check.json` (produced by `fingerprint_check.py` on 2026-09-17 from the same xlsx).\n")
log.append(textwrap.dedent("""\
## E. Tally

| Study | Variables | Statistics per variable | Cells transcribed | Printed anomalies footnoted | Illegible cells |
|---|---:|---:|---:|---|---:|
| CSCM2025 | 8 | 4 (Max., Min., Mean, SD) | 32 | 0 | 0 |
| Buildings2026 | 8 | 4 (Max., Min., Mean, SD) | 32 | 1 numeric: Cement SD `171.18` [a] | 0 |
| SciRep2026 | 12 | 5 (Mean, Std, Min, Max, Skewness) | 60 (48 + 12 skewness) | 3 label/unit: `CS (MP)a` [b], `P (%)` [c], `CC (%)` printed as fraction [d]; 1 precision: P Min `0.001` [e] | 0 |
| IJCSM2026 (control) | 12 | 4 (Minimum, Maximum, Average, Standard deviation) | 48 | 0 | 0 |
| **Total** | | | **172** | | **0** |

## F. Build

`S2_full_statistics.md` and this log were generated by `build_S2.py` (kept in the session scratchpad; the transcribed values and page/line citations are embedded in it verbatim, and it aborts if any transcribed token is not found on its cited pdftotext line). Generated 2026-09-17.
"""))
open(OUT_LOG, "w").write("\n".join(log))
print("wrote", OUT_S2); print("wrote", OUT_LOG)
