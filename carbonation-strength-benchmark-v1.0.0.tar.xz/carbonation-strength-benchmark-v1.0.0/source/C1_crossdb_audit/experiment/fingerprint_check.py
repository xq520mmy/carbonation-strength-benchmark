#!/usr/bin/env python3
"""Reproduce Table 1 (descriptive-statistic fingerprint) and Sections 4.1-4.2 (replicate
structure and lookup baseline) of the manuscript from the 198-row supplementary table.

Input : probe/data/scirep_MOESM1.xlsx  (NOT distributed here; see probe/data/README.md)
Output: fingerprint_check.json (written next to this script) and a printed summary.

What is computed
----------------
1. For every column: min, max, mean, SD with ddof=0 (population) and ddof=1 (sample), and the
   ratio SD1/SD0, which must equal sqrt(n/(n-1)) = 1.002535 for n = 198.
2. Comparison with the statistics printed by the three studies (Table 1 of the manuscript).
   Printed values are transcribed from the studies' tables; they are stored in PRINTED below
   and mirrored in ../EVIDENCE.json. A printed value "agrees" if the computed value, rounded to
   the number of decimals printed, equals it.
3. Replicate structure: distinct feature vectors, group-size distribution, rows in groups of
   size >= 2, within-group vs total variance of compressive strength (CS).
4. Lookup baseline: predict each row by the mean CS of its replicate group (no learning).

The grouping key is identical to the one used by split_comparison.py, loso_calibration.py,
model_family_sweep.py and diagnostics_failure.py: the 11 feature values formatted with "%.6g"
and joined with "|".

Usage
-----
    python3 fingerprint_check.py                # expects ../probe/data/scirep_MOESM1.xlsx
    python3 fingerprint_check.py --data PATH    # explicit path to the xlsx
"""
import argparse, json, math, os
from collections import Counter, defaultdict

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DATA = os.path.join(HERE, "..", "probe", "data", "scirep_MOESM1.xlsx")
TARGET = "CS"

# Values as printed by the three studies (manuscript Table 1; mirrored in ../EVIDENCE.json).
# Strings keep the printed precision. ddof = the estimator convention each study's SD implies.
PRINTED = {
    "C": {
        "CSCM2025":      dict(max="719", min="100", mean="354.3", sd="171.8", ddof=0),
        "Buildings2026": dict(max="719", min="100", mean="354.3", sd="171.18", ddof=0,
                              note="printed 171.18 against computed 171.78; treated in the manuscript as a transposition, not a falsification"),
        "SciRep2026":    dict(max="719.0", min="100.0", mean="354.275", sd="172.218", ddof=1),
    },
    "FA": {
        "CSCM2025":      dict(max="2227", min="0", mean="881.3", sd="570.2", ddof=0),
        "Buildings2026": dict(max="2227", min="0", mean="881.3", sd="570.2", ddof=0),
        "SciRep2026":    dict(max="2227.0", min="0.0", mean="881.336", sd="571.633", ddof=1),
    },
    "P": {
        "CSCM2025":      dict(sd="0.166", ddof=0),
        "Buildings2026": dict(sd="0.166", ddof=0),
    },
    "CS": {
        "CSCM2025":      dict(max="81.89", min="1.61", mean="32.23", sd="18.79", ddof=0),
        "Buildings2026": dict(max="81.89", min="1.61", mean="32.23", sd="18.79", ddof=0),
        "SciRep2026":    dict(max="81.890", min="1.610", mean="32.229", sd="18.840", ddof=1),
    },
}


def decimals(s: str) -> int:
    return len(s.split(".")[1]) if "." in s else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=DEFAULT_DATA)
    args = ap.parse_args()

    df = pd.read_excel(args.data)
    df = df.loc[:, [c for c in df.columns if not str(c).startswith("Unnamed")]]
    assert df.shape == (198, 12), f"expected 198 x 12, got {df.shape}"
    n = len(df)
    ratio_expected = math.sqrt(n / (n - 1))

    # 1. per-column statistics
    stats = {}
    for c in df.columns:
        v = df[c].astype(float).values
        sd0, sd1 = float(v.std(ddof=0)), float(v.std(ddof=1))
        stats[c] = dict(min=float(v.min()), max=float(v.max()), mean=float(v.mean()),
                        sd_ddof0=sd0, sd_ddof1=sd1, sd1_over_sd0=sd1 / sd0)

    # 2. comparison with printed values
    comparison, n_checked, n_agree = {}, 0, 0
    for var, studies in PRINTED.items():
        comparison[var] = {}
        for study, p in studies.items():
            ddof = p["ddof"]
            rows = {}
            for stat in ("max", "min", "mean", "sd"):
                if stat not in p:
                    continue
                printed = p[stat]
                comp = stats[var]["sd_ddof%d" % ddof] if stat == "sd" else stats[var][stat]
                agree = round(comp, decimals(printed)) == float(printed)
                rows[stat] = dict(printed=printed, computed=round(comp, 6), agrees=bool(agree))
                n_checked += 1; n_agree += int(agree)
            if "note" in p:
                rows["note"] = p["note"]
            comparison[var][study] = rows

    # 3. replicate structure
    feat = [c for c in df.columns if c != TARGET]
    y = df[TARGET].astype(float).values
    keys = ["|".join(f"{v:.6g}" for v in r) for r in df[feat].values]
    groups = defaultdict(list)
    for i, k in enumerate(keys):
        groups[k].append(i)
    sizes = Counter(len(v) for v in groups.values())
    dup_groups = [v for v in groups.values() if len(v) > 1]
    rows_in_dup = sum(len(v) for v in dup_groups)
    within = float(np.mean([y[v].var(ddof=0) for v in dup_groups]))
    total = float(y.var(ddof=0))

    # 4. lookup baseline: replicate-group mean, no learning
    pred = np.empty_like(y)
    for v in groups.values():
        pred[v] = y[v].mean()
    resid = y - pred
    rmse = float(np.sqrt(np.mean(resid ** 2)))
    mae = float(np.mean(np.abs(resid)))
    r2 = float(1 - np.sum(resid ** 2) / np.sum((y - y.mean()) ** 2))

    out = dict(
        data_file="probe/data/" + os.path.basename(args.data),   # expected location inside this package
        n_rows=n, n_columns=int(df.shape[1]), columns=list(df.columns),
        sqrt_n_over_n_minus_1=ratio_expected,
        per_column=stats,
        printed_vs_computed=dict(n_checked=n_checked, n_agree=n_agree, detail=comparison),
        replicate_structure=dict(
            n_distinct_feature_vectors=len(groups),
            n_groups_size_ge_2=len(dup_groups),
            rows_in_groups_size_ge_2=rows_in_dup,
            frac_rows_in_groups_size_ge_2=rows_in_dup / n,
            group_size_distribution={str(k): sizes[k] for k in sorted(sizes)},
            within_group_cs_variance_mean=within, total_cs_variance=total,
            within_over_total=within / total),
        lookup_baseline=dict(r2=r2, rmse=rmse, mae=mae,
                             note="each row predicted by the mean CS of its replicate group; rows with a unique feature vector predict themselves exactly"),
    )
    with open(os.path.join(HERE, "fingerprint_check.json"), "w") as f:
        json.dump(out, f, indent=2)

    print(f"n = {n}; sqrt(n/(n-1)) = {ratio_expected:.6f}")
    print(f"{'col':22s} {'min':>9s} {'max':>9s} {'mean':>10s} {'sd ddof0':>10s} {'sd ddof1':>10s} {'ratio':>9s}")
    for c, s in stats.items():
        print(f"{c:22s} {s['min']:9.4g} {s['max']:9.4g} {s['mean']:10.4f} {s['sd_ddof0']:10.4f} {s['sd_ddof1']:10.4f} {s['sd1_over_sd0']:9.6f}")
    print(f"\nprinted vs computed: {n_agree}/{n_checked} agree at printed precision")
    for var, studies in comparison.items():
        for study, rows in studies.items():
            bad = [k for k, r in rows.items() if isinstance(r, dict) and not r["agrees"]]
            flag = "OK " if not bad else "!! "
            print(f"  {flag}{var:3s} {study:14s}" + ("" if not bad else f" disagrees on {bad}: " + rows.get("note", "")))
    rs = out["replicate_structure"]
    print(f"\nreplicate structure: {rs['n_distinct_feature_vectors']} distinct feature vectors; "
          f"{rs['n_groups_size_ge_2']} groups of size >= 2; {rs['rows_in_groups_size_ge_2']} rows "
          f"({100*rs['frac_rows_in_groups_size_ge_2']:.1f}%) in such groups; sizes {rs['group_size_distribution']}")
    print(f"within-group CS variance {within:.3f} vs total {total:.3f} -> {100*within/total:.2f}%")
    print(f"lookup baseline: R2 = {r2:.4f}, RMSE = {rmse:.3f} MPa, MAE = {mae:.3f} MPa")


if __name__ == "__main__":
    main()
