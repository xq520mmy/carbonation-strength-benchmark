#!/usr/bin/env python3
"""Supplementary sweeps: Crossref, Europe PMC, Semantic Scholar, Unpaywall (OA status)."""
import json, os, time, urllib.parse, urllib.request, urllib.error
HERE = os.path.dirname(os.path.abspath(__file__)); RAW = os.path.join(HERE, "..", "raw")
MAIL = "mingmingye1992@gmail.com"
UA = f"C1-extval/1.0 (mailto:{MAIL})"
def get(u, t=60):
    r = urllib.request.Request(u, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(r, timeout=t) as f: return json.loads(f.read().decode())

out = {"crossref": {}, "epmc": {}, "s2": {}, "log": []}

# ---- Crossref ----
CRQ = ['"carbonation curing" "compressive strength"', '"CO2 curing" concrete "compressive strength"',
       '"accelerated carbonation curing" mix proportion', '"carbonation curing" "mix proportion"',
       '"CO2 curing" "mix proportions"']
for q in CRQ:
    off, got = 0, 0
    while off < 400:
        u = ("https://api.crossref.org/works?query.bibliographic=" + urllib.parse.quote(q) +
             f"&filter=from-pub-date:2015-01-01,type:journal-article&rows=100&offset={off}&mailto={MAIL}")
        try: d = get(u)
        except Exception as e: out["log"].append(f"crossref {q} off{off} ERR {e}"); break
        items = d["message"]["items"]
        if not items: break
        for it in items:
            doi = (it.get("DOI") or "").lower()
            out["crossref"].setdefault(doi, dict(doi=doi, title=(it.get("title") or [""])[0],
                year=(it.get("issued", {}).get("date-parts") or [[None]])[0][0],
                venue=(it.get("container-title") or [""])[0], publisher=it.get("publisher")))
            got += 1
        off += 100; time.sleep(0.2)
    out["log"].append(f"crossref\t{q}\ttotal={d['message']['total-results']}\tcollected={got}")
    print(out["log"][-1], flush=True)

# ---- Europe PMC ----
EQ = ['"carbonation curing" AND "compressive strength"', '"CO2 curing" AND concrete',
      '"accelerated carbonation" AND "compressive strength" AND concrete']
for q in EQ:
    cur, got = "*", 0
    while True:
        u = ("https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=" +
             urllib.parse.quote(q + ' AND (FIRST_PDATE:[2015-01-01 TO 2026-12-31])') +
             f"&format=json&pageSize=100&cursorMark={urllib.parse.quote(cur)}&resultType=lite")
        try: d = get(u)
        except Exception as e: out["log"].append(f"epmc {q} ERR {e}"); break
        for r in d["resultList"]["result"]:
            doi = (r.get("doi") or "").lower()
            k = doi or r.get("id")
            out["epmc"].setdefault(k, dict(doi=doi, pmcid=r.get("pmcid"), inEPMC=r.get("inEPMC"),
                isOA=r.get("isOpenAccess"), title=r.get("title"), year=r.get("pubYear"),
                venue=r.get("journalTitle")))
            got += 1
        nc = d.get("nextCursorMark")
        if not nc or nc == cur or not d["resultList"]["result"]: break
        cur = nc; time.sleep(0.15)
    out["log"].append(f"epmc\t{q}\thitCount={d.get('hitCount')}\tcollected={got}")
    print(out["log"][-1], flush=True)

# ---- Semantic Scholar ----
SQ = ['carbonation curing compressive strength concrete', 'CO2 curing concrete mix proportion compressive strength']
for q in SQ:
    got = 0
    for off in range(0, 300, 100):
        u = ("https://api.semanticscholar.org/graph/v1/paper/search?query=" + urllib.parse.quote(q) +
             f"&offset={off}&limit=100&year=2015-2026&fields=title,year,venue,externalIds,openAccessPdf,isOpenAccess")
        try: d = get(u)
        except Exception as e: out["log"].append(f"s2 {q} off{off} ERR {type(e).__name__} {e}"); break
        for p in d.get("data", []):
            doi = ((p.get("externalIds") or {}).get("DOI") or "").lower()
            k = doi or p["paperId"]
            out["s2"].setdefault(k, dict(doi=doi, title=p.get("title"), year=p.get("year"),
                venue=p.get("venue"), isOA=p.get("isOpenAccess"),
                pdf=(p.get("openAccessPdf") or {}).get("url")))
            got += 1
        time.sleep(3.0)
    out["log"].append(f"s2\t{q}\tcollected={got}")
    print(out["log"][-1], flush=True)

json.dump(out, open(os.path.join(RAW, "other_sources.json"), "w"), indent=1, ensure_ascii=False)
print("crossref", len(out["crossref"]), "epmc", len(out["epmc"]), "s2", len(out["s2"]))
