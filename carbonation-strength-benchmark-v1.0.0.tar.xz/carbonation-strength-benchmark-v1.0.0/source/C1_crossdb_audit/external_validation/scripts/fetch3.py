#!/usr/bin/env python3
"""Threaded publisher-aware OA fetcher. Logs every HTTP outcome including 403."""
import json, os, re, sys, time, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "..", "raw"); FT = os.path.join(HERE, "..", "fulltext")
os.makedirs(FT, exist_ok=True)
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/125.0 Safari/537.36")
MDPI = dict(ma="materials", buildings="buildings", coatings="coatings", su="sustainability",
            app="applsci", min="minerals", polym="polymers", solids="solids", geotechnics="geotechnics",
            pr="processes", constrmater="constrmater", cryst="crystals", jcs="jcs", en="energies",
            infrastructures="infrastructures", civileng="civileng", eng="eng", gels="gels",
            ijerph="ijerph", nano="nanomaterials", molecules="molecules", recycling="recycling",
            resources="resources", sci="sci", environments="environments", waste="waste",
            chemengineering="chemengineering", jmmp="jmmp", fibers="fibers", ceramics="ceramics")
BLOCK = ("sciencedirect.com", "elsevier.com", "tandfonline.com", "onlinelibrary.wiley.com",
         "pubs.acs.org", "iopscience.iop.org", "journals.sagepub.com", "icevirtuallibrary.com",
         "ascelibrary.org", "emerald.com", "degruyter.com", "cambridge.org", "jstage.jst.go.jp",
         "springer.com/article", "nature.com/articles")
def slug(doi, oid): return (re.sub(r"[^A-Za-z0-9]+", "_", doi) if doi else oid)[:90]
def get(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), r.headers.get("Content-Type", ""), r.geturl()
def cands(doi, rec):
    c = []; d = (doi or "").lower()
    if d.startswith("10.3390/"):
        m = re.match(r"([a-z]+)(\d+)$", d.split("/", 1)[1])
        if m:
            ab, num = m.group(1), m.group(2); j = MDPI.get(ab, ab); seen = set()
            for volw in (1, 2, 3):
                if len(num) <= volw + 2: continue
                iss = num[volw:volw+2]
                if not iss.isdigit() or not 1 <= int(iss) <= 24: continue
                vol, art = num[:volw], num[volw+2:]
                for v in (vol.zfill(2), vol):
                    for a in (art.zfill(5), art.zfill(4)):
                        st = f"{j}-{v}-{a}"
                        if st in seen: continue
                        seen.add(st)
                        c.append(f"https://mdpi-res.com/d_attachment/{j}/{st}/article_deploy/{st}.pdf")
    if d.startswith(("10.1007/", "10.1186/", "10.1038/")):
        c.append("https://link.springer.com/content/pdf/" + doi + ".pdf")
    if d.startswith("10.3389/"):
        c.append(f"https://www.frontiersin.org/articles/{doi}/pdf")
    c.append("EPMC")
    for u in (rec.get("url"), rec.get("landing")):
        if u and not any(b in u for b in BLOCK) and u not in c: c.append(u)
    if doi and not d.startswith("10.1016/"): c.append("https://doi.org/" + doi)
    return c
def epmc(doi, name):
    try:
        q = f'https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=DOI:%22{doi}%22&format=json&resultType=core'
        r = json.loads(get(q, 20)[0].decode())["resultList"]["result"]
    except Exception as e: return None, f"EPMC search -> {type(e).__name__}"
    for x in r:
        if x.get("pmcid") and x.get("inEPMC") == "Y":
            u = f"https://www.ebi.ac.uk/europepmc/webservices/rest/{x['pmcid']}/fullTextXML"
            try:
                b = get(u, 45)[0]
                if len(b) > 5000:
                    open(os.path.join(FT, name + ".xml"), "wb").write(b); return ("xml", u, len(b), name + ".xml"), None
            except Exception as e: return None, f"EPMC xml -> {type(e).__name__}"
    return None, "EPMC: no OA fulltext"
def work(rec):
    doi = (rec.get("doi") or "").replace("https://doi.org/", ""); name = slug(doi, rec["id"])
    for e in (".pdf", ".xml"):
        p = os.path.join(FT, name + e)
        if os.path.exists(p) and os.path.getsize(p) > 20000:
            return dict(id=rec["id"], doi=doi, title=rec.get("title"), venue=rec.get("venue"),
                        status=e[1:], file=name + e, note="cached")
    ok = None; errs = []
    for u in cands(doi, rec):
        if u == "EPMC":
            if not doi: continue
            o, err = epmc(doi, name)
            if o: ok = o; break
            errs.append(err); continue
        try:
            body, ct, _ = get(u)
            if body[:5] == b"%PDF-" and len(body) > 20000:
                open(os.path.join(FT, name + ".pdf"), "wb").write(body)
                ok = ("pdf", u, len(body), name + ".pdf"); break
            errs.append(f"{u} -> ct={ct} len={len(body)} (not pdf)")
        except urllib.error.HTTPError as e: errs.append(f"{u} -> HTTP {e.code}")
        except Exception as e: errs.append(f"{u} -> {type(e).__name__}")
    return dict(id=rec["id"], doi=doi, title=rec.get("title"), venue=rec.get("venue"),
                status=ok[0] if ok else "FAIL", url=ok[1] if ok else None,
                bytes=ok[2] if ok else None, file=ok[3] if ok else None, errors=errs)
def main(infile, outfile, nw=10):
    rows = json.load(open(os.path.join(RAW, infile)))
    p = os.path.join(RAW, outfile)
    log = json.load(open(p)) if os.path.exists(p) else []
    seen = {l["id"] for l in log if l["status"] != "FAIL"}
    todo = [r for r in rows if r["id"] not in seen]
    print(f"todo {len(todo)} / {len(rows)}", flush=True)
    log = [l for l in log if l["id"] in seen]
    with ThreadPoolExecutor(max_workers=nw) as ex:
        for i, res in enumerate(ex.map(work, todo)):
            log.append(res)
            print(f"[{i+1}/{len(todo)}] {'OK  ' if res['status']!='FAIL' else 'FAIL'} {res['status']:4s} {res['doi'] or res['id']:40s} {(res.get('title') or '')[:50]}", flush=True)
    json.dump(log, open(p, "w"), indent=1, ensure_ascii=False)
    import collections; print(collections.Counter(l["status"] for l in log))
if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 10)
