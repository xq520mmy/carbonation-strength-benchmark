#!/usr/bin/env python3
"""外部验证图：(a) 预测 vs 实测（按实验室簇着色）；(b) 工艺窗口重叠。纯 CPU，matplotlib Agg。"""
import os, json
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); EV = os.path.join(HERE, "..")
import sys; sys.path.insert(0, os.path.join(EV, "..", "model_experiments")); import common as C

J = json.load(open(os.path.join(EV, "results", "extval_tierA.json")))
rows = pd.DataFrame(J["external_rows"])
REC = "ET300 raw rescaled (recommended)"
pred = np.array(J["runs"][REC]["pred_mean"], float)
y = pd.to_numeric(rows["CS"], errors="coerce").values
lab = rows["lab_id"].astype(str).values
inw = rows["_inwin"].astype(str).str.lower().isin(["true", "1"]).values

fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.9))
labs = sorted(set(lab), key=lambda L: -(lab == L).sum())
cmap = plt.get_cmap("tab10")
for i, L in enumerate(labs):
    m = lab == L
    ax[0].scatter(y[m], pred[m], s=42, alpha=.85, color=cmap(i % 10),
                  edgecolor="k", linewidth=.4, label=f"{L[:30]} (n={m.sum()})",
                  marker="o" if not inw[m].all() else "s")
lim = [0, max(y.max(), pred.max()) * 1.08]
ax[0].plot(lim, lim, "k-", lw=1)
for d in (10, -10):
    ax[0].plot(lim, [v + d for v in lim], "k--", lw=.7, alpha=.5)
ax[0].set_xlim(lim); ax[0].set_ylim(lim)
r2 = J["runs"][REC]["all"]["r2"]["mean"]; rmse = J["runs"][REC]["all"]["rmse"]["mean"]
ax[0].set_xlabel("Measured compressive strength [MPa]")
ax[0].set_ylabel("Predicted [MPa]")
ax[0].set_title(f"(a) External validation, ExtraTrees fixed from the paper\n"
                f"n={len(y)}, R²={r2:+.3f}, RMSE={rmse:.1f} MPa  (dashed: ±10 MPa)", fontsize=9)
ax[0].legend(fontsize=6.0, loc="lower right", framealpha=.9)

cols = C.RAW_COLS
tr = C._df[cols]
pos = np.arange(len(cols))
for k, c in enumerate(cols):
    lo, hi = tr[c].min(), tr[c].max()
    ev = pd.to_numeric(rows[c], errors="coerce").values
    def nz(v, l, h): return 0.0 if h - l == 0 else (v - l) / (h - l)
    ax[1].plot([nz(lo, lo, hi), nz(hi, lo, hi)], [k, k], color="0.25", lw=6, solid_capstyle="butt",
               label="198-row range" if k == 0 else None)
    xs = np.clip([nz(v, lo, hi) for v in ev], -0.35, 1.35)
    out = J["window"][c]["n_outside"]
    ax[1].scatter(xs, np.full(len(xs), k) + .28, s=16, color="crimson", alpha=.55,
                  label="external rows" if k == 0 else None)
    ax[1].text(1.45, k, f"{out}", fontsize=7.5, va="center",
               color="crimson" if out else "0.4")
ax[1].set_yticks(pos); ax[1].set_yticklabels(cols, fontsize=8)
ax[1].set_xlim(-0.45, 1.65); ax[1].axvline(0, color="0.7", lw=.6); ax[1].axvline(1, color="0.7", lw=.6)
ax[1].set_xlabel("position in the 198-row range (0 = min, 1 = max)", fontsize=9)
ax[1].set_title(f"(b) Process-window overlap — rows outside the range on the right\n"
                f"only {J['n_in_window']}/{J['n_external_complete']} external rows are inside on all 11 variables", fontsize=9)
ax[1].legend(fontsize=7, loc="lower right")
ax[1].invert_yaxis()
fig.tight_layout()
fig.savefig(os.path.join(EV, "fig_external_validation.png"), dpi=170)
print("wrote fig_external_validation.png")
