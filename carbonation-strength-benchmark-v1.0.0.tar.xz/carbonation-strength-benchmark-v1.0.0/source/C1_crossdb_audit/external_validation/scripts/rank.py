#!/usr/bin/env python3
import json, os, re
HERE = os.path.dirname(os.path.abspath(__file__)); RAW = os.path.join(HERE, "..", "raw")
oa = json.load(open(os.path.join(RAW, "oa_with_abstracts.json")))

# ---- exclusion: the 26 sources of the 198-row table, and their laboratories ----
SRC_DOIS = {d.lower() for d in """10.1080/21650373.2023.2213241 10.14359/51685791 10.1016/j.cemconcomp.2015.07.004
10.1680/macr.13.00222 10.2172/1155035 10.1617/s11527-013-0185-3 10.1016/j.conbuildmat.2016.03.048
10.14359/51714461 10.1016/j.conbuildmat.2011.03.025 10.82308/50681 10.1061/(asce)mt.1943-5533.0000462
10.1080/21650373.2013.797373 10.1520/stp157720130134 10.82308/2349 10.1061/(asce)mt.1943-5533.0001649
10.1016/j.conbuildmat.2016.07.041 10.1016/j.jcou.2019.05.034 10.1007/978-3-319-95768-5_4 10.3390/ma12223729
10.1021/acssuschemeng.9b07348 10.1061/(asce)mt.1943-5533.0003087 10.1080/19648189.2019.1707714
10.3390/buildings12060817 10.1016/j.conbuildmat.2022.129861""".split()}
# laboratories / PIs behind the 198 rows -> any paper of theirs is treated as potentially same-campaign
EXCL_AUTHORS = ["yixin shao", "hilal el-hassan", "vahid rostami", "duo zhang", "tiefeng liu",
                "zaid morshed", "abu zakir morshed", "a.z. morshed", "xiaodong xian", "mehrdad mahoutian",
                "zaid ghouleh", "ming-gin lee", "yung-chih wang", "yu-cheng kan", "sao-jeng kao",
                "tiefeng chen", "xiaojian gao", "devender sharma", "shweta goyal", "gaganjot singh sidhu",
                "yishuo su", "wei-chien wang", "jia chu", "ditao niu", "bingbing guo"]
POS = ["carbonation curing", "co2 curing", "carbon dioxide curing", "accelerated carbonation curing",
       "carbonation-cured", "co2-cured", "early-age carbonation", "carbonation cured"]
STRENGTH = ["compressive strength", "compression strength"]
MATERIAL = ["concrete", "mortar", "cement paste", "block", "brick", "masonry", "cementitious", "paste"]
NEG = ["review", "machine learning", "prediction model", "artificial neural", "meta-analysis",
       "life cycle assessment", "bibliometric", "numerical simulation", "molecular dynamic"]

rows = []
for k, v in oa.items():
    doi = (v.get("doi") or "").lower()
    txt = ((v.get("title") or "") + " " + (v.get("abstract") or "")).lower()
    au = " ; ".join(v.get("authors") or []).lower()
    excl = None
    if doi in SRC_DOIS: excl = "SOURCE_OF_198"
    else:
        for a in EXCL_AUTHORS:
            if a in au: excl = f"EXCL_AUTHOR:{a}"; break
    s = 0
    if any(p in txt for p in POS): s += 4
    if any(p in txt for p in STRENGTH): s += 3
    if any(p in txt for p in MATERIAL): s += 1
    if any(p in (v.get("title") or "").lower() for p in POS): s += 2
    for n in NEG:
        if n in txt: s -= 2
    rows.append(dict(id=k, score=s, excl=excl, doi=v.get("doi"), year=v["year"], venue=v["venue"],
                     oa=v["oa_status"], url=v.get("oa_url") or v.get("landing"),
                     title=v["title"], authors=v.get("authors"), abstract=v.get("abstract"),
                     institutions=v.get("institutions")))
rows.sort(key=lambda r: (-r["score"], -(r["year"] or 0)))
json.dump(rows, open(os.path.join(RAW, "ranked.json"), "w"), indent=1, ensure_ascii=False)
inc = [r for r in rows if not r["excl"] and r["score"] >= 7]
print("total OA:", len(rows), "| excluded:", sum(1 for r in rows if r["excl"]), "| score>=7 & not excluded:", len(inc))
import collections
print(collections.Counter(r["excl"].split(":")[0] for r in rows if r["excl"]))
print(collections.Counter(r["score"] for r in rows))
for r in inc[:60]:
    print(f"{r['score']} {r['year']} {r['oa']:7s} {str(r['doi'])[:45]:47s} {str(r['title'])[:95]}")
