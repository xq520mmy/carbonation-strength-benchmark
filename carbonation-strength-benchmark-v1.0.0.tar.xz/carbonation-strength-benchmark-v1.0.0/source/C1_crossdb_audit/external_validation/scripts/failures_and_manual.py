#!/usr/bin/env python3
"""汇总所有抓取失败件，并生成"需用户手动下载"的优先清单（已排除绿色通道补捞成功的）。"""
import json, os, re, collections
HERE=os.path.dirname(os.path.abspath(__file__)); RAW=os.path.join(HERE,"..","raw")
sl={}
for f in ["shortlist.json","shortlist_tier2.json","shortlist_tier3.json"]:
    p=os.path.join(RAW,f)
    if os.path.exists(p):
        for r in json.load(open(p)): sl[r["id"]]=r
fails=[]; ok=0
for lf in ["fetch_log2.json","fetch_log_slow.json","fetch_log_t2.json","fetch_log_t3.json"]:
    p=os.path.join(RAW,lf)
    if not os.path.exists(p): continue
    for l in json.load(open(p)):
        if l["status"]=="FAIL":
            r=sl.get(l["id"],{})
            fails.append(dict(doi=l.get("doi"), title=r.get("title") or l.get("title"), year=r.get("year"),
                              venue=r.get("venue") or l.get("venue"), score=r.get("score"),
                              codes=sorted(set(re.findall(r"HTTP (\d+)", " ".join(l.get("errors") or [])))),
                              errors=l.get("errors")))
        else: ok+=1
gp=os.path.join(RAW,"green_log.json")
green={g["doi"] for g in json.load(open(gp)) if g["status"]=="pdf"} if os.path.exists(gp) else set()
rem=[f for f in fails if (f.get("doi") or "") not in green]
POS=re.compile(r'carbonation curing|co2 curing|co₂ curing|carbon dioxide curing|accelerated carbonation|carbonation-cured|co2-cured|carbonated',re.I)
STR=re.compile(r'strength|mechanical|concrete|mortar|paste|block|brick|precast',re.I)
NEG=re.compile(r'review|machine learning|bibliometric|life cycle|prediction model',re.I)
cand=[f for f in rem if POS.search(f.get("title") or "") and STR.search(f.get("title") or "") and not NEG.search(f.get("title") or "")]
cand.sort(key=lambda f:(-(f.get("score") or 0), -(f.get("year") or 0)))
json.dump(fails, open(os.path.join(RAW,"fetch_failures.json"),"w"), indent=1, ensure_ascii=False)
json.dump(cand, open(os.path.join(RAW,"manual_download_list.json"),"w"), indent=1, ensure_ascii=False)
print("fetched ok:",ok,"| failed:",len(fails),"| green-recovered:",len(green),"| still missing:",len(rem),"| priority manual list:",len(cand))
print(collections.Counter((f["doi"] or "NODOI").split("/")[0] for f in cand).most_common(8))
