#!/usr/bin/env python3
"""汇总抽取结果 -> extracted_data.csv + PROVENANCE.md；并做去重/防污染检查 -> DEDUP_CHECK.md"""
import sys, os, json, glob, re
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
EV = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(HERE, "..", "..", "model_experiments"))
import common as C

FIELDS = ["study_id","doi","mix_id","C","CA","FA","W","slag","fly_ash","W_B","steam_h","T_h","CC","P_MPa","CS_MPa","cs_age_d"]
EXTRA  = ["carbonated","slag_kind","unit_basis","unit_note","evidence","page","missing","flags","stem","title","venue","year"]

# 198 行的 26 个来源 DOI（cscm_sources.json）+ 同实验室 PI
SRC_DOIS = {d.lower() for d in """10.1080/21650373.2023.2213241 10.14359/51685791 10.1016/j.cemconcomp.2015.07.004
10.1680/macr.13.00222 10.2172/1155035 10.1617/s11527-013-0185-3 10.1016/j.conbuildmat.2016.03.048
10.14359/51714461 10.1016/j.conbuildmat.2011.03.025 10.82308/50681 10.1061/(asce)mt.1943-5533.0000462
10.1080/21650373.2013.797373 10.1520/stp157720130134 10.82308/2349 10.1061/(asce)mt.1943-5533.0001649
10.1016/j.conbuildmat.2016.07.041 10.1016/j.jcou.2019.05.034 10.1007/978-3-319-95768-5_4 10.3390/ma12223729
10.1021/acssuschemeng.9b07348 10.1061/(asce)mt.1943-5533.0003087 10.1080/19648189.2019.1707714
10.3390/buildings12060817 10.1016/j.conbuildmat.2022.129861""".split()}
EXCL_AUTHORS = ["yixin shao","hilal el-hassan","vahid rostami","duo zhang","tiefeng liu","abu zakir morshed",
                "a.z. morshed","zaid ghouleh","xiaodong xian","mehrdad mahoutian","ming-gin lee","yung-chih wang",
                "yu-cheng kan","sao-jeng kao","tiefeng chen","xiaojian gao","devender sharma","shweta goyal",
                "gaganjot singh sidhu","jia chu","ditao niu","bingbing guo","yishuo su"]

def load():
    recs, papers = [], []
    for p in sorted(glob.glob(os.path.join(EV, "extract", "batch_*.jsonl"))):
        for ln, line in enumerate(open(p), 1):
            line = line.strip()
            if not line: continue
            try: o = json.loads(line)
            except Exception as e: print("BADJSON", p, ln, e); continue
            o["_file"] = os.path.basename(p)
            (papers if o.get("type") == "paper" else recs).append(o)
    return recs, papers

def main():
    recs, papers = load()
    man = json.load(open(os.path.join(EV, "raw", "manifest.json")))
    by_doi = {}
    for k, v in man.items():
        if v.get("doi"): by_doi[v["doi"].lower()] = v
    rows = []
    for r in recs:
        if r.get("carbonated") is False: continue
        d = {k: r.get(k) for k in FIELDS}
        for k in EXTRA: d[k] = r.get(k)
        doi = (d.get("doi") or "").lower().replace("https://doi.org/", "")
        d["doi"] = doi
        m = by_doi.get(doi) or man.get(r.get("stem") or "", {})
        d["title"] = d.get("title") or m.get("title"); d["venue"] = d.get("venue") or m.get("venue")
        d["year"] = d.get("year") or m.get("year"); d["stem"] = d.get("stem") or m.get("stem")
        d["_authors"] = "; ".join(m.get("authors") or [])
        if not d.get("study_id"): d["study_id"] = re.sub(r"[^A-Za-z0-9]+", "_", doi)[:40] or d["stem"]
        for k in ("missing", "flags"):
            if isinstance(d.get(k), list): d[k] = ";".join(map(str, d[k]))
        rows.append(d)
    df = pd.DataFrame(rows)
    if df.empty:
        print("NO RECORDS"); return
    # ---- 防污染：来源级
    df["_excl_reason"] = ""
    df.loc[df["doi"].isin(SRC_DOIS), "_excl_reason"] = "SOURCE_OF_198"
    for a in EXCL_AUTHORS:
        hit = df["_authors"].str.lower().str.contains(a, na=False) & (df["_excl_reason"] == "")
        df.loc[hit, "_excl_reason"] = f"SAME_LAB_AUTHOR:{a}"
    # ---- 防污染：数值级近重复
    num = ["C","CA","FA","W","slag","fly_ash","W_B","steam_h","T_h","CC","P_MPa","CS_MPa"]
    for c in num: df[c] = pd.to_numeric(df[c], errors="coerce")
    tr = C._df.copy(); tr.columns = ["C","CA","FA","W","slag","fly_ash","W_B","steam_h","T_h","CC","P_MPa","CS_MPa"]
    dup_notes, mix_notes = [], []
    MIX = ["C","CA","FA","W","slag","fly_ash","W_B"]
    for _, r in df.iterrows():
        v = r[num].astype(float).values
        best, bestj = None, None
        mixhit = []
        for j, t in enumerate(tr[num].values):
            cmpi = ~np.isnan(v)
            den = np.where(np.abs(t[cmpi]) > 1e-9, np.abs(t[cmpi]), 1.0)
            rel = np.abs(v[cmpi] - t[cmpi]) / den
            sc = float(np.max(rel)) if rel.size else 9e9
            if best is None or sc < best: best, bestj = sc, j
        # 只比配合比 7 列：要求至少 5 列非缺失、且其中至少 3 列非零（否则全零列会造成假阳性）
        for j, t in enumerate(tr[MIX].values):
            w = r[MIX].astype(float).values
            ci = ~np.isnan(w)
            if ci.sum() < 5: continue
            if int(np.sum(np.abs(w[ci]) > 1e-9)) < 3: continue
            den = np.where(np.abs(t[ci]) > 1e-9, np.abs(t[ci]), 1.0)
            if np.max(np.abs(w[ci] - t[ci]) / den) < 0.01: mixhit.append(j + 1)
        dup_notes.append(dict(max_rel_dev=best, nearest_train_row=(bestj + 1) if bestj is not None else None))
        mix_notes.append(";".join(map(str, mixhit[:6])))
    df["_near_dup_maxreldev"] = [d["max_rel_dev"] for d in dup_notes]
    df["_nearest_train_row"] = [d["nearest_train_row"] for d in dup_notes]
    df["_mix_vector_match_train_rows"] = mix_notes
    df["_n_present"] = df[num].notna().sum(axis=1)
    df.loc[(df["_near_dup_maxreldev"] < 0.01) & (df["_n_present"] >= 8) & (df["_excl_reason"] == ""), "_excl_reason"] = "NUMERIC_NEAR_DUPLICATE"
    df.loc[(df["_mix_vector_match_train_rows"] != "") & (df["_excl_reason"] == ""), "_excl_reason"] = "MIX_VECTOR_MATCHES_198"
    keep = df[df["_excl_reason"] == ""].reset_index(drop=True)
    # ---- 确定性补全（规则写死，不看标签）----
    # (a) 配合比表若是真正的 kg/m3 表且给出了 C/W/骨料，则未出现的矿渣、粉煤灰列记 0 kg/m3
    kgm3 = keep["unit_basis"].astype(str).str.contains(r"kg\s*/?\s*m ?3|kg/m³", case=False, regex=True)
    basis_ok = kgm3 & keep["C"].notna() & keep["W"].notna() & (keep[["CA", "FA"]].notna().any(axis=1))
    for c in ("slag", "fly_ash"):
        fillm = basis_ok & keep[c].isna()
        keep.loc[fillm, c] = 0.0
        keep.loc[fillm, "flags"] = keep.loc[fillm, "flags"].fillna("") + ";absent_component_set_to_0"
    # (b) 未报蒸汽预养护 -> 0 h
    fillm = keep["steam_h"].isna()
    keep.loc[fillm, "steam_h"] = 0.0
    keep.loc[fillm, "flags"] = keep.loc[fillm, "flags"].fillna("") + ";steam_not_reported_set_to_0"
    # (c) 分档
    CORE = ["C", "CA", "FA", "W", "slag", "fly_ash", "W_B", "steam_h", "T_h", "CC", "CS_MPa"]
    core_ok = keep[CORE].notna().all(axis=1) & basis_ok
    keep["tier"] = "C_incomplete"
    keep.loc[core_ok & keep["P_MPa"].notna(), "tier"] = "A_complete"
    keep.loc[core_ok & keep["P_MPa"].isna(), "tier"] = "B_P_imputed_ambient"
    keep["P_MPa_model"] = keep["P_MPa"].where(keep["P_MPa"].notna(), 0.1)
    # (d) 实验室聚类：作者重叠的论文并成一个 lab（与 C1 的 leave-one-LAB-out 同精神）
    LABS = {
        "IBERIA_CORDOBA_LISBOA": ["10.3390/ma16062436", "10.3390/ma16082995", "10.3390/ma18040904",
                                  "10.3390/ma16051923", "10.3390/constrmater4020020"],
        "BAGHDAD_ALSULTANI": ["10.1186/s40069-026-00902-8", "10.1186/s43251-025-00185-1"],
    }
    keep["lab_id"] = keep["doi"].replace("", np.nan).fillna(keep["study_id"]).astype(str)
    for lab, dois in LABS.items():
        keep.loc[keep["doi"].isin(dois), "lab_id"] = lab
    # (e) slag 列语义一致性：198 行里 slag 只取 0 或 ~1502（膨胀矿渣轻骨料），
    #     外部记录若 0 < slag < 1000（作为胶凝材料的 GGBS / 钢渣），该列含义与训练集不同 -> 标出
    sl = pd.to_numeric(keep["slag"], errors="coerce")
    keep["slag_semantics_ok"] = (sl.isna()) | (sl == 0) | (sl > 1000)
    keep.insert(0, "rec_id", [f"EXT-{i+1:04d}" for i in range(len(keep))])
    keep.to_csv(os.path.join(EV, "extracted_data.csv"), index=False)
    df.to_csv(os.path.join(EV, "raw", "extracted_all_with_exclusions.csv"), index=False)
    json.dump([p for p in papers], open(os.path.join(EV, "raw", "paper_notes.json"), "w"), indent=1, ensure_ascii=False)
    print(f"records parsed: {len(df)}  kept: {len(keep)}  studies kept: {keep['study_id'].nunique()}")
    print(keep.groupby("tier").agg(n=("rec_id", "size"), studies=("doi", "nunique")).to_string())
    print(df["_excl_reason"].value_counts().to_string())
    print("papers reported:", len(papers))

if __name__ == "__main__":
    main()
