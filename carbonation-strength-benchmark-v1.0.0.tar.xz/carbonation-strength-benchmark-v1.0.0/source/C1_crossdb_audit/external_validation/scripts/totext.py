#!/usr/bin/env python3
"""PDF/XML -> layout-preserving text; then screen for 'has a usable mix + curing + strength table'."""
import os, re, json, subprocess, sys, glob
HERE = os.path.dirname(os.path.abspath(__file__))
FT = os.path.join(HERE, "..", "fulltext"); TXT = os.path.join(HERE, "..", "text")
RAW = os.path.join(HERE, "..", "raw")
os.makedirs(TXT, exist_ok=True)

def xml2txt(p):
    from lxml import etree
    t = etree.parse(p)
    return "\n".join(x for x in t.getroot().itertext())

for p in sorted(glob.glob(os.path.join(FT, "*"))):
    b = os.path.basename(p); stem, ext = os.path.splitext(b)
    o = os.path.join(TXT, stem + ".txt")
    if os.path.exists(o) and os.path.getsize(o) > 500: continue
    try:
        if ext == ".pdf":
            subprocess.run(["pdftotext", "-layout", p, o], check=True, timeout=180,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif ext == ".xml":
            open(o, "w").write(xml2txt(p))
    except Exception as e:
        print("ERR", b, e)

# ---- screening ----
KG = re.compile(r"kg\s*/\s*m\s*3|kg/m3|kg m−3|kg·m−3|kg/m³", re.I)
MIXTAB = re.compile(r"mix(ture)?\s+(proportion|design|composition|ratio)|mix\s+proportions?|proportions?\s+of\s+the\s+mix", re.I)
CO2 = re.compile(r"carbonation curing|CO2 curing|CO₂ curing|carbon dioxide curing|accelerated carbonation", re.I)
CONC = re.compile(r"(\d{1,3}(?:\.\d+)?)\s*%\s*(?:\(?v/?v\)?\s*)?CO|CO2\s*(?:concentration|purity)[^.]{0,40}?(\d{1,3}(?:\.\d+)?)\s*%", re.I)
PRES = re.compile(r"(\d{1,3}(?:\.\d+)?)\s*(bar|MPa|kPa|psi)\b", re.I)
D28 = re.compile(r"28[- ]?d(ay)?", re.I)
CS = re.compile(r"compressive strength", re.I)

rows = []
for o in sorted(glob.glob(os.path.join(TXT, "*.txt"))):
    t = open(o, errors="ignore").read()
    rows.append(dict(stem=os.path.basename(o)[:-4], chars=len(t),
                     kg=len(KG.findall(t)), mixtab=len(MIXTAB.findall(t)), co2=len(CO2.findall(t)),
                     conc=len(CONC.findall(t)), pres=len(PRES.findall(t)), d28=len(D28.findall(t)),
                     cs=len(CS.findall(t))))
for r in rows:
    r["score"] = ((r["kg"] > 0) * 3 + (r["mixtab"] > 0) * 3 + (r["co2"] > 0) * 2 +
                  (r["conc"] > 0) * 2 + (r["d28"] > 0) * 2 + (r["cs"] > 0) * 1 + (r["pres"] > 0) * 1)
rows.sort(key=lambda r: -r["score"])
json.dump(rows, open(os.path.join(RAW, "text_screen.json"), "w"), indent=1)
print(f"{len(rows)} texts")
for r in rows[:200]:
    print(f"{r['score']:3d} kg={r['kg']:3d} mix={r['mixtab']:2d} co2={r['co2']:3d} conc={r['conc']:2d} p={r['pres']:3d} d28={r['d28']:3d}  {r['stem']}")
