#!/usr/bin/env python3
"""从 results/extval_*.json 渲染 EXTVAL_RESULTS.md。所有数字都来自 JSON，不手写。"""
import os, json
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); EV = os.path.join(HERE, "..")
R = {t: json.load(open(os.path.join(EV, "results", f"extval_{t}.json")))
     for t in ["tierA", "tierAB", "tierA_28d", "tierAB_28d"]}
df = pd.read_csv(os.path.join(EV, "extracted_data.csv"))

# C1 论文里已固定的参考值（manuscript/C1_final.md Table 3/7 与 model_experiments/RESULTS.md §8）
PAPER = {
 "RF300 raw flagged (baseline)":      dict(loso=0.497, strict=-0.166, rand=0.953, src="Table 3 / Table 7"),
 "RF300 raw rescaled":                dict(loso=0.583, strict=-0.089, rand=0.938, src="Table 3 / Table 7"),
 "ET300 raw rescaled (recommended)":  dict(loso=0.825, strict=+0.347, rand=0.957, src="Table 3 / Table 7"),
 "ET300 raw flagged":                 dict(loso=0.792, strict=None,   rand=0.958, src="Table 3"),
 "ET300 max_features=1/3 rescaled":   dict(loso=0.782, strict=+0.573, rand=None,  src="Table 5 / Table 7"),
 "HGB raw rescaled":                  dict(loso=0.770, strict=+0.271, rand=0.947, src="Table 3 / Table 7"),
 "LGBM-mono raw rescaled":            dict(loso=0.766, strict=+0.383, rand=0.963, src="RESULTS.md §8 / Table 7"),
 "TabPFN v2 raw flagged":             dict(loso=0.691, strict=None,   rand=0.963, src="Table 3"),
 "TabPFN v2 raw rescaled":            dict(loso=0.694, strict=+0.574, rand=None,  src="RESULTS.md §8 / Table 7"),
 "stack-NNLS":                        dict(loso=0.798, strict=+0.344, rand=None,  src="Table 6 / Table 7"),
 "uniform-mean of 4 candidates":      dict(loso=0.817, strict=+0.417, rand=None,  src="Table 6 / Table 7"),
}
ORDER = list(PAPER)

def g(t, name, cut="all", k="r2"):
    r = R[t]["runs"].get(name)
    if not r: return None
    c = r.get(cut)
    if not c or not c.get(k): return None
    return c[k]

def fmt(v, n=3, sign=True):
    if v is None: return "—"
    m, s = v["mean"], v.get("sd", 0.0)
    a = f"{m:+.{n}f}" if sign else f"{m:.{n}f}"
    return a + (f" ± {s:.{n}f}" if s and s > 5e-4 else "")

L = []; A = L.append
A("# EXTVAL_RESULTS —— C1 基准的独立外部验证\n")
A(f"生成于 {pd.Timestamp.utcnow().strftime('%Y-%m-%d %H:%M UTC')}；脚本 `scripts/run_extval.py`，结果 `results/extval_*.json`。")
A("**训练集 = C1 的全部 198 行；测试集 = 本次从原始文献新抽取的记录，与 198 行在来源论文、实验室、数值三个层面都不相交（见 `DEDUP_CHECK.md`）。**")
A("所有超参、特征集、单位调和规则、堆叠权重与 conformal 校准**全部沿用 C1 论文里已固定的设定**，没有在新数据上重选任何东西；")
A("堆叠权重与 conformal 分位数只用 198 行训练集内部的 inner leave-one-group-out 残差求得。\n")

A("## 1. 外部测试集\n")
ab = df[df["tier"] != "C_incomplete"]
A(f"- 逐篇检视了 **{len(json.load(open(os.path.join(EV,'raw','paper_notes.json'))))} 篇**取到全文的论文，其中 **{df['doi'].nunique() + (1 if df['doi'].isna().any() else 0)} 篇**产出了数据，共 **{len(df)} 条记录**。")
A(f"- 其中可进模型的 **tier A（11 个输入全部来自原文印出的 kg/m³ 表）= {int((df['tier']=='A_complete').sum())} 条 / {df[df['tier']=='A_complete']['doi'].nunique()} 篇**；")
A(f"  **tier B（同上但碳化压力未报，按常压确定性填 0.1 MPa）= {int((df['tier']=='B_P_imputed_ambient').sum())} 条 / {df[df['tier']=='B_P_imputed_ambient']['doi'].nunique()} 篇**；")
A(f"  **tier C（原文只给质量比 / wt.% / 每批克数，无法换算 kg/m³，或关键养护参数缺失）= {int((df['tier']=='C_incomplete').sum())} 条**，不进模型。")
a_only = df[df["tier"] == "A_complete"]
A(f"- tier A 是 **{a_only['lab_id'].nunique()} 个独立实验室簇**（按作者重叠合并同一实验室的多篇论文）；tier A+B 合计 **{len(ab)} 条 / {ab['lab_id'].nunique()} 个实验室簇**。")
A(f"- 强度龄期：与 C1 目标定义（28 d 强度）一致的，tier A 有 **{int((pd.to_numeric(a_only['cs_age_d'],errors='coerce')==28).sum())} 条**、tier A+B 有 **{int((pd.to_numeric(ab['cs_age_d'],errors='coerce')==28).sum())} 条**；其余是 1/3/7/14 d 等碳化结束即测或其它龄期。\n")
A("**tier C 占了 {} / {} 条，本身就是一个结论**：碳化养护文献的主流不按 kg/m³ 报配合比（质量比、wt.%、每批克数），".format(int((df['tier']=='C_incomplete').sum()), len(df)))
A("而 C1 的 11 个特征里有 6 个是绝对质量。字段口径不统一是把这批文献接到 198 行上的第一道硬墙。\n")

A("## 2. 主结果：C1 论文里固定的模型，用到从未见过的研究上\n")
A(f"口径说明：`tier A` = {R['tierA']['n_external_complete']} 条 / {R['tierA']['n_labs']} 个实验室簇；"
  f"`tier A+B` = {R['tierAB']['n_external_complete']} 条 / {R['tierAB']['n_labs']} 簇（把压力未报的行按常压补进来）；"
  f"`仅 28 d` 两档分别是 {R['tierA_28d']['n_external_complete']} 条 / {R['tierA_28d']['n_labs']} 簇 与 "
  f"{R['tierAB_28d']['n_external_complete']} 条 / {R['tierAB_28d']['n_labs']} 簇。")
A("R² 的分母是**各口径自身**留出行的总方差。随机模型报 10 个种子（HGB/LGBM 5 个，TabPFN 1 个）的 mean ± SD。\n")
A("| 模型（配置与 C1 论文逐字一致） | C1 论文 LOSO pooled R²（主折） | C1 论文严格折 R² | C1 论文随机 5 折 R² | **外部 tier A R²** | 外部 tier A RMSE | **外部 tier A+B R²** | **外部 tier A（仅 28 d）R²** | **外部 tier A+B（仅 28 d）R²** |")
A("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
for n in ORDER:
    p = PAPER[n]
    A(f"| {n} | {p['loso']:+.3f} | {('%+.3f'%p['strict']) if p['strict'] is not None else '—'} | "
      f"{('%.3f'%p['rand']) if p['rand'] is not None else '—'} | "
      f"**{fmt(g('tierA',n))}** | {fmt(g('tierA',n,'all','rmse'),2,False)} | "
      f"{fmt(g('tierAB',n))} | {fmt(g('tierA_28d',n))} | {fmt(g('tierAB_28d',n))} |")
A("")
best = max(ORDER, key=lambda n: (g('tierA', n) or {"mean": -9})["mean"])
bv = g('tierA', best)
rec = "ET300 raw rescaled (recommended)"
rv = g('tierA', rec); bl = g('tierA', "RF300 raw flagged (baseline)")
A(f"**读法**：C1 论文推荐的 ExtraTrees 在主折 LOSO 下 pooled R² = +0.825；同一个模型、同一套超参，拿到这批从未进过 198 行的研究上，")
A(f"tier A 口径的 R² 是 **{rv['mean']:+.3f} ± {rv['sd']:.3f}**（RMSE {g('tierA',rec,'all','rmse')['mean']:.2f} MPa，MAE {g('tierA',rec,'all','mae')['mean']:.2f} MPa）。")
A(f"论文里的诚实基线 RF300 在外部集上是 {bl['mean']:+.3f}。整张表里外部表现最好的是 **{best}（{bv['mean']:+.3f}）**，")
A("仍远低于 0.65 的预设达标线，也低于「预测训练集均值」这一平凡基线所对应的 R² = 0（多个配置是负的）。\n")

# ---- 平凡基线 ----
import sys as _sys
_sys.path.insert(0, os.path.join(EV, "..", "model_experiments"))
import common as _C
A("### 2b. 与平凡基线对照\n")
A("| 预测子 | tier A R² | tier A RMSE | tier A MAE | tier A+B R² | tier A+B RMSE |")
A("|---|---:|---:|---:|---:|---:|")
for t, lab in [("tierA", ""), ("tierAB", "")]:
    pass
rows_ab = df[df["tier"] != "C_incomplete"]
ya = pd.to_numeric(df[df["tier"] == "A_complete"]["CS_MPa"], errors="coerce").values
yab = pd.to_numeric(rows_ab["CS_MPa"], errors="coerce").values
trmean = float(_C.Y.mean())
def trivial(y, p):
    p = np.full_like(y, p, dtype=float)
    ss = 1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2)
    return ss, float(np.sqrt(np.mean((y - p) ** 2))), float(np.mean(np.abs(y - p)))
r1 = trivial(ya, trmean); r2_ = trivial(yab, trmean)
A(f"| 常数 = 198 行的训练均值（{trmean:.2f} MPa） | {r1[0]:+.3f} | {r1[1]:.2f} | {r1[2]:.2f} | {r2_[0]:+.3f} | {r2_[1]:.2f} |")
r3 = trivial(ya, ya.mean()); r4 = trivial(yab, yab.mean())
A(f"| 常数 = 外部集自身均值（事后，不可实现） | {r3[0]:+.3f} | {r3[1]:.2f} | {r3[2]:.2f} | {r4[0]:+.3f} | {r4[1]:.2f} |")
A(f"| **C1 推荐的 ExtraTrees** | **{g('tierA',rec)['mean']:+.3f}** | **{g('tierA',rec,'all','rmse')['mean']:.2f}** | **{g('tierA',rec,'all','mae')['mean']:.2f}** | **{g('tierAB',rec)['mean']:+.3f}** | **{g('tierAB',rec,'all','rmse')['mean']:.2f}** |")
A("")
A(f"外部集的强度均值是 {ya.mean():.2f} MPa（tier A），198 行是 {trmean:.2f} MPa。")
A("在 tier A 上，C1 推荐模型与「直接吐出训练集均值」这一常数预测子的差别很小；在 tier A+B 上模型更差。")
A(f"作为对照，C1 论文里同一模型在留出研究上的 MAE 是 4.95 MPa，这里是 {g('tierA',rec,'all','mae')['mean']:.2f} MPa。\n")

A("![外部验证](fig_external_validation.png)\n")
A("*图（a）：C1 推荐的 ExtraTrees 在外部集上的预测 vs 实测，按实验室簇着色。预测被压在约 29–47 MPa 的窄带里，"
  "而实测跨 5–67 MPa——这正是模型退化成「吐训练集均值」的形状。*")
A("*图（b）：11 个变量各自的窗口重叠；右侧红字是该列越界的外部行数。*\n")
A("## 3. 分实验室簇（C1 推荐模型，tier A+B，10 种子均值预测）\n")
A("| 实验室簇 / 论文 | n | R² | RMSE (MPa) | MAE (MPa) | 偏差 (MPa) |")
A("|---|---:|---:|---:|---:|---:|")
bs = R["tierAB"]["runs"][rec]["by_study"]
for k, v in sorted(bs.items(), key=lambda kv: -kv[1]["n"]):
    r2 = "—" if v["r2"] is None else f"{v['r2']:+.3f}"
    A(f"| `{k}` | {v['n']} | {r2} | {v['rmse']:.2f} | {v['mae']:.2f} | {v['bias']:+.2f} |")
A("")
A("单簇 R² 大多为负甚至极负，机制与 C1 论文 §4.2 讲的一样：单个研究内部强度离散度很小，R² 的分母塌掉；")
A("所以真正该看的是 **RMSE / MAE / 偏差**。偏差列显示误差不是随机的——在若干簇上模型系统性地高估或低估 10–30 MPa。\n")

A("## 4. Conformal 区间的实际覆盖率\n")
A("校准残差只来自 198 行训练集：`cross-study(LOGO)` 用训练研究间的 inner-LOGO 残差（C1 论文 Table 9 给出 90% 名义下宽 45.2 MPa）；")
A("`random-5fold` 用训练行随机 5 折残差（论文里宽 12.8 MPa、留出研究上实际覆盖 67%）。下表是这两套区间**在全新研究上的实际覆盖率**。\n")
A("| 模型 | 校准口径 | 名义 | 区间宽度 (MPa) | tier A 实际覆盖 | tier A+B 实际覆盖 | 窗口内子集覆盖 |")
A("|---|---|---:|---:|---:|---:|---:|")
ca = {(c["model"], c["alpha"], c["calib"]): c for c in R["tierA"]["conformal"]}
cb = {(c["model"], c["alpha"], c["calib"]): c for c in R["tierAB"]["conformal"]}
for m in ["ET300 raw rescaled (recommended)", "HGB raw rescaled", "LGBM-mono raw rescaled", "TabPFN v2 raw rescaled", "stack-NNLS"]:
    for al in (0.1, 0.2):
        for cal in ("cross-study(LOGO)", "random-5fold"):
            a = ca.get((m, al, cal)); b = cb.get((m, al, cal))
            if not a: continue
            cw = a.get("coverage_in_window")
            A(f"| {m} | {cal} | {1-al:.2f} | {a['width']:.1f} | {a['coverage_all']:.2f} | "
              f"{b['coverage_all']:.2f} | {'—' if cw is None else f'{cw:.2f}'} |")
A("")
etc = ca[(rec, 0.1, "cross-study(LOGO)")]; etr = ca[(rec, 0.1, "random-5fold")]
A(f"**读法**：C1 论文里「跨研究校准」的 90% 区间宽 45.2 MPa、在留出折上覆盖 100%，本来是「宽到没信息但至少诚实」。")
A(f"换到真正的外部研究上，同一套校准给出的区间宽 {etc['width']:.1f} MPa，实际只覆盖 **{etc['coverage_all']:.0%}**（名义 90%）——")
A(f"连「宽到没信息」这一档都不再成立。随机 5 折校准的区间宽 {etr['width']:.1f} MPa，实际覆盖 **{etr['coverage_all']:.0%}**。\n")

A("## 5. 诚实性检查：工艺窗口重不重叠\n")
A("下表逐列比较 198 行的取值范围与外部集（tier A）的取值范围。`越界行数`是该列落在训练区间之外的外部行数。\n")
A("| 变量 | 198 行 min | 198 行 max | 外部 min | 外部 max | 越界行数 |")
A("|---|---:|---:|---:|---:|---:|")
for c, v in R["tierA"]["window"].items():
    A(f"| `{c}` | {v['train_min']:.4g} | {v['train_max']:.4g} | {v['ext_min']:.4g} | {v['ext_max']:.4g} | {v['n_outside']} |")
A("")
w = R["tierA"]
A(f"**11 列同时落在训练区间内的外部行只有 {w['n_in_window']} / {w['n_external_complete']} 条**。越界主要来自三列：")
A(f"碳化时长 T（训练集 1–48 h，外部最长 {w['window']['T']['ext_max']:.0f} h —— 大量现代文献把试件在 CO₂ 舱里放 7 d / 28 d / 40–120 d）、")
A(f"CO₂ 浓度 CC（训练集最低 20%，外部有 5% 的舱）、以及蒸汽预养护时长（训练集 0–4 h，外部有 8 h）。\n")
A("此外还有一个**列语义**问题，比数值越界更隐蔽：198 行里 `blast furnace slag` 一列只取 0 或 ≈1502 kg/m³，")
A("按 C1 论文 §3.3 它记的是**膨胀矿渣轻骨料**，不是掺合料；而外部文献里同名的列是作为胶凝材料的 GGBS / 钢渣（102–204 kg/m³）。")
A(f"tier A+B 里列语义与训练集一致（slag = 0 或 > 1000）的有 **{R['tierAB']['n_slag_semantics_ok']} / {len(ab)}** 条；")
A(f"同时满足「11 列都在窗口内」且「slag 语义一致」的只剩 **{R['tierA']['n_strict']}** 条，已不足以支撑任何统计量——这一档因此不报 R²。\n")
A("**结论（分两种口径）**：")
A(f"- **全集口径**：tier A 上 R² = {rv['mean']:+.3f}，tier A+B 上 {g('tierAB',rec)['mean']:+.3f}。模型没有撑住。")
A(f"- **窗口内口径**：只有 {w['n_in_window']} 条行 11 列全部在训练窗口内，样本量太小、且这 12 行内部强度离散度很低（R² 分母塌缩），")
A("  所以窗口内的 R²（−5 至 −9）不能当作独立证据；它们的 RMSE（14.4–17.4 MPa）与全集 RMSE 同量级，")
A("  说明**误差不是单纯由协变量外移造成的**——即使退到窗口内，误差也没有回到论文里 6.6 MPa 的水平。\n")

A("## 6. 达标判定\n")
A("C1 论文的预设成功线是 **LOSO pooled R² ≥ 0.65**（与基线同口径）。把这条线原样搬到外部集上：\n")
A("| 口径 | n | 论文推荐配置的 R² | 全表最佳 R² | 达标 |")
A("|---|---:|---:|---:|:--:|")
for t, lab in [("tierA", "tier A（外部，全集）"), ("tierAB", "tier A+B（外部，全集）"),
               ("tierA_28d", "tier A，仅 28 d 龄期"), ("tierAB_28d", "tier A+B，仅 28 d 龄期")]:
    rr = g(t, rec); bb = max(ORDER, key=lambda n: (g(t, n) or {"mean": -9})["mean"])
    bbv = g(t, bb)
    A(f"| {lab} | {R[t]['n_external_complete']}（{R[t]['n_labs']} 簇） | {rr['mean']:+.3f} | {bbv['mean']:+.3f}（{bb}） | **否** |")
A("")
A("**四种口径全部不达标**，且多数配置的 R² 为负（不如直接预测训练集均值）。")
A("对照 C1 论文自己的表述：主折 0.825「达标」、严格折 0.347「不达标」、把模型选择也留出后 0.573「不达标」——")
A("外部验证给出的是第四个、也是最不留情面的数字。\n")

A("## 7. 写进论文怎么说\n")
A("### 中文（≤150 字）\n")
A("> 我们从 2015–2026 年公开文献另抽 "
  f"{len(ab)} 条碳化养护记录（{ab['lab_id'].nunique()} 个独立实验室簇），核验其与这 198 行在来源论文、实验室、数值三个层面均无重叠。"
  f"沿用本文已固定的超参直接外推，推荐模型的 pooled R² 由 0.825 降至 {rv['mean']:+.3f}（RMSE {g('tierA',rec,'all','rmse')['mean']:.1f} MPa），"
  f"与「直接预测训练均值」的常数预测子无异；跨研究校准的 90% 区间实际仅覆盖 {etc['coverage_all']:.0%}。"
  f"且 {R['tierA']['n_external_complete']} 条中仅 {w['n_in_window']} 条的全部变量落在训练窗口内。"
  "本基准的条件性达标不能外推到其数据窗口之外。\n")
A("### English (≤150 words)\n")
A("> To test whether 198 rows can support cross-study prediction, we assembled an independent external set from the "
  f"2015–2026 open literature: {len(ab)} carbonation-curing records from {ab['lab_id'].nunique()} laboratory clusters, verified to share no source paper, "
  "no laboratory and no near-duplicate values with the benchmark. Applying the models exactly as fixed in this paper — "
  f"no hyperparameter re-selection — pooled R² falls from +0.825 under LOSO to {rv['mean']:+.3f} "
  f"(RMSE {g('tierA',rec,'all','rmse')['mean']:.1f} MPa); the best of eleven configurations reaches {bv['mean']:+.3f}. "
  f"Conformal intervals calibrated across the training studies, {etc['width']:.0f} MPa wide at a nominal 90%, cover {etc['coverage_all']:.0%} of external rows. "
  f"Only {w['n_in_window']} of {w['n_external_complete']} external rows lie inside the training range on all eleven variables, and most of the "
  "literature does not report mixtures in kg/m³ at all. The benchmark's conditional pass therefore does not extend beyond its own data window.\n")

import re as _re2
_zh = [x for x in L if x.startswith("> 我们从 2015")][0]
_en = [x for x in L if x.startswith("> To test whether")][0]
_nzh = len(_re2.findall("[\u4e00-\u9fff]", _zh))
_nen = len(_en.split()) - 1
L[L.index("### 中文（≤150 字）\n")] = "### 中文（汉字 %d 字，≤150）\n" % _nzh
L[L.index("### English (≤150 words)\n")] = "### English (%d words, ≤150)\n" % _nen
A("## 8. 局限（必须与结果同读）\n")
A("1. **外部集不是文献总体的随机样本**：Elsevier / Taylor & Francis 对本机 403（见 `SEARCH_LOG.md` §5），"
  "而 244 篇候选里 104 篇是 Elsevier。外部集偏向金色 OA（MDPI / Springer OA / SciELO）。")
A(f"2. **样本量小**：tier A {R['tierA']['n_external_complete']} 条 / {R['tierA']['n_labs']} 个实验室簇（tier A+B {R['tierAB']['n_external_complete']} 条 / {R['tierAB']['n_labs']} 簇）。"
  "C1 论文自己指出 3 个折时「选择 146 个配置≈在 3 个数据点上选」，这里同样不足以做精细的模型间比较；"
  "结论只到「模型没有撑住」这一步，不到「某个模型比另一个好」。")
A(f"3. **协变量外移是真实存在的**：仅 {w['n_in_window']} / {w['n_external_complete']} 条全变量落在训练窗口内。失败**至少部分**源于窗口不重叠，"
  "但窗口内子集的 RMSE 并未回落到论文水平，说明外移不是唯一原因。")
A("4. **`slag` 列语义不一致**：训练集里是膨胀矿渣轻骨料，外部文献里是 GGBS / 钢渣掺合料。"
  "这既是本次验证的噪声源，也正是 C1 论文关于「字段口径」的论点的直接证据。")
A("5. **龄期口径**：C1 的目标是 28 d 强度，但外部文献大量只报碳化结束即测的强度。"
  "已单列「仅 28 d」口径（tier A 21 条 / tier A+B 42 条），结论一致。")
A("6. **tier B 的常压假设**：33 条记录的碳化压力未报，按常压舱填 0.1 MPa。"
  "tier A（不含这些行）与 tier A+B 的结论一致，故该假设不驱动结论。")
A("7. **图读数**：极少数记录来自**带印刷数据标签**的柱状图（flag `from_figure_with_printed_labels`）；"
  "无标签的图一律不收（C1 论文 §3.2 的 87.3 / 77.3 MPa 教训）。\n")

A("## 9. 复现\n")
A("```bash")
A("cd external_validation")
A("python3 scripts/search_openalex.py        # 主检索")
A("python3 scripts/screen.py && python3 scripts/rank.py")
A("python3 scripts/fetch3.py shortlist_fast.json fetch_log2.json 12")
A("python3 scripts/fetch3.py shortlist_slow.json  fetch_log_slow.json 12")
A("python3 scripts/fetch3.py shortlist_tier2.json fetch_log_t2.json   12")
A("python3 scripts/fetch3.py shortlist_tier3.json fetch_log_t3.json   12")
A("python3 scripts/unpaywall_green.py        # 绿色通道/机构库回捞")
A("python3 scripts/failures_and_manual.py    # -> raw/manual_download_list.json（403 清单）")
A("python3 scripts/totext.py                 # PDF -> 文本")
A("#（抽取按 EXTRACTION_BRIEF.md 逐篇进行，产物在 extract/batch_*.jsonl）")
A("python3 scripts/consolidate.py            # -> extracted_data.csv")
A("cd ../model_experiments")
A("for t in A AB A28 AB28; do C1_NJOBS=4 .venv/bin/python ../external_validation/scripts/run_extval.py $t; done")
A(".venv/bin/python ../external_validation/scripts/make_figs.py")
A("cd ../external_validation && python3 scripts/write_docs.py && python3 scripts/write_results.py")
A("```\n")
A("环境：与 `model_experiments/.venv` 同一套（Python 3.11 / numpy 2.4.6 / sklearn 1.6.1 / lightgbm 4.7.0 / tabpfn 2.2.1 / torch CPU）。纯 CPU，未用 GPU/MLX。")
open(os.path.join(EV, "EXTVAL_RESULTS.md"), "w").write("\n".join(L))
print("EXTVAL_RESULTS.md", len(L), "lines")
