#!/usr/bin/env python3
"""Fetch abstracts for OA hits, apply exclusion list, score for screening."""
import json, os, re, time, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "..", "raw")
MAIL = "mingmingye1992@gmail.com"

hits = json.load(open(os.path.join(RAW, "openalex_hits.json")))["hits"]
oa = {k: v for k, v in hits.items() if v["is_oa"] and (v["year"] or 0) >= 2015}
ids = list(oa)

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": f"C1-extval/1.0 (mailto:{MAIL})"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode())

abst = {}
for i in range(0, len(ids), 50):
    batch = ids[i:i+50]
    f = "openalex:" + "|".join(batch)
    url = ("https://api.openalex.org/works?filter=" + urllib.parse.quote(f, safe=":,|")
           + f"&per-page=50&select=id,abstract_inverted_index&mailto={MAIL}")
    d = fetch(url)
    for w in d["results"]:
        wid = w["id"].rsplit("/", 1)[-1]
        inv = w.get("abstract_inverted_index")
        if inv:
            pos = {}
            for tok, ps in inv.items():
                for p in ps:
                    pos[p] = tok
            abst[wid] = " ".join(pos[k] for k in sorted(pos))
    time.sleep(0.1)
    print(f"{i+len(batch)}/{len(ids)}", flush=True)

for k in oa:
    oa[k]["abstract"] = abst.get(k)
json.dump(oa, open(os.path.join(RAW, "oa_with_abstracts.json"), "w"), indent=1, ensure_ascii=False)
print("with abstract:", sum(1 for v in oa.values() if v.get("abstract")), "/", len(oa))
