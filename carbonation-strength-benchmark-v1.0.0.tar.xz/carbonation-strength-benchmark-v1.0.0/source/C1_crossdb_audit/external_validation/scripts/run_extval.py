#!/usr/bin/env python3
"""C1 外部验证：198 行全部作训练集，external_validation/extracted_data.csv 作测试集。

纪律（不得违反）：
- 超参与模型选择**一律沿用 C1 论文里已固定的**，不在新数据上重选。
- 特征工程复用 model_experiments/common.py 的 make_features（纯逐行变换，无跨行统计量）。
- 单位调和规则（total<1200 → rescale ×2200/total）对训练/测试一视同仁。
- conformal 校准残差只来自 198 行训练集（inner LOGO / 随机 5 折两种口径），测试集从不参与任何拟合。
"""
import sys, os, json, warnings
import numpy as np, pandas as pd
warnings.filterwarnings("ignore")
for _v in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
HERE = os.path.dirname(os.path.abspath(__file__))
ME = os.path.join(HERE, "..", "..", "model_experiments")
sys.path.insert(0, ME)
import common as C
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.model_selection import LeaveOneGroupOut, KFold
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from scipy.optimize import nnls
import lightgbm as lgb

OUT = os.path.join(HERE, "..", "results"); os.makedirs(OUT, exist_ok=True)
CSV = os.path.join(HERE, "..", "extracted_data.csv")
SEEDS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
SEEDS5 = [0, 1, 2, 3, 4]
MONO_RAW = {"W/B": -1, "T": 1, "CC": 1}

# ---------------------------------------------------------------- 论文里固定的模型
def mk_rf(seed, **kw):  p = dict(n_estimators=300, random_state=seed, n_jobs=1); p.update(kw); return RandomForestRegressor(**p)
def mk_et(seed, **kw):  p = dict(n_estimators=300, random_state=seed, n_jobs=1); p.update(kw); return ExtraTreesRegressor(**p)
def mk_hgb(seed):       return HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=5, random_state=seed)
def mk_lgbm(seed):
    return lgb.LGBMRegressor(num_leaves=8, min_child_samples=5, learning_rate=0.05, n_estimators=300, subsample=0.8,
                             subsample_freq=1, colsample_bytree=0.8, random_state=seed, verbose=-1, n_jobs=1,
                             monotone_constraints=[MONO_RAW.get(c, 0) for c in C.RAW_COLS],
                             monotone_constraints_method="advanced")
class TabPFNWrap:
    def __init__(self, seed):
        import torch; torch.set_num_threads(1)
        from tabpfn import TabPFNRegressor
        self.m = TabPFNRegressor(device="cpu", random_state=seed)
    def fit(self, X, y): self.m.fit(np.asarray(X, float), np.asarray(y, float)); return self
    def predict(self, X): return np.asarray(self.m.predict(np.asarray(X, float)), float)

CONFIGS = {
    "RF300 raw flagged (baseline)":        dict(mk=lambda s: mk_rf(s), harm="flag",    seeds=SEEDS),
    "RF300 raw rescaled":                  dict(mk=lambda s: mk_rf(s), harm="rescale", seeds=SEEDS),
    "ET300 raw rescaled (recommended)":    dict(mk=lambda s: mk_et(s), harm="rescale", seeds=SEEDS),
    "ET300 raw flagged":                   dict(mk=lambda s: mk_et(s), harm="flag",    seeds=SEEDS),
    "ET300 max_features=1/3 rescaled":     dict(mk=lambda s: mk_et(s, max_features=1/3), harm="rescale", seeds=SEEDS),
    "HGB raw rescaled":                    dict(mk=mk_hgb,             harm="rescale", seeds=SEEDS5),
    "LGBM-mono raw rescaled":              dict(mk=mk_lgbm,            harm="rescale", seeds=SEEDS5),
    "TabPFN v2 raw flagged":               dict(mk=lambda s: TabPFNWrap(0), harm="flag",    seeds=[0]),
    "TabPFN v2 raw rescaled":              dict(mk=lambda s: TabPFNWrap(0), harm="rescale", seeds=[0]),
}
STACK_CANDS = ["ET300 raw rescaled (recommended)", "HGB raw rescaled", "LGBM-mono raw rescaled", "TabPFN v2 raw rescaled"]

def metrics(y, p):
    y = np.asarray(y, float); p = np.asarray(p, float)
    d = dict(n=int(len(y)), rmse=float(np.sqrt(mean_squared_error(y, p))), mae=float(mean_absolute_error(y, p)))
    d["r2"] = float(r2_score(y, p)) if len(y) > 1 and np.var(y) > 0 else None
    d["bias"] = float(np.mean(p - y))
    return d

# ---------------------------------------------------------------- 数据
def load_external(tiers=("A_complete",), age28=False):
    df = pd.read_csv(CSV)
    df = df[df["tier"].isin(tiers)]
    if age28:
        df = df[pd.to_numeric(df["cs_age_d"], errors="coerce") == 28]
    df = df.reset_index(drop=True)
    if "P_MPa_model" in df.columns:
        df["P_MPa"] = pd.to_numeric(df["P_MPa_model"], errors="coerce")
    ren = {"slag": "blast furnace slag", "fly_ash": "fly ash", "W_B": "W/B",
           "steam_h": "CCU-steam curing time", "T_h": "T", "P_MPa": "P", "CS_MPa": "CS"}
    df = df.rename(columns=ren)
    for c in C.RAW_COLS + ["CS"]:
        if c not in df.columns: df[c] = np.nan
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df

def main(tiers=("A_complete",), tag="tierA", age28=False):
    ext = load_external(tiers, age28)
    y_tr = C.Y
    res = {"_desc": "C1 external validation: train on all 198 rows, test on newly extracted external records",
           "tiers": list(tiers), "tag": tag, "age28_only": age28,
           "n_external_all": int(len(ext)), "runs": {}}

    complete = ext[C.RAW_COLS].notna().all(axis=1) & ext["CS"].notna()
    ext_c = ext[complete].reset_index(drop=True)
    res["n_external_complete"] = int(len(ext_c))
    print(f"external: {len(ext)} rows, complete-case {len(ext_c)}")

    # 覆盖窗口（用 198 行的 min/max 定义）
    tr_raw = C._df[C.RAW_COLS]
    lo, hi = tr_raw.min(), tr_raw.max()
    inwin = pd.Series(True, index=ext_c.index)
    per_col = {}
    for c in C.RAW_COLS:
        ok = (ext_c[c] >= lo[c]) & (ext_c[c] <= hi[c])
        per_col[c] = dict(train_min=float(lo[c]), train_max=float(hi[c]),
                          ext_min=float(ext_c[c].min()), ext_max=float(ext_c[c].max()),
                          n_outside=int((~ok).sum()))
        inwin &= ok
    res["window"] = per_col
    res["n_in_window"] = int(inwin.sum())
    slagok = ext_c["slag_semantics_ok"].astype(bool).values if "slag_semantics_ok" in ext_c else np.ones(len(ext_c), bool)
    ext_c = ext_c.assign(_inwin=inwin.values, _slagok=slagok, _strict=(inwin.values & slagok))
    res["n_slag_semantics_ok"] = int(slagok.sum()); res["n_strict"] = int((inwin.values & slagok).sum())
    res["n_labs"] = int(pd.Series(ext_c["lab_id"] if "lab_id" in ext_c else ext_c["doi"]).nunique())
    print(f"slag-semantics-consistent: {slagok.sum()}  strict(in-window & slag-ok): {(inwin.values & slagok).sum()}")
    print(f"in-window rows: {inwin.sum()}/{len(ext_c)}")

    groups_ext = (ext_c["lab_id"] if "lab_id" in ext_c else ext_c["doi"]).astype(str).fillna("UNKNOWN").values
    preds_store = {}

    for name, cfg in CONFIGS.items():
        print(f"\n### {name}", flush=True)
        ps = []
        for s in cfg["seeds"]:
            Xtr = C.make_features(C._df, "raw", cfg["harm"])
            Xte = C.make_features(ext_c, "raw", cfg["harm"])
            m = cfg["mk"](s); m.fit(Xtr, y_tr)
            ps.append(np.asarray(m.predict(Xte), float))
        P = np.array(ps)
        preds_store[name] = P
        yt = ext_c["CS"].values
        per_seed_all = [metrics(yt, p) for p in P]
        per_seed_win = [metrics(yt[ext_c["_inwin"].values], p[ext_c["_inwin"].values]) for p in P] if inwin.sum() > 2 else []
        per_seed_str = [metrics(yt[ext_c["_strict"].values], p[ext_c["_strict"].values]) for p in P] if ext_c["_strict"].sum() > 2 else []
        def agg(lst, k):
            v = [x[k] for x in lst if x[k] is not None]
            return dict(mean=float(np.mean(v)), sd=float(np.std(v, ddof=1)) if len(v) > 1 else 0.0) if v else None
        run = dict(harm=cfg["harm"], n_seeds=len(cfg["seeds"]),
                   all={k: agg(per_seed_all, k) for k in ("r2", "rmse", "mae", "bias")},
                   in_window={k: agg(per_seed_win, k) for k in ("r2", "rmse", "mae", "bias")} if per_seed_win else None,
                   strict={k: agg(per_seed_str, k) for k in ("r2", "rmse", "mae", "bias")} if per_seed_str else None,
                   by_study={})
        pm = P.mean(axis=0)
        for g in sorted(set(groups_ext)):
            i = groups_ext == g
            run["by_study"][g] = metrics(yt[i], pm[i])
        run["pred_mean"] = pm.tolist()
        res["runs"][name] = run
        r2 = run["all"]["r2"]
        print(f"   all: R²={r2['mean']:+.3f}±{r2['sd']:.3f}  RMSE={run['all']['rmse']['mean']:.2f}  MAE={run['all']['mae']['mean']:.2f}  bias={run['all']['bias']['mean']:+.2f}")
        if run["in_window"] and run["in_window"]["r2"]:
            w = run["in_window"]
            print(f"   win: R²={w['r2']['mean']:+.3f}  RMSE={w['rmse']['mean']:.2f}  (n={inwin.sum()})")
        json.dump(res, open(os.path.join(OUT, f"extval_{tag}.json"), "w"), indent=1, ensure_ascii=False)

    # ------------------------------------------------ stack-NNLS / uniform-mean（权重只来自 198 行的 inner LOGO）
    print("\n### stacking (weights from inner LOGO on the 198 training rows only)")
    G = C.INNER_GROUP
    oof = {}; oof_rand = {}
    for name in STACK_CANDS:
        cfg = CONFIGS[name]
        Xtr = C.make_features(C._df, "raw", cfg["harm"])
        s = cfg["seeds"][0]
        o = np.full(198, np.nan)
        for itr, ite in LeaveOneGroupOut().split(Xtr, y_tr, G):
            m = cfg["mk"](s); m.fit(Xtr.iloc[itr], y_tr[itr]); o[ite] = m.predict(Xtr.iloc[ite])
        oof[name] = o
        orr = np.full(198, np.nan)
        for itr, ite in KFold(5, shuffle=True, random_state=s).split(Xtr):
            m = cfg["mk"](s); m.fit(Xtr.iloc[itr], y_tr[itr]); orr[ite] = m.predict(Xtr.iloc[ite])
        oof_rand[name] = orr
    A = np.column_stack([oof[n] for n in STACK_CANDS])
    w, _ = nnls(A, y_tr); w = w / w.sum() if w.sum() > 0 else np.ones(len(STACK_CANDS)) / len(STACK_CANDS)
    res["stack_weights"] = dict(zip(STACK_CANDS, map(float, w)))
    res["inner_logo_rmse"] = {n: float(np.sqrt(np.mean((y_tr - oof[n]) ** 2))) for n in STACK_CANDS}
    T = np.column_stack([preds_store[n].mean(axis=0) for n in STACK_CANDS])
    yt = ext_c["CS"].values
    for nm, p in [("stack-NNLS", T @ w), ("uniform-mean of 4 candidates", T.mean(axis=1))]:
        m_all = metrics(yt, p)
        m_win = metrics(yt[ext_c["_inwin"].values], p[ext_c["_inwin"].values]) if inwin.sum() > 2 else None
        m_str = metrics(yt[ext_c["_strict"].values], p[ext_c["_strict"].values]) if ext_c["_strict"].sum() > 2 else None
        res["runs"][nm] = dict(harm="rescale", n_seeds=1,
                               all={k: (dict(mean=m_all[k], sd=0.0) if m_all[k] is not None else None) for k in ("r2","rmse","mae","bias")},
                               in_window={k: (dict(mean=m_win[k], sd=0.0) if m_win and m_win[k] is not None else None) for k in ("r2","rmse","mae","bias")} if m_win else None,
                               strict={k: (dict(mean=m_str[k], sd=0.0) if m_str and m_str[k] is not None else None) for k in ("r2","rmse","mae","bias")} if m_str else None,
                               by_study={g: metrics(yt[groups_ext == g], p[groups_ext == g]) for g in sorted(set(groups_ext))},
                               pred_mean=p.tolist())
        preds_store[nm] = p[None, :]
        print(f"   {nm}: R²={m_all['r2']:+.3f} RMSE={m_all['rmse']:.2f} MAE={m_all['mae']:.2f}")

    # ------------------------------------------------ conformal
    print("\n### conformal (calibrated on the 198 training rows only)")
    def q_conf(absres, alpha):
        a = np.sort(absres[~np.isnan(absres)]); n = len(a)
        k = min(int(np.ceil((n + 1) * (1 - alpha))), n); return float(a[k - 1])
    conf = []
    for name in STACK_CANDS:
        for alpha in (0.1, 0.2):
            for cal, rr in (("cross-study(LOGO)", np.abs(y_tr - oof[name])),
                            ("random-5fold", np.abs(y_tr - oof_rand[name]))):
                q = q_conf(rr, alpha)
                p = preds_store[name].mean(axis=0)
                cov = float(np.mean(np.abs(yt - p) <= q))
                covw = float(np.mean(np.abs(yt[ext_c["_inwin"].values] - p[ext_c["_inwin"].values]) <= q)) if inwin.sum() else None
                conf.append(dict(model=name, alpha=alpha, calib=cal, q=q, width=2 * q,
                                 coverage_all=cov, coverage_in_window=covw,
                                 coverage_strict=float(np.mean(np.abs(yt[ext_c["_strict"].values] - p[ext_c["_strict"].values]) <= q)) if ext_c["_strict"].sum() else None,
                                 nominal=1 - alpha))
                print(f"   {name:35s} a={alpha} {cal:18s} width={2*q:6.1f} cov_all={cov:.2f}" + (f" cov_win={covw:.2f}" if covw is not None else ""))
    # stack conformal
    A_oof = np.column_stack([oof[n] for n in STACK_CANDS]) @ w
    A_rand = np.column_stack([oof_rand[n] for n in STACK_CANDS]) @ w
    for alpha in (0.1, 0.2):
        for cal, rr in (("cross-study(LOGO)", np.abs(y_tr - A_oof)), ("random-5fold", np.abs(y_tr - A_rand))):
            q = q_conf(rr, alpha); p = preds_store["stack-NNLS"][0]
            cov = float(np.mean(np.abs(yt - p) <= q))
            covw = float(np.mean(np.abs(yt[ext_c["_inwin"].values] - p[ext_c["_inwin"].values]) <= q)) if inwin.sum() else None
            conf.append(dict(model="stack-NNLS", alpha=alpha, calib=cal, q=q, width=2 * q,
                             coverage_all=cov, coverage_in_window=covw, nominal=1 - alpha))
            print(f"   {'stack-NNLS':35s} a={alpha} {cal:18s} width={2*q:6.1f} cov_all={cov:.2f}" + (f" cov_win={covw:.2f}" if covw is not None else ""))
    res["conformal"] = conf
    res["external_rows"] = ext_c.to_dict(orient="records")
    res["_env"] = C.env_info()
    json.dump(res, open(os.path.join(OUT, f"extval_{tag}.json"), "w"), indent=1, ensure_ascii=False, default=str)
    print("\nwrote", os.path.join(OUT, f"extval_{tag}.json"))

if __name__ == "__main__":
    import sys
    t = sys.argv[1] if len(sys.argv) > 1 else "A"
    A = ("A_complete",); AB = ("A_complete", "B_P_imputed_ambient")
    tab = {"A": (A, "tierA", False), "AB": (AB, "tierAB", False),
           "A28": (A, "tierA_28d", True), "AB28": (AB, "tierAB_28d", True)}
    if t not in tab: raise SystemExit("usage: run_extval.py [A|AB|A28|AB28]")
    main(*tab[t])
