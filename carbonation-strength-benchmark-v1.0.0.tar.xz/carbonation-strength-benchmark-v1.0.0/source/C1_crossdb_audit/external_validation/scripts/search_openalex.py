#!/usr/bin/env python3
"""OpenAlex sweep for carbonation-curing compressive-strength papers, 2015-2026."""
import json, time, urllib.parse, urllib.request, os, sys

MAIL = "mingmingye1992@gmail.com"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "raw", "openalex_hits.json")

QUERIES = [
    # (label, search string used in title_and_abstract.search)
    ("q1",  '"carbonation curing" AND "compressive strength"'),
    ("q2",  '"CO2 curing" AND "compressive strength"'),
    ("q3",  '"accelerated carbonation" AND "compressive strength" AND concrete'),
    ("q4",  '"carbonation curing" AND concrete'),
    ("q5",  '"carbonation curing" AND mortar'),
    ("q6",  '"CO2 curing" AND (concrete OR mortar OR "cement paste")'),
    ("q7",  '"carbon dioxide curing" AND concrete'),
    ("q8",  '"early-age carbonation" AND concrete'),
    ("q9",  '"carbonation cured" AND strength'),
    ("q10", '"CO2 uptake" AND "carbonation curing" AND strength'),
    ("q11", '"carbonation curing" AND "compressive strength" AND (block OR brick OR "masonry unit")'),
    ("q12", '"accelerated carbonation curing"'),
    ("q13", '"CO2 curing" AND "steel slag"'),
    ("q14", '"carbonation curing" AND "recycled aggregate"'),
    ("q15", '"carbonation curing" AND "fly ash"'),
    ("q16", '"carbonation curing" AND "slag"'),
    ("q17", '"CO2 curing" AND "cement paste"'),
    ("q18", '"carbonation curing" AND "pressure"'),
]

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": f"C1-extval/1.0 (mailto:{MAIL})"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode())

hits = {}
log = []
for label, q in QUERIES:
    cursor = "*"
    n = 0
    total = None
    while True:
        f = f"title_and_abstract.search:{q},from_publication_date:2015-01-01,type:article"
        url = ("https://api.openalex.org/works?filter=" + urllib.parse.quote(f, safe=":,")
               + f"&per-page=200&cursor={cursor}&mailto={MAIL}")
        try:
            d = fetch(url)
        except Exception as e:
            log.append(f"{label}\tERROR\t{e}")
            break
        if total is None:
            total = d["meta"]["count"]
        for w in d["results"]:
            wid = w["id"].rsplit("/", 1)[-1]
            rec = hits.setdefault(wid, {
                "openalex": wid,
                "doi": (w.get("doi") or "").replace("https://doi.org/", "") or None,
                "title": w.get("title"),
                "year": w.get("publication_year"),
                "venue": ((w.get("primary_location") or {}).get("source") or {}).get("display_name"),
                "publisher": ((w.get("primary_location") or {}).get("source") or {}).get("host_organization_name"),
                "oa_status": (w.get("open_access") or {}).get("oa_status"),
                "is_oa": (w.get("open_access") or {}).get("is_oa"),
                "oa_url": (w.get("best_oa_location") or {}).get("pdf_url") or (w.get("open_access") or {}).get("oa_url"),
                "landing": (w.get("best_oa_location") or {}).get("landing_page_url"),
                "license": (w.get("best_oa_location") or {}).get("license"),
                "authors": [a["author"]["display_name"] for a in (w.get("authorships") or [])][:12],
                "institutions": sorted({i["display_name"] for a in (w.get("authorships") or []) for i in (a.get("institutions") or [])}),
                "cited_by": w.get("cited_by_count"),
                "queries": [],
            })
            if label not in rec["queries"]:
                rec["queries"].append(label)
            n += 1
        cursor = d["meta"].get("next_cursor")
        if not cursor or not d["results"]:
            break
        time.sleep(0.12)
    log.append(f"{label}\t{q}\ttotal={total}\tcollected={n}")
    print(log[-1], flush=True)

os.makedirs(os.path.dirname(OUT), exist_ok=True)
json.dump({"queries": [{"label": l, "q": q} for l, q in QUERIES], "log": log, "hits": hits},
          open(OUT, "w"), indent=1, ensure_ascii=False)
print("unique works:", len(hits))
oa = [h for h in hits.values() if h["is_oa"]]
print("OA:", len(oa))
