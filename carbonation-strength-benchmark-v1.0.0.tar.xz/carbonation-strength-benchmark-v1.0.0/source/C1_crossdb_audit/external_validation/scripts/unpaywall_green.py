#!/usr/bin/env python3
"""For every failed DOI, ask Unpaywall + OpenAlex for a repository (green) copy and try to fetch it."""
import json, os, re, sys, time, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__)); RAW = os.path.join(HERE,"..","raw"); FT = os.path.join(HERE,"..","fulltext")
MAIL = "mingmingye1992@gmail.com"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36"
BLOCK = ("sciencedirect.com","elsevier.com","tandfonline.com","onlinelibrary.wiley.com","pubs.acs.org",
         "iopscience.iop.org","journals.sagepub.com","icevirtuallibrary.com","ascelibrary.org","link.springer.com/article")
def get(u,t=25,accept="*/*"):
    r=urllib.request.Request(u,headers={"User-Agent":UA,"Accept":accept})
    with urllib.request.urlopen(r,timeout=t) as f: return f.read()
def work(rec):
    doi=(rec.get("doi") or "").lower()
    if not doi: return dict(doi=None, status="FAIL", note="no doi")
    name=re.sub(r"[^A-Za-z0-9]+","_",doi)[:90]
    p=os.path.join(FT,name+".pdf")
    if os.path.exists(p) and os.path.getsize(p)>20000: return dict(doi=doi,status="cached")
    urls=[]
    try:
        d=json.loads(get(f"https://api.unpaywall.org/v2/{doi}?email={MAIL}",25).decode())
        for loc in (d.get("oa_locations") or []):
            for k in ("url_for_pdf","url"):
                u=loc.get(k)
                if u and not any(b in u for b in BLOCK): urls.append(u)
    except Exception as e: pass
    try:
        d=json.loads(get(f"https://api.openalex.org/works/doi:{doi}?mailto={MAIL}",25).decode())
        for loc in (d.get("locations") or []):
            for k in ("pdf_url","landing_page_url"):
                u=loc.get(k)
                if u and not any(b in u for b in BLOCK): urls.append(u)
    except Exception: pass
    seen=set(); errs=[]
    for u in urls:
        if u in seen: continue
        seen.add(u)
        try:
            b=get(u,25)
            if b[:5]==b"%PDF-" and len(b)>20000:
                open(p,"wb").write(b); return dict(doi=doi,status="pdf",url=u,bytes=len(b),file=name+".pdf")
            errs.append(f"{u} -> not pdf ({len(b)}B)")
        except urllib.error.HTTPError as e: errs.append(f"{u} -> HTTP {e.code}")
        except Exception as e: errs.append(f"{u} -> {type(e).__name__}")
    return dict(doi=doi,status="FAIL",tried=sorted(seen),errors=errs)
fails=json.load(open(os.path.join(RAW,"fetch_failures.json")))
out=[]
with ThreadPoolExecutor(max_workers=10) as ex:
    for i,r in enumerate(ex.map(work,fails)):
        out.append(r)
        if r["status"]!="FAIL": print(f"[{i+1}/{len(fails)}] GREEN {r['doi']} {r.get('url','')[:90]}",flush=True)
json.dump(out,open(os.path.join(RAW,"green_log.json"),"w"),indent=1,ensure_ascii=False)
import collections; print(collections.Counter(r["status"] for r in out))
