# SEARCH_LOG —— C1 外部验证集的文献检索与全文获取记录

检索执行日期：**2026-09-18**。全部检索由脚本发起并落盘原始响应；本文件的每个数字都来自 `raw/*.json`，无一手写。

脚本：`scripts/search_openalex.py`（主检索）、`scripts/search_other.py`（Crossref / Europe PMC / Semantic Scholar 补检）、
`scripts/screen.py` + `scripts/rank.py`（摘要抓取与筛选打分）、`scripts/fetch3.py`（出版商感知的全文抓取）、`scripts/unpaywall_green.py`（绿色通道/机构库回捞）。

## 1. 目标与纳入标准

找 2015–2026 年报告**碳化养护（carbonation curing / CO₂ curing / accelerated carbonation curing）水泥基材料抗压强度**、
且**表格里同时给出配合比与养护参数**的原始试验论文，用作 C1 那 198 行的外部测试集。

纳入需同时满足：① 含波特兰水泥（或掺合水泥）的胶凝体系；② 试件本身经过 CO₂/碳化养护（**只碳化原料粉体或骨料的不算**）；
③ 抗压强度是**原文印出来的数字**（表格，或带数据标签的图）；④ 配合比最好是 kg/m³。

## 2. OpenAlex 主检索（18 条检索式，`title_and_abstract.search`，`from_publication_date:2015-01-01`，`type:article`）

| # | 检索式 | OpenAlex 命中总数 | 收回 |
|---|---|---:|---:|
| q1 | `"carbonation curing" AND "compressive strength"` | 443 | 443 |
| q2 | `"CO2 curing" AND "compressive strength"` | 232 | 232 |
| q3 | `"accelerated carbonation" AND "compressive strength" AND concrete` | 296 | 296 |
| q4 | `"carbonation curing" AND concrete` | 315 | 315 |
| q5 | `"carbonation curing" AND mortar` | 129 | 129 |
| q6 | `"CO2 curing" AND (concrete OR mortar OR "cement paste")` | 274 | 274 |
| q7 | `"carbon dioxide curing" AND concrete` | 21 | 21 |
| q8 | `"early-age carbonation" AND concrete` | 19 | 19 |
| q9 | `"carbonation cured" AND strength` | 620 | 621 |
| q10 | `"CO2 uptake" AND "carbonation curing" AND strength` | 64 | 64 |
| q11 | `"carbonation curing" AND "compressive strength" AND (block OR brick OR "masonry unit")` | 32 | 32 |
| q12 | `"accelerated carbonation curing"` | 160 | 160 |
| q13 | `"CO2 curing" AND "steel slag"` | 17 | 17 |
| q14 | `"carbonation curing" AND "recycled aggregate"` | 26 | 26 |
| q15 | `"carbonation curing" AND "fly ash"` | 85 | 85 |
| q16 | `"carbonation curing" AND "slag"` | 199 | 199 |
| q17 | `"CO2 curing" AND "cement paste"` | 68 | 68 |
| q18 | `"carbonation curing" AND "pressure"` | 89 | 89 |

去重后 **1266 篇**唯一文献；其中 OpenAlex 标记 OA 的 **536 篇**。

对 536 篇 2015+ OA 文献补抓摘要（OpenAlex `abstract_inverted_index`），成功 485 篇。

## 3. 补充检索（覆盖性检查）

| 数据源 | 检索式 | 结果 |
|---|---|---|
| crossref | `"carbonation curing" "compressive strength"` | total=208018 / collected=400 |
| crossref | `"CO2 curing" concrete "compressive strength"` | total=439387 / collected=400 |
| crossref | `"accelerated carbonation curing" mix proportion` | total=83234 / collected=400 |
| crossref | `"carbonation curing" "mix proportion"` | total=47134 / collected=400 |
| crossref | `"CO2 curing" "mix proportions"` | total=132540 / collected=400 |
| epmc | `"carbonation curing" AND "compressive strength"` | hitCount=130 / collected=130 |
| epmc | `"CO2 curing" AND concrete` | hitCount=104 / collected=104 |
| epmc | `"accelerated carbonation" AND "compressive strength" AND concrete` | hitCount=292 / collected=292 |
| s2 carbonation curing compressive strength concrete off0 ERR HTTPError HTTP Error 429:  | — | s2 carbonation curing compressive strength concrete off0 ERR HTTPError HTTP Error 429:  |
| s2 | `carbonation curing compressive strength concrete` | collected=0 |
| s2 CO2 curing concrete mix proportion compressive strength off0 ERR HTTPError HTTP Error 429:  | — | s2 CO2 curing concrete mix proportion compressive strength off0 ERR HTTPError HTTP Error 429:  |
| s2 | `CO2 curing concrete mix proportion compressive strength` | collected=0 |

- Crossref 收回 1364 条、Europe PMC 421 条。
- **Semantic Scholar API 返回 HTTP 429（无 key 限流），两次检索均 0 条**，照实记录，未以任何方式补数。
- 交叉核对：Crossref 里标题含碳化养护关键词且 2015+ 的 415 条中，**92 条不在 OpenAlex 命中集内**；Europe PMC 的 34 条里 10 条不在。这 102 条已并入第 5 节的 tier-3 抓取。

## 4. 防污染排除（在抓全文之前）

排除依据 `probe/cscm_sources.json` 的 26 个来源 DOI，以及这些来源背后的实验室 PI 名单（Shao/El-Hassan/Rostami/Zhang Duo/Liu Tiefeng/Morshed/Ghouleh/Xian/Mahoutian/Lee Ming-Gin/Wang Yung-Chih/Kan/Kao/Chen Tiefeng/Gao Xiaojian/Sharma/Goyal/Sidhu，以及 198 行那三篇 ML 论文的作者 Chu Jia/Niu Ditao/Guo Bingbing）。

| 排除原因 | 篇数 |
|---|---:|
| `EXCL_AUTHOR:duo zhang` | 7 |
| `EXCL_AUTHOR:hilal el-hassan` | 5 |
| `EXCL_AUTHOR:ditao niu` | 4 |
| `EXCL_AUTHOR:yixin shao` | 3 |
| `SOURCE_OF_198` | 2 |
| `EXCL_AUTHOR:jia chu` | 2 |
| `EXCL_AUTHOR:yung-chih wang` | 1 |
| `EXCL_AUTHOR:tiefeng chen` | 1 |
| `EXCL_AUTHOR:xiaojian gao` | 1 |
| `EXCL_AUTHOR:shweta goyal` | 1 |
| **合计** | **27** |

筛选打分后（关键词加权、综述/纯建模减分），得 **244 篇**候选（score ≥ 7 且未被排除）。

## 5. 全文获取：成败与 403 清单

### 5.1 出版商可达性（实测，2026-09-18）

| 出版商 / 通道 | 实测结果 |
|---|---|
| **MDPI** `www.mdpi.com/.../pdf` | **HTTP 403** |
| **MDPI** `mdpi-res.com/d_attachment/<刊>/<刊>-<卷:02d>-<文号:05d>/article_deploy/....pdf` | **200，可用**（本次 OA 全文的主要来源） |
| **Elsevier / ScienceDirect** `doi.org/10.1016/...` | 302 → 2.7 KB 重定向壳页，非全文 |
| **Elsevier** `sciencedirect.com/.../pdfft` | **HTTP 403**（实测） |
| **Elsevier** `api.elsevier.com/content/article/doi/...` | 200 但仅 coredata 元数据；`?view=FULL` 返回 `AUTHENTICATION_ERROR / Invalid API Key` |
| **Taylor & Francis** `doi.org/10.1080/...` | **HTTP 403** |
| **Springer / Nature OA** `link.springer.com/content/pdf/<doi>.pdf` | 200，可用 |
| **Europe PMC** `/{PMCID}/fullTextXML` | 200，可用（PMC 收录的 MDPI/BMC/ACS 部分） |
| **Frontiers / SciELO / 各开放期刊** | 多数 200 |

**结论：Elsevier（ScienceDirect）与 Taylor & Francis 对本机 403，无法自动取全文**——与任务书的预判一致。其全文只能由用户手动下载（第 6 节清单）。

### 5.2 抓取批次

| 批次 | 候选数 | 取到全文 |
|---|---:|---:|
| tier-1 可达出版商（score ≥ 7） | 121 | 94 |
| tier-1 受限出版商（score ≥ 7，主要是 Elsevier） | 123 | 7 |
| tier-2（score 4–6，可达出版商） | 71 | 60 |
| tier-3（Crossref/EPMC 独有命中） | 34 | 21 |
| 绿色通道回捞（Unpaywall + OpenAlex `locations` 机构库副本） | 167 篇失败件 | 15 |
| **合计取到全文** | — | **197** |

取到的 197 篇全文用 `pdftotext -layout` 转文本（保留表格对齐）后进入人工/代理抽取（规程见 `EXTRACTION_BRIEF.md`）。

## 6. 需要用户手动下载的文献清单（403 / 取不到全文，但标题显示很可能有可用数据）

下列 **71** 篇通过了标题级筛选（碳化养护 + 强度/混凝土，排除综述与纯建模），但本机取不到全文。
其中 49 篇是 Elsevier（ScienceDirect 403）。**没有为任何一篇编造数据。**

| # | 年 | DOI | 期刊 | 标题 |
|---:|---:|---|---|---|
| 1 | 2026 | `10.1016/j.cscm.2026.e05779` | Case Studies in Construction Mater | Enhancing early strength of cement mortar using MSWI fly ash under accelerated carbonation c |
| 2 | 2026 | `10.1016/j.dibe.2026.100936` | Developments in the Built Environm | Influence of carbonation curing on chloride penetration resistance and pore structure refine |
| 3 | 2026 | `10.1016/j.cscm.2026.e06430` | Case Studies in Construction Mater | Synergistic regulation of thermal insulation and mechanical performance of aerogel foam conc |
| 4 | 2026 | `10.1016/j.rinma.2026.101032` | Results in Materials | Industrially relevant early-age carbonation curing of high-calcium fly ash blended mortars:  |
| 5 | 2026 | `10.1016/j.rineng.2026.109455` | Results in Engineering | Multi-response optimization of early-age CO2 curing conditions for enhanced carbon sequestra |
| 6 | 2026 | `10.1016/j.rineng.2026.110473` | Results in Engineering | Enhanced strength and carbon sequestration in CO2-cured alkali-activated slag (AAS) through  |
| 7 | 2026 | `10.1016/j.scp.2026.102542` | Sustainable Chemistry and Pharmacy | Synergistic effects of pre-conditioning and CO2 curing parameters on the alkalinity, microst |
| 8 | 2026 | `10.1016/j.cscm.2026.e06048` | Case Studies in Construction Mater | Mechanical properties and carbon sequestration performance of cemented paste backfill under  |
| 9 | 2025 | `10.47836/pjst.33.2.07` | Pertanika journal of science & tec | Performance of High-volume Carbide Lime Mortar Under Accelerated CO2 Curing Followed by Post |
| 10 | 2025 | `10.59440/ceer/200891` | Civil And Environmental Engineerin | Optimising The Performance of Carbide Lime Waste Mortar: The Role of Temperature in Accelera |
| 11 | 2025 | `10.6084/m9.figshare.30724589.v1` | Figshare | Performance evaluation and predictive modeling of pervious concrete under variable CO2 curin |
| 12 | 2025 | `10.6084/m9.figshare.30724589` | Figshare | Performance evaluation and predictive modeling of pervious concrete under variable CO2 curin |
| 13 | 2025 | `10.1016/j.jobe.2025.112683` | Journal of Building Engineering | Effects of low-lime calcium silicate cement addition on the hydration, carbonation, and micr |
| 14 | 2025 | `10.1016/j.dibe.2025.100725` | Developments in the Built Environm | Effect of pre-conditioning on the carbonation curing characteristics of belite-rich cement p |
| 15 | 2025 | `10.1016/j.dibe.2025.100805` | Developments in the Built Environm | From waste to value: Enhancing strength and CO2 sequestration of cement composites with lime |
| 16 | 2025 | `10.1016/j.asej.2025.103476` | Ain Shams Engineering Journal | Effect of the CO2 curing on a certain recycled concrete with the mineral-added binary and te |
| 17 | 2025 | `10.1016/j.ccst.2025.100368` | Carbon Capture Science & Technolog | A novel insight into CO2-cured cement modified by ultrasonic carbonated waste incineration f |
| 18 | 2025 | `10.1016/j.jcou.2025.103221` | Journal of CO2 Utilization | Evolution of properties and microstructure of recycled aggregate mortars containing rice hus |
| 19 | 2025 | `10.1016/j.cscm.2025.e04709` | Case Studies in Construction Mater | Unraveling the microstructural evolution of cement paste in different zones after CO2 curing |
| 20 | 2024 | `10.1016/j.dibe.2024.100397` | Developments in the Built Environm | Compressive strength development and microstructure evolution of mortars prepared using reac |
| 21 | 2024 | `10.1016/j.cscm.2024.e03251` | Case Studies in Construction Mater | Effects of carbonation curing on chemical attack in cement paste incorporating liquid-crysta |
| 22 | 2024 | `(无 DOI)` | International Journal of Sustainab | Performance of Carbide Lime Waste Mortar via 24 Hours Accelerated CO2 Curing |
| 23 | 2023 | `10.4028/p-h8kwpf` | Key engineering materials | Effectiveness of Carbide Lime Waste as CO2 Capturing Materials of Mortar at Early CO2 Curing |
| 24 | 2023 | `10.1016/j.conbuildmat.2023.131330` | Construction and Building Material | Flue gas carbonation curing of steel slag blocks: Effects of residual heat and water vapor |
| 25 | 2023 | `10.1016/j.cemconcomp.2023.105186` | Cement and Concrete Composites | Investigation on the influential mechanism of FA and GGBS on the properties of CO2-cured cem |
| 26 | 2022 | `10.1016/j.cemconres.2022.106827` | Cement and Concrete Research | Effect of temperature on CO2 curing, compressive strength and microstructure of cement paste |
| 27 | 2020 | `10.4028/www.scientific.net/kem.846.207` | Key engineering materials | Effect of CO2 Curing on the Strength of High Strength Pervious Concrete |
| 28 | 2020 | `10.1016/j.jmrt.2020.08.051` | Journal of Materials Research and  | Impact of CO2 curing on the microhardness and strength of 0.35 w/c cement paste: Comparative |
| 29 | 2019 | `10.17159/2309-8775/2019/v61n4a7` | Journal of the South African Insti | Mechanical properties, durability characteristics and shrinkage of plain cement and fly ash  |
| 30 | 2026 | `10.1088/2631-8695/aea749` | Engineering Research Express | Influence of CO2 Curing and Oxalic Acid Molarity on the Mechanical and Microstructural Prope |
| 31 | 2026 | `10.1016/j.conbuildmat.2026.145381` | Construction and Building Material | Enhancement effects of CO2 curing on biochar modified construction solid waste: Mechanical p |
| 32 | 2025 | `10.1016/j.dibe.2025.100813` | Developments in the Built Environm | Effect of carbonation curing on the microstructural evolution and mechanical properties of s |
| 33 | 2024 | `10.1016/j.jcou.2024.102757` | Journal of CO2 Utilization | Synergetic effect of CO2 curing and bottom ash with low Ca on the enhancement of carbonation |
| 34 | 2026 | `10.1016/j.mtcomm.2026.115734` | Materials Today Communications | Influence of natural fibers on accelerated carbonation of cement mortars: An experimental ev |
| 35 | 2026 | `10.1016/j.clwas.2026.100565` | Cleaner Waste Systems | Effects of coal-ash and brewery wastewater on carbonated concrete and its carbon neutrality  |
| 36 | 2025 | `10.1016/j.jma.2024.12.016` | Journal of Magnesium and Alloys | Effect of pre-autoclaving treatment on volume stability and compressive strength of carbonat |
| 37 | 2025 | `10.1016/j.conbuildmat.2025.142286` | Construction and Building Material | Technical and environmental assessment of CO2-cured alkali-activated pervious paving blocks  |
| 38 | 2024 | `10.1016/j.jcou.2024.103010` | Journal of CO2 Utilization | Synergistic effects of CO2 sequestration on mechanical, microstructural, and environmental p |
| 39 | 2022 | `10.1016/j.cscm.2022.e01474` | Case Studies in Construction Mater | Carbonated concrete brick capturing carbon dioxide from cement kiln exhaust gas |
| 40 | 2017 | `10.2109/jcersj2.17111` | Journal of the Ceramic Society of  | Assessment of the freeze–thaw resistance of concrete incorporating carbonated coarse recycle |
| 41 | 2026 | `10.1088/1748-9326/ae9968` | Environmental Research Letters | Dynamic carbon footprint trade-off between carbonation curing, mineral carbonation and natur |
| 42 | 2026 | `10.1016/j.cemconcomp.2026.106806` | Cement and Concrete Composites | Mechanisms of internal carbonation curing in biochar-based cement paste: Amine-modified bioc |
| 43 | 2026 | `10.1016/j.jobe.2026.116421` | Journal of Building Engineering | Effect of biochar-enabled internal CO2 curing on CO2 sequestration and mechanical properties |
| 44 | 2026 | `10.1016/j.cscm.2026.e05875` | Case Studies in Construction Mater | Carbonation curing of ultra-high-performance concrete produced with Portland cement of varyi |
| 45 | 2026 | `10.1016/j.cscm.2026.e06489` | Case Studies in Construction Mater | Mechanical and durability performance of concrete under dry ice and accelerated carbonation  |
| 46 | 2026 | `10.1016/j.jrst.2026.08.003` | Journal of Railway Science and Tec | Flue gas carbonation curing under ambient pressure: A sustainable approach for precast railw |
| 47 | 2026 | `10.1016/j.rineng.2026.113026` | Results in Engineering | Synergistic effects of red mud incorporation and CO2 curing on the microstructure, carbonati |
| 48 | 2026 | `10.1016/j.cscm.2026.e05964` | Case Studies in Construction Mater | Co-recycling of steel slag and recycled concrete fines into fibre-reinforced artificial aggr |
| 49 | 2026 | `10.1016/j.rineng.2026.109227` | Results in Engineering | Cation leaching behaviors of carbonation-cured belite-rich cement paste |
| 50 | 2026 | `10.14744/sigma.2026.2032` | Sigma Journal of Engineering and N | Optimized mix framework for accelerated carbonation concrete by ground granulated blast furn |
| 51 | 2026 | `10.1007/s40098-026-01550-1` | Indian Geotechnical Journal | Enhancement of Recycled Concrete Aggregates Through Accelerated Carbonation for Sustainable  |
| 52 | 2025 | `10.13140/rg.2.2.28273.34403` |  | Accelerated Carbonation Curing of Recycled Concrete Aggregate: Microstructural Investigation |
| 53 | 2025 | `10.1016/j.jcou.2025.103130` | Journal of CO2 Utilization | Carbonation curing for recycling and property enhancement of copper slag-based blended morta |
| 54 | 2025 | `10.36922/msam025330076` | Materials Science in Additive Manu | Unlocking the sustainable potential of 3D concrete printing with large aggregates and steam– |
| 55 | 2025 | `10.1016/j.cscm.2025.e05150` | Case Studies in Construction Mater | Effect of acid attack coupled with elevated temperatures on carbonation-cured calcium sulfoa |
| 56 | 2024 | `10.1016/j.cscm.2024.e03591` | Case Studies in Construction Mater | Enhancing carbon sequestration in cement mortar using high volume local rice husk biochar co |
| 57 | 2024 | `10.1016/j.cscm.2024.e02973` | Case Studies in Construction Mater | Effects of CO2 curing methods on frost resistance and mechanical properties of recycled aggr |
| 58 | 2024 | `10.30880/ijie.2024.16.09.004` | International Journal of Integrate | Performance of Carbide Lime Waste Mortar via 24 Hours Accelerated CO2 Curing |
| 59 | 2023 | `10.1016/j.jobe.2023.107704` | Journal of Building Engineering | Unveiling the role of reactive magnesia and red mud in CO2-cured aerated concrete |
| 60 | 2022 | `10.1016/j.jclepro.2022.133545` | Journal of Cleaner Production | Recycling waste glass aggregate in concrete: Mitigation of alkali-silica reaction (ASR) by c |
| 61 | 2022 | `10.1016/j.jclepro.2022.135501` | Journal of Cleaner Production | Carbonation curing of mortars produced with reactivated cementitious materials for CO2 seque |
| 62 | 2022 | `10.1016/j.jclepro.2022.133533` | Journal of Cleaner Production | Effect of incorporating municipal solid waste incinerated bottom ash in alkali-activated fly |
| 63 | 2022 | `10.1016/j.conbuildmat.2022.127999` | Construction and Building Material | Effect of reactive magnesium oxide in alkali-activated fly ash mortars exposed to accelerate |
| 64 | 2022 | `10.1016/j.conbuildmat.2022.127977` | Construction and Building Material | The use of alkaline CO2 solvent for the CO2 curing of blast-furnace slag mortar |
| 65 | 2021 | `10.1016/j.conbuildmat.2021.123076` | Construction and Building Material | Carbon capture in ultra-high performance concrete using pressurized CO2 curing |
| 66 | 2021 | `10.1155/2021/6659768` | Journal of Engineering | Performance of GGBS Cement Concrete under Natural Carbonation and Accelerated Carbonation Ex |
| 67 | 2020 | `10.1007/s12205-020-0817-4` | KSCE Journal of Civil Engineering | Strength and Mechanism of Carbonated Solidified Clay with Steel Slag Curing Agent |
| 68 | 2019 | `10.18720/mce.92.9` | DOAJ (DOAJ: Directory of Open Acce | CO2 curing of hydrated lime modified pervious concretes |
| 69 | 2018 | `10.1088/1757-899x/431/5/052013` | IOP Conference Series: Materials S | Influence of curing duration on accelerated carbonation of concrete and the uncertainties in |
| 70 | 2017 | `10.1617/s11527-017-1066-y` | Materials and Structures | Empirical modelling of CO2 uptake by recycled concrete aggregates under accelerated carbonat |
| 71 | 2016 | `10.30684/etj.34.6a.1` | Engineering and Technology Journal | Strength Evaluation of CO2-Cured Cellulose Date Palm Fiber Reinforced Cementitious Boards |

完整机器可读清单：`raw/manual_download_list.json`（含每次尝试的 URL 与 HTTP 状态）。

## 7. 已知检索局限（照实记）

1. Semantic Scholar 因限流 0 命中，未能作为独立覆盖性校验。

2. 仅检索英文关键词；`raw/batch_16.json` 里有若干日文期刊（AIJ/JCI/セメント技術年報）是经 Crossref/绿色通道偶然捞到的，不是系统检索的结果。

3. 本机无法访问 Elsevier 全文，而 Elsevier 恰好是本领域体量最大的出版商（244 篇候选里 104 篇是 10.1016），因此**本外部验证集对文献总体并不是随机样本**，它偏向 MDPI/Springer-OA/SciELO 等金色 OA 渠道。这一点在 `EXTVAL_RESULTS.md` 的局限一节里再次强调。

## 8. 目录与文件

| 路径 | 内容 | 体积 |
|---|---|---:|
| `fulltext/` | 下载到的 197 篇 OA 原文（PDF / Europe PMC XML）。**可删**——所有抽取都已转成 `text/`，脚本可重新下载 | ~1.0 GB |
| `text/` | `pdftotext -layout` 转出的文本，抽取的直接依据 | ~21 MB |
| `raw/` | 检索/筛选/抓取的全部原始响应与日志（`openalex_hits.json`、`ranked.json`、`fetch_log*.json`、`green_log.json`、`manual_download_list.json`、`paper_notes.json` 等） | ~6 MB |
| `extract/batch_*.jsonl` | 逐篇抽取的原始输出（论文级判定 + 记录级数据 + 逐字 evidence） | ~0.9 MB |
| `results/` | `extval_*.json`（四种口径的完整结果）与运行日志 | ~0.9 MB |
| `scripts/` | 全部可复跑脚本 | — |
