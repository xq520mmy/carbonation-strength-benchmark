#!/usr/bin/env python3
"""M3：ExtraTrees 深入 —— 为什么它在 LOSO 下远好于 RF；哪些超参重要；嵌套选择会选到什么。

  (a) 结构消融：RF ↔ ET 之间的两个差别（bootstrap、随机阈值）逐一切换
  (b) ET 超参：n_estimators、max_features、min_samples_leaf、max_depth（固定档 + 嵌套选择）
  (c) 特征：raw / raw+少量物理量（cw, co2_dose, density_h）/ raw 去掉某列（留一特征消融）
"""
import sys, os, json, numpy as np, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor

SEEDS = C.DEFAULT_SEEDS
HARM = "rescale"

def et(seed, groups, **kw):
    p = dict(n_estimators=300, random_state=seed, n_jobs=1); p.update(kw)
    return ExtraTreesRegressor(**p)

def mk(**kw):
    return lambda seed, groups: et(seed, groups, **kw)

def mk_rf(**kw):
    def f(seed, groups):
        p = dict(n_estimators=300, random_state=seed, n_jobs=1); p.update(kw)
        return RandomForestRegressor(**p)
    return f

R = {"_desc": "M3 ExtraTrees 深入：结构消融 / 超参 / 特征消融", "runs": {}}
_prev = os.path.join(C.RESDIR, "m3_extratrees.json")
if os.path.exists(_prev):
    R["runs"] = json.load(open(_prev))["runs"]; print(f"resume: {len(R['runs'])} done")

def do(name, make, fs="raw", target="none", seeds=SEEDS, harm=HARM, X=None, rand=True):
    if name in R["runs"]:
        return
    print(f"\n### {name}", flush=True)
    lo = C.run_loso(make, fs, target, seeds, harmonize_units=harm, X_override=X)
    ra = C.run_random_kfold(make, fs, target, seeds, harmonize_units=harm, X_override=X) if rand else None
    R["runs"][name] = dict(fs=fs, harm=harm, target=target, loso=C.strip_preds(lo), rand=ra,
                           loso_pred_mean=np.nanmean(np.array([lo["preds"][s] for s in lo["preds"]]), axis=0).tolist())
    C.save_json("m3_extratrees", R)

# (a) RF ↔ ET 结构消融（raw, rescale）
do("A|RF (bootstrap, greedy)", mk_rf())
do("A|RF no-bootstrap (greedy, full sample)", mk_rf(bootstrap=False))
do("A|ET bootstrap (random thr + bootstrap)", mk(bootstrap=True))
do("A|ET (random thr, full sample) = default", mk())
do("A|ET max_features=1/3", mk(max_features=1 / 3))
do("A|ET max_features=sqrt", mk(max_features="sqrt"))
do("A|ET max_features=1", mk(max_features=1))
do("A|RF max_features=1/3", mk_rf(max_features=1 / 3))

# (b) ET 超参固定档
for msl in (1, 2, 3, 5, 8):
    do(f"B|ET min_samples_leaf={msl}", mk(min_samples_leaf=msl))
for md in (4, 6, 8, None):
    do(f"B|ET max_depth={md}", mk(max_depth=md))
do("B|ET n_estimators=1000", mk(n_estimators=1000), seeds=SEEDS[:5])

# (b') 嵌套选择：网格 max_features × min_samples_leaf
GRID = [dict(max_features=mf, min_samples_leaf=msl) for mf, msl in itertools.product([1.0, 1 / 3, "sqrt"], [1, 3, 8])]
def mk_nested(target):
    ttf = C.TargetTf(target)
    def make(seed, groups):
        return C.NestedSelect(lambda cfg: et(seed, groups, **cfg), GRID, groups, ttf)
    return make
do("B|ET nested(max_features×min_leaf)", mk_nested("none"), seeds=SEEDS[:5])
R["grid_nested"] = GRID

# (c) 特征消融
Xraw = C.X_of("raw", HARM)
Xphys = C.X_of("phys_d", HARM, fill_nan=2300.0)
do("C|raw + cw + co2_dose", mk(), X=Xraw.assign(cw=Xphys["cw"], co2_dose=Xphys["co2_dose"]))
do("C|raw + density_h", mk(), X=Xraw.assign(density_h=Xphys["density_h"]))
do("C|raw + cw + co2_dose + density_h + cement_frac", mk(),
   X=Xraw.assign(cw=Xphys["cw"], co2_dose=Xphys["co2_dose"], density_h=Xphys["density_h"], cement_frac=Xphys["cement_frac"]))
for col in C.RAW_COLS:
    do(f"C|raw − {col}", mk(), X=Xraw.drop(columns=[col]), seeds=SEEDS[:5], rand=False)
do("C|raw flag (no rescale)", mk(), harm="flag")
do("C|raw off (no harmonization at all)", mk(), harm="off")

# ---- 渲染
lines = ["## §3 M3：ExtraTrees 深入 —— 结构消融 / 超参 / 特征消融", "",
         f"脚本 `m3_extratrees.py`，结果 `results/m3_extratrees.json`。默认 raw 特征 + rescale 单位调和 + 原值目标；300 棵树；A/B/C 为三组消融。"
         "嵌套选择网格：max_features {1.0, 1/3, sqrt} × min_samples_leaf {1, 3, 8}（9 格，训练研究内 leave-one-group-out）。", "", C.MD_HEADER]
for k, v in R["runs"].items():
    lines.append(C.md_row(k, v["loso"], v["rand"]))
best = max(R["runs"].items(), key=lambda kv: kv[1]["loso"]["pooled"]["r2"]["mean"])
lines += ["", f"M3 内最佳：**{best[0].replace('|', ' · ')}**", "", C.per_fold_table(best[0], best[1]["loso"])]
C.append_md("\n".join(lines))
print("\n-> RESULTS.md 追加 §3 完成")
