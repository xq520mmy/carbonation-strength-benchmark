#!/usr/bin/env python3
"""M7：跨研究不变性 —— 研究均衡加权 与 Group DRO（研究 = group）。

  (a) 均衡加权：训练行按 inner group 加权，使每个研究总权重相等（w_i = 1/(G·n_g)）；sqrt 版 w_i ∝ 1/√n_g
  (b) Group DRO（指数梯度）：q_g 初始均匀；每轮用当前 q 加权拟合，用训练研究内 leave-one-group-out
      算每个研究的 RMSE L_g，q_g ← q_g·exp(η·L_g/mean(L))，归一化；K 轮后用最终 q 加权重训。
      与经典 online Group DRO 的差别：用嵌套留一研究的 out-of-group 误差而不是训练误差（树的训练误差≈0，无信息）。
基学习器：ET300 raw rescale（M1/M3 最佳）与 HGB raw rescale。
"""
import sys, os, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.model_selection import LeaveOneGroupOut

SEEDS = C.DEFAULT_SEEDS
HARM = "rescale"

def et(seed): return ExtraTreesRegressor(n_estimators=300, random_state=seed, n_jobs=1)
def hgb(seed): return HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=5, random_state=seed)

def balanced_w(tr, power=1.0):
    g = C.INNER_GROUP[tr]
    u, cnt = np.unique(g, return_counts=True)
    w = {k: 1.0 / (c ** power) for k, c in zip(u, cnt)}
    ww = np.array([w[x] for x in g]); return ww * len(tr) / ww.sum()

class GroupDRO:
    def __init__(self, build, groups, seed, eta=1.0, rounds=5):
        self.build, self.groups, self.seed, self.eta, self.rounds = build, np.asarray(groups), seed, eta, rounds
    def fit(self, X, y, sample_weight=None):
        X = X.reset_index(drop=True); y = np.asarray(y, float)
        G = np.unique(self.groups); q = {g: 1.0 / len(G) for g in G}
        splits = list(LeaveOneGroupOut().split(X, y, self.groups))
        hist = []
        for r in range(self.rounds):
            w = np.array([q[g] for g in self.groups]); w = w / w.sum() * len(y)
            L = {}
            for tr, te in splits:
                m = self.build(self.seed + r); m.fit(X.iloc[tr], y[tr], sample_weight=w[tr])
                L[self.groups[te[0]]] = float(np.sqrt(np.mean((y[te] - m.predict(X.iloc[te])) ** 2)))
            Lbar = np.mean(list(L.values()))
            for g in G:
                q[g] *= np.exp(self.eta * L[g] / Lbar)
            s = sum(q.values()); q = {g: v / s for g, v in q.items()}
            hist.append(dict(L=L, q=dict(q)))
        self.hist_ = hist
        w = np.array([q[g] for g in self.groups]); w = w / w.sum() * len(y)
        self.m = self.build(self.seed); self.m.fit(X, y, sample_weight=w); return self
    def predict(self, X):
        return self.m.predict(X)

R = {"_desc": "M7 研究均衡加权 / Group DRO", "runs": {}}
_prev = os.path.join(C.RESDIR, "m7_groupdro.json")
if os.path.exists(_prev):
    R["runs"] = json.load(open(_prev))["runs"]; print(f"resume: {len(R['runs'])} done")

def do(name, make, seeds=SEEDS, swf=None):
    if name in R["runs"]:
        return
    print(f"\n### {name}", flush=True)
    lo = C.run_loso(make, "raw", "none", seeds, harmonize_units=HARM, sample_weight_fn=swf)
    ra = C.run_random_kfold(make, "raw", "none", seeds, harmonize_units=HARM, sample_weight_fn=swf)
    R["runs"][name] = dict(fs="raw", target="none", loso=C.strip_preds(lo), rand=ra,
                           loso_pred_mean=np.nanmean(np.array([lo["preds"][s] for s in lo["preds"]]), axis=0).tolist())
    C.save_json("m7_groupdro", R)

for bname, build in (("ET", et), ("HGB", hgb)):
    do(f"{bname}|uniform (对照)", lambda s, g, b=build: b(s))
    do(f"{bname}|balanced 1/n_g", lambda s, g, b=build: b(s), swf=lambda tr: balanced_w(tr, 1.0))
    do(f"{bname}|balanced 1/sqrt(n_g)", lambda s, g, b=build: b(s), swf=lambda tr: balanced_w(tr, 0.5))
    do(f"{bname}|GroupDRO eta=1, 5 rounds", lambda s, g, b=build: GroupDRO(b, g, s, 1.0, 5), seeds=SEEDS[:5])
    do(f"{bname}|GroupDRO eta=0.3, 5 rounds", lambda s, g, b=build: GroupDRO(b, g, s, 0.3, 5), seeds=SEEDS[:5])

lines = ["## §7 M7：研究均衡加权 / Group DRO（研究为 group）", "",
         "脚本 `m7_groupdro.py`，结果 `results/m7_groupdro.json`。raw 特征 + rescale；inner group = 训练侧研究标签（含推定标签）。"
         "Group DRO 用训练研究内 leave-one-group-out 的 out-of-group RMSE 做指数梯度更新（5 轮）。", "", C.MD_HEADER]
for k, v in R["runs"].items():
    lines.append(C.md_row(k, v["loso"], v["rand"]))
best = max(R["runs"].items(), key=lambda kv: kv[1]["loso"]["pooled"]["r2"]["mean"])
lines += ["", f"M7 内最佳：**{best[0].replace('|', ' · ')}**", "", C.per_fold_table(best[0], best[1]["loso"])]
C.append_md("\n".join(lines))
print("\n-> RESULTS.md 追加 §7 完成")
