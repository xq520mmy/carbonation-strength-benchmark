#!/usr/bin/env python3
"""M6：UCI concrete（Yeh 1998，1030 行普通湿养混凝土）迁移。**UCI 只进训练侧，永不进评价。**

共享特征空间（9 维）：cement, slag(SCM), flyash, water, superplasticizer, coarse_agg, fine_agg, age, w/b。
CO₂ 库映射：cement=C；slag(SCM)=0（本库 slag 列是轻骨料，按溯源笔记 §1.1 并入 coarse_agg）；flyash=fly ash；
water=W；SP=0（未记录）；coarse_agg=CA+slag；fine_agg=FA；age=28；w/b=W/B。质量列先经 rescale 单位调和。

变体：
  (0) UCI-only 零样本：UCI 模型直接预测 CO₂ 库（不看任何 CO₂ 标签）——参考线
  (1) 特征增广：raw + uci_pred（UCI 模型对该配比的"常规 28 d 强度"预测，log MPa）→ ET / HGB
  (2) 残差学习：目标 = CS − exp(uci_pred)，ET 学 CO₂ 养护带来的修正 → 预测 = exp(uci_pred) + 修正
  (3) 预训练 + 微调：HGB 在 UCI 上先 boosting 200 轮（warm_start），再在 CO₂ 训练行上续 100 轮（共享 9 维特征）
  (4) 预训练 + 微调 + 养护特征：同 (3)，但 CO₂ 侧特征 = 9 维共享 + [T, CC, P, steam]（UCI 侧这些列为常数 0，
      树无法在 UCI 阶段用到，微调阶段可用）
"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.metrics import r2_score

SEEDS = C.DEFAULT_SEEDS
HARM = "rescale"

# ---------------------------------------------------------------- UCI
uci = pd.read_csv(C.UCI)
uci.columns = ["cement", "slag", "flyash", "water", "sp", "ca", "fa", "age", "strength"]
assert uci.shape == (1030, 9)
SHARED = ["cement", "slag", "flyash", "water", "sp", "ca", "fa", "age", "wb"]
uci["wb"] = uci["water"] / (uci["cement"] + uci["slag"] + uci["flyash"])
XU = uci[SHARED].values.astype(float); zU = np.log(uci["strength"].values)

def uci_model(seed=0, max_iter=300, warm=False):
    return HistGradientBoostingRegressor(max_iter=max_iter, learning_rate=0.05, max_leaf_nodes=15,
                                         min_samples_leaf=10, random_state=seed, warm_start=warm)

# UCI 自身随机 5 折（只是 sanity，说明 UCI 模型学到了东西）
cvp = cross_val_predict(uci_model(), XU, zU, cv=KFold(5, shuffle=True, random_state=0))
uci_cv_r2 = float(r2_score(np.exp(zU), np.exp(cvp)))
print(f"UCI 自身随机 5 折 R²（MPa 尺度）= {uci_cv_r2:.3f}")

UCI_FULL = uci_model().fit(XU, zU)

def map_to_shared(harm=HARM):
    raw = C.X_of("raw", harm)
    m = pd.DataFrame({
        "cement": raw["C"], "slag": 0.0, "flyash": raw["fly ash"], "water": raw["W"], "sp": 0.0,
        "ca": raw["CA"] + raw["blast furnace slag"], "fa": raw["FA"], "age": 28.0, "wb": raw["W/B"]})
    return m[SHARED]

XS = map_to_shared()
UCI_PRED_LOG = UCI_FULL.predict(XS.values)           # 常规养护下该配比的 28 d 强度预测（log MPa）

R = {"_desc": "M6 UCI 迁移（UCI 只进训练侧）", "uci_cv_r2": uci_cv_r2, "runs": {}}
_prev = os.path.join(C.RESDIR, "m6_uci_transfer.json")
if os.path.exists(_prev):
    R["runs"] = json.load(open(_prev))["runs"]; print(f"resume: {len(R['runs'])} done")

def do(name, make, fs="raw", target="none", seeds=SEEDS, X=None, rand=True):
    if name in R["runs"]:
        return
    print(f"\n### {name}", flush=True)
    lo = C.run_loso(make, fs, target, seeds, harmonize_units=HARM, X_override=X)
    ra = C.run_random_kfold(make, fs, target, seeds, harmonize_units=HARM, X_override=X) if rand else None
    R["runs"][name] = dict(fs=fs, target=target, loso=C.strip_preds(lo), rand=ra,
                           loso_pred_mean=np.nanmean(np.array([lo["preds"][s] for s in lo["preds"]]), axis=0).tolist())
    C.save_json("m6_uci_transfer", R)

# (0) 零样本参考：直接用 UCI 预测。用一个"常数模型"包装以复用协议（fit 不看 y）。
class ZeroShot:
    def fit(self, X, y): return self
    def predict(self, X): return np.exp(X["uci_pred"].values)
X0 = pd.DataFrame({"uci_pred": UCI_PRED_LOG})
do("0|UCI-only zero-shot (无 CO2 标签)", lambda s, g: ZeroShot(), X=X0, seeds=[0])

# (1) 特征增广
Xraw = C.X_of("raw", HARM)
X1 = Xraw.assign(uci_pred=UCI_PRED_LOG)
et = lambda s, g: ExtraTreesRegressor(n_estimators=300, random_state=s, n_jobs=1)
hgb = lambda s, g: HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=5, random_state=s)
do("1|ET raw + uci_pred", et, X=X1)
do("1|HGB raw + uci_pred", hgb, X=X1)
do("1|ET uci_pred + curing only (T,CC,P,steam,W/B)", et,
   X=pd.DataFrame({"uci_pred": UCI_PRED_LOG, "T": Xraw["T"], "CC": Xraw["CC"], "P": Xraw["P"],
                   "steam": Xraw["CCU-steam curing time"], "W/B": Xraw["W/B"]}))

# (2) 残差学习：目标 = CS − exp(uci_pred)
class Residual:
    def __init__(self, base): self.base = base
    def fit(self, X, y):
        off = np.exp(X["uci_pred"].values); self.base.fit(X, np.asarray(y) - off); return self
    def predict(self, X):
        return np.exp(X["uci_pred"].values) + self.base.predict(X)
do("2|ET residual on exp(uci_pred)", lambda s, g: Residual(ExtraTreesRegressor(n_estimators=300, random_state=s, n_jobs=1)), X=X1)
do("2|HGB residual on exp(uci_pred)", lambda s, g: Residual(HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=5, random_state=s)), X=X1)

# (3)/(4) 预训练 + 微调（共享特征空间；log 目标）——用 LightGBM 的 init_model 续训。
# 注：第一版用 sklearn HGB 的 warm_start 在新数据上续训，结果爆炸（RMSE 37–47）：HGB 的 warm_start 会在新数据上
# 重新分箱，旧树的 raw_predictions 与新分箱不一致，属实现错误而非方法失败，已弃用。
import lightgbm as lgb
class PretrainFinetune:
    def __init__(self, seed, extra_cols, pre_iter=200, ft_iter=100, ft_lr=0.05):
        self.seed, self.extra, self.pre, self.ft, self.ft_lr = seed, extra_cols, pre_iter, ft_iter, ft_lr
    def fit(self, X, z):
        cols = SHARED + self.extra
        XU2 = np.c_[XU, np.zeros((len(XU), len(self.extra)))] if self.extra else XU
        base = dict(num_leaves=15, min_child_samples=10, learning_rate=0.05, subsample=0.8, subsample_freq=1,
                    colsample_bytree=0.9, verbose=-1, n_jobs=1, random_state=self.seed)
        pre = lgb.LGBMRegressor(n_estimators=self.pre, **base).fit(XU2, zU)
        base.update(min_child_samples=5, learning_rate=self.ft_lr)
        ft = lgb.LGBMRegressor(n_estimators=self.ft, **base)
        ft.fit(X[cols].values, np.asarray(z), init_model=pre.booster_)      # 续训：以 UCI 模型的预测为初值
        self.m, self.cols = ft, cols; return self
    def predict(self, X):
        return self.m.predict(X[self.cols].values)
X34 = XS.assign(T=Xraw["T"], CC=Xraw["CC"], P=Xraw["P"], steam=Xraw["CCU-steam curing time"])
for k in [k for k in R["runs"] if k.startswith(("3|", "4|", "4b|", "4c|")) and "HGB" in k]:
    R["runs"].pop(k)                                   # 丢弃 HGB warm_start 的错误结果
do("3|LGBM pretrain(UCI 200) + finetune(CO2 100), shared 9 feats", lambda s, g: PretrainFinetune(s, []), target="log", X=X34)
do("4|LGBM pretrain + finetune, shared 9 + curing(T,CC,P,steam)", lambda s, g: PretrainFinetune(s, ["T", "CC", "P", "steam"]), target="log", X=X34)
do("4b|LGBM pretrain + finetune 300 rounds, shared 9 + curing", lambda s, g: PretrainFinetune(s, ["T", "CC", "P", "steam"], 200, 300), target="log", X=X34)
# 对照：不预训练，同一 LGBM 超参在同一 13 维特征上只用 CO2 训练行
def lgbm_plain(s, g):
    return lgb.LGBMRegressor(n_estimators=300, num_leaves=15, min_child_samples=5, learning_rate=0.05, subsample=0.8,
                             subsample_freq=1, colsample_bytree=0.9, verbose=-1, n_jobs=1, random_state=s)
do("4c|LGBM no-pretrain, same 13 feats (对照)", lgbm_plain, target="log", X=X34)

# ---- 渲染
lines = ["## §6 M6：UCI concrete 迁移（UCI 1030 行只进训练侧）", "",
         f"脚本 `m6_uci_transfer.py`，结果 `results/m6_uci_transfer.json`。UCI 模型 = HGB(300, lr 0.05, 15 叶) 于 log 强度；"
         f"UCI 自身随机 5 折 R² = {uci_cv_r2:.3f}（sanity）。CO₂ 库按 rescale 单位调和后映射到 9 维共享特征；slag 列并入粗骨料。", "",
         C.MD_HEADER]
for k, v in R["runs"].items():
    lines.append(C.md_row(k, v["loso"], v["rand"]))
best = max(R["runs"].items(), key=lambda kv: kv[1]["loso"]["pooled"]["r2"]["mean"])
lines += ["", f"M6 内最佳：**{best[0].replace('|', ' · ')}**", "", C.per_fold_table(best[0], best[1]["loso"])]
C.append_md("\n".join(lines))
print("\n-> RESULTS.md 追加 §6 完成")
