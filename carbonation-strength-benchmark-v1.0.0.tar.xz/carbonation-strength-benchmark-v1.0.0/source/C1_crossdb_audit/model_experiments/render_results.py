#!/usr/bin/env python3
"""把 RESULTS.md 重建为：§0 协议 + 各方法节（取文件中每节的**最后一次**渲染，去掉断点续跑造成的重复）+ §Z 汇总。
§Z 的全部数字从 results/*.json 读取，不经人手转录；叙述段落在 NARRATIVE 里。"""
import sys, os, re, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C

MD = C.RESULTS_MD
text = open(MD).read()
parts = re.split(r"(?m)^(?=## §)", text)
head = parts[0]
secs = {}
order = []
for p in parts[1:]:
    m = re.match(r"## §(\w+)", p)
    sid = m.group(1)
    secs[sid] = p.rstrip() + "\n\n"                 # 最后一次出现覆盖前面的
    if sid not in order:
        order.append(sid)
def key(s):
    return (0, int(s)) if s.isdigit() else (1, s)
order = sorted([s for s in order if s != "Z"], key=key)

def J(name):
    p = os.path.join(C.RESDIR, name)
    return json.load(open(p)) if os.path.exists(p) else None

M1, M2, M3, M4, M5, M6, M7 = (J(f) for f in ["m1_baseline_fe.json", "m2_lgbm.json", "m3_extratrees.json", "m4_tabpfn.json",
                                            "m5_gp_mixed.json", "m6_uci_transfer.json", "m7_groupdro.json"])
M8, M9, M10 = J("m8_ensemble_conformal.json"), J("m9_honest_selection.json"), J("m10_strict_mcgill.json")
M8S = J("m8_ensemble_conformal_strict.json")
DRY = "--dry" in sys.argv

def run(M, k):
    return M["runs"][k] if (M and k in M["runs"]) else None

def best_of(M):
    if not M: return None, None
    k = max(M["runs"], key=lambda kk: M["runs"][kk]["loso"]["pooled"]["r2"]["mean"])
    return k, M["runs"][k]

Z = ["## §Z 汇总", ""]
# ---------------------------------------------------------------- Z.1 方法 × 协议
Z += ["### Z.1 方法 × 协议（每族取代表配置；名称 = 模型 · 特征 · 目标 · 单位调和）", "",
      "LOSO = 留一研究（143 行 pooled）；随机 5 折 = 全 198 行 KFold(5, shuffle)。随机模型为多种子 mean ± SD。", "", C.MD_HEADER]
rows = [
    ("基线 RF300 · raw · none · flag（loso_calibration 同款）", run(M1, "RF300|raw|none")),
    ("RF300 · raw · none · rescale", run(M1, "RF300|raw|none|rescale")),
    ("**ExtraTrees300 · raw · none · rescale（默认超参，推荐）**", run(M1, "ET300|raw|none|rescale")),
    ("ExtraTrees300 · raw · none · flag（不调单位）", run(M1, "ET300|raw|none")),
    ("ExtraTrees300 · raw−W/B · rescale（M3 特征消融最佳，选择乐观）", run(M3, "C|raw − W/B")),
    ("ExtraTrees300 · phys_d · none · rescale", run(M1, "ET300|phys_d|none|rescale")),
    ("HistGB · raw · none · rescale", run(M1, "HGB|raw|none|rescale")),
    ("LightGBM-mono · raw · none · rescale · nested", run(M2, "LGBM-mono|raw|none|rescale|nested")),
    ("LightGBM · raw · none · rescale · nested（无约束）", run(M2, "LGBM|raw|none|rescale|nested")),
    (f"TabPFN v2 最佳：{best_of(M4)[0]}", best_of(M4)[1]),
    (f"M5 最佳：{best_of(M5)[0]}", best_of(M5)[1]),
    ("M5 MixedLM 随机截距 · compact · log", run(M5, "MixedLM-randint|compact|log")),
    ("M6 UCI 零样本（不用 CO₂ 标签）", run(M6, "0|UCI-only zero-shot (无 CO2 标签)")),
    (f"M6 最佳：{best_of(M6)[0]}", best_of(M6)[1]),
    ("M7 ET balanced 1/√n_g", run(M7, "ET|balanced 1/sqrt(n_g)")),
    ("M7 ET GroupDRO η=0.3", run(M7, "ET|GroupDRO eta=0.3, 5 rounds")),
]
for name, r in rows:
    if r:
        Z.append(C.md_row(name, r["loso"], r.get("rand")))
if M8:
    for m in ["stack-NNLS", "select-by-inner", "uniform-mean"]:
        o = M8["methods"][m]
        Z.append(C.md_row(f"M8 {m}（4 候选，只看训练研究内 inner LOGO）", o, None))
if M9:
    Z.append(f"| M9 select-by-other-studies（{M9['n_configs']} 配置，选择只看其余两折） | {M9['pooled_r2_select_by_others']:+.3f} | {M9['pooled_rmse_select_by_others']:.2f} | — | — | "
             + " | ".join(f"{M9['select_by_other_studies'][f]['rmse_on_f']:.1f}" for f in C.QUANT_FOLDS) + " | — | — |")
Z.append("")

# ---------------------------------------------------------------- Z.2 推荐模型每研究
rec = run(M1, "ET300|raw|none|rescale")
if rec:
    Z += ["### Z.2 推荐模型（ExtraTrees300 · raw · rescale）每个留出研究", "", C.per_fold_table("ExtraTrees300 raw rescale", rec["loso"]), ""]
    Z += [f"随机 5 折（文献协议）同一模型：R² = {rec['rand']['all198']['r2']['mean']:.3f} ± {rec['rand']['all198']['r2']['sd']:.3f}，RMSE = {rec['rand']['all198']['rmse']['mean']:.2f} MPa，"
          f"测试集泄漏率 {rec['rand']['test_leak_rate']*100:.0f}%；LOSO 与随机 5 折的 R² 差 = {rec['rand']['all198']['r2']['mean'] - rec['loso']['pooled']['r2']['mean']:.3f}。", ""]

# ---------------------------------------------------------------- Z.3 消融
if M3:
    Z += ["### Z.3 推荐模型的消融（M3；raw · rescale · none 除注明外）", "",
          "| 消融 | LOSO pooled R² | pooled RMSE | RMSE Taiwan | Shao | McGill |", "|---|---:|---:|---:|---:|---:|"]
    for k in ["A|RF (bootstrap, greedy)", "A|RF no-bootstrap (greedy, full sample)", "A|ET bootstrap (random thr + bootstrap)",
              "A|ET (random thr, full sample) = default", "A|ET max_features=1/3", "A|ET max_features=1",
              "B|ET min_samples_leaf=1", "B|ET min_samples_leaf=2", "B|ET min_samples_leaf=3", "B|ET min_samples_leaf=5", "B|ET min_samples_leaf=8",
              "B|ET max_depth=4", "B|ET max_depth=6", "B|ET n_estimators=1000", "B|ET nested(max_features×min_leaf)",
              "C|raw + cw + co2_dose", "C|raw + density_h", "C|raw + cw + co2_dose + density_h + cement_frac",
              "C|raw − W/B", "C|raw − W", "C|raw − C", "C|raw − T", "C|raw − CC", "C|raw − P",
              "C|raw flag (no rescale)", "C|raw off (no harmonization at all)"]:
        r = run(M3, k)
        if r:
            lo = r["loso"]; pf = lo["per_fold"]
            Z.append(f"| {k.replace('|', ' · ')} | {lo['pooled']['r2']['mean']:+.3f} ± {lo['pooled']['r2']['sd']:.3f} | {lo['pooled']['rmse']['mean']:.2f} | "
                     f"{pf['TAIWAN_LEE_WANG']['rmse']['mean']:.1f} | {pf['SHAO_DOE_BLOCK']['rmse']['mean']:.1f} | {pf['MCGILL_LAB']['rmse']['mean']:.1f} |")
    Z.append("")

# ---------------------------------------------------------------- Z.4 conformal
if M8:
    Z += ["### Z.4 Conformal 预测区间（M8；split conformal，校准残差来自训练研究内 inner LOGO = 换研究口径）", "",
          "| 模型 | 校准口径 | 1−α | pooled 覆盖率 | 平均宽度 (MPa) |", "|---|---|---:|---:|---:|"]
    for r in M8["conformal_pooled"]:
        Z.append(f"| {r['model']} | {r['calib']} | {1 - r['alpha']:.1f} | {r['coverage']:.2f} | {r['width']:.1f} |")
    Z.append("")

# ---------------------------------------------------------------- Z.5 严格 McGill
if M10:
    Z += ["### Z.5 严格 McGill 折敏感性（M10；U_MISC 15 行并入留出块）", "",
          "| 模型 | 主口径 pooled R² | strict pooled143(可比) R² | 主口径 McGill(76) RMSE | strict 下原 76 行 RMSE |", "|---|---:|---:|---:|---:|"]
    MAIN = {"RF300 raw flag (原基线)": run(M1, "RF300|raw|none"), "RF300 raw rescale": run(M1, "RF300|raw|none|rescale"),
            "ET300 raw rescale (leaf=1)": run(M3, "B|ET min_samples_leaf=1"), "ET300 raw rescale leaf=3": run(M3, "B|ET min_samples_leaf=3"),
            "ET300 raw rescale leaf=5": run(M3, "B|ET min_samples_leaf=5"), "ET300 raw rescale max_features=1/3": run(M3, "A|ET max_features=1/3"),
            "HGB raw rescale": run(M1, "HGB|raw|none|rescale"), "LGBM-mono raw rescale": run(M2, "LGBM-mono|raw|none|rescale|fixed")}
    MAIN.update({"ET300 phys_d rescale": run(M1, "ET300|phys_d|none|rescale"), "ET300 ratio_d rescale": run(M1, "ET300|ratio_d|none"),
                 "TabPFN raw rescale": run(M4, "TabPFN|raw|none|rescale"), "TabPFN phys_d rescale": run(M4, "TabPFN|phys_d|none|rescale")})
    for k, v in M10["runs"].items():
        mn = MAIN.get(k); lo = v["loso"]
        a = f"{mn['loso']['pooled']['r2']['mean']:+.3f}" if mn else "—"; b = f"{mn['loso']['per_fold']['MCGILL_LAB']['rmse']['mean']:.2f}" if mn else "—"
        Z.append(f"| {k} | {a} | {lo['pooled143_comparable']['r2']['mean']:+.3f} ± {lo['pooled143_comparable']['r2']['sd']:.3f} | {b} | {lo['mcgill_orig76']['rmse']['mean']:.2f} |")
    if M8S:
        for m in ["stack-NNLS", "select-by-inner", "uniform-mean"]:
            o = M8S["methods"][m]
            Z.append(f"| M8-strict {m}（pooled 为 158 行） | {M8['methods'][m]['pooled']['r2']['mean']:+.3f} | {o['pooled']['r2']['mean']:+.3f} ± {o['pooled']['r2']['sd']:.3f}（158 行） | "
                     f"{M8['methods'][m]['per_fold']['MCGILL_LAB']['rmse']['mean']:.2f} | {o['per_fold']['MCGILL_LAB']['rmse']['mean']:.2f}（91 行） |")
    Z.append("")

NARR = open(os.path.join(C.HERE, "narrative_Z.md")).read() if os.path.exists(os.path.join(C.HERE, "narrative_Z.md")) else ""
# 叙述里允许用 {expr} 引用 JSON 数字
def fill(s):
    def rep(m):
        try: return format(eval(m.group(1)), m.group(2) or "")
        except Exception as e: return f"?{m.group(1)}?"
    return re.sub(r"\{\{(.+?)(?::([^}]*))?\}\}", rep, s)
Z.append(fill(NARR))

out = head.rstrip() + "\n\n" + "".join(secs[s] for s in order) + "\n".join(Z) + "\n"
if DRY:
    print("\n".join(Z))
    bad = [l for l in Z[-1].splitlines() if "?" in l and "{{" not in l and "？" not in l and re.search(r"\?[A-Za-z]", l)]
    print(f"\n[dry] 未解析占位符行数：{len(bad)}")
    for l in bad: print("   ", l[:160])
else:
    open(MD, "w").write(out)
    print(f"RESULTS.md 重建完成：{len(out.splitlines())} 行；节：{order + ['Z']}")
