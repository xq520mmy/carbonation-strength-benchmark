#!/usr/bin/env python3
"""M5：核方法与层次模型。
  (a) GP（ARD-RBF + 白噪声，log 目标，StandardScaler 只在训练行 fit）—— sklearn
  (b) 研究块核 GP（自实现）：K = k_ARD(x,x') + s_g²·1[study=study'] + s_n² I。
      训练时同研究的行共享一个随机截距；预测**未见研究**时块项协方差为 0，自动收缩到总体函数。
      超参（ARD 长度尺度、幅值、s_g、s_n）在训练行上极大化边际似然。
  (c) 线性混合效应（statsmodels MixedLM，随机截距 = 训练侧研究标签；预测只用固定效应）
  (d) 研究均衡加权的 Ridge / GP（每个训练研究总权重相等）——在 M7 里做，这里不重复
"""
import sys, os, numpy as np, warnings
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
from scipy.optimize import minimize
from scipy.linalg import cho_factor, cho_solve
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel as CK
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
warnings.filterwarnings("ignore")

# 紧凑物理特征子集（ARD 维度少一点，边际似然更稳）
COMPACT = ["wb", "cw", "cement_frac", "water_frac", "agg_frac", "fine_frac", "log_agg_binder", "ash_frac",
           "log_T", "CC", "log_P", "log_dose", "steam_flag", "density_h"]

def X_compact(harm=True):
    X = C.X_of("ratio_d", harm, fill_nan=2300.0)
    return X[COMPACT]

# ---------------------------------------------------------------- (a) sklearn GP
def make_gp(seed, groups):
    k = CK(1.0, (1e-2, 1e2)) * RBF(length_scale=np.ones(len(COMPACT)), length_scale_bounds=(1e-2, 1e3)) \
        + WhiteKernel(0.05, (1e-4, 1.0))
    return make_pipeline(StandardScaler(),
                         GaussianProcessRegressor(kernel=k, normalize_y=True, n_restarts_optimizer=2, random_state=seed))

# ---------------------------------------------------------------- (b) 研究块核 GP
class BlockGP:
    """z = f(x) + b_g + eps；f ~ GP(0, a² RBF_ARD)，b_g ~ N(0, s_g²)，eps ~ N(0, s_n²)。
    fit 时用训练行的 group；predict 时视所有测试行为**新研究**（块项不参与）。"""
    def __init__(self, groups, seed=0, n_restarts=2):
        self.groups = np.asarray(groups); self.seed = seed; self.n_restarts = n_restarts
    def _K(self, A, B, ls, amp):
        d = (A[:, None, :] - B[None, :, :]) / ls
        return amp ** 2 * np.exp(-0.5 * (d ** 2).sum(-1))
    def _nll(self, theta, X, z, G):
        p = len(COMPACT) if X.shape[1] == len(COMPACT) else X.shape[1]
        ls = np.exp(theta[:p]); amp = np.exp(theta[p]); sg = np.exp(theta[p + 1]); sn = np.exp(theta[p + 2])
        K = self._K(X, X, ls, amp) + sg ** 2 * G + (sn ** 2 + 1e-6) * np.eye(len(z))
        try:
            cf = cho_factor(K, lower=True)
        except np.linalg.LinAlgError:
            return 1e10
        alpha = cho_solve(cf, z)
        return 0.5 * z @ alpha + np.log(np.diag(cf[0])).sum() + 0.5 * len(z) * np.log(2 * np.pi)
    def fit(self, X, z):
        X = np.asarray(X, float); z = np.asarray(z, float)
        self.sc = StandardScaler().fit(X); Xs = self.sc.transform(X)
        self.mu, self.sd = z.mean(), z.std() + 1e-9
        zs = (z - self.mu) / self.sd
        G = (self.groups[:, None] == self.groups[None, :]).astype(float)
        p = X.shape[1]
        rng = np.random.default_rng(self.seed)
        best = None
        inits = [np.r_[np.zeros(p), 0.0, np.log(0.3), np.log(0.3)]]
        for _ in range(self.n_restarts):
            inits.append(np.r_[rng.normal(0.5, 0.7, p), rng.normal(0, 0.5), rng.normal(-1, 0.7), rng.normal(-1, 0.7)])
        bounds = [(np.log(0.05), np.log(50))] * p + [(np.log(0.1), np.log(10)), (np.log(1e-3), np.log(3)), (np.log(1e-3), np.log(3))]
        for th0 in inits:
            r = minimize(self._nll, th0, args=(Xs, zs, G), method="L-BFGS-B", bounds=bounds)
            if best is None or r.fun < best.fun:
                best = r
        th = best.x
        self.ls, self.amp, self.sg, self.sn = np.exp(th[:p]), np.exp(th[p]), np.exp(th[p + 1]), np.exp(th[p + 2])
        K = self._K(Xs, Xs, self.ls, self.amp) + self.sg ** 2 * G + (self.sn ** 2 + 1e-6) * np.eye(len(zs))
        self.cf = cho_factor(K, lower=True); self.alpha = cho_solve(self.cf, zs); self.Xs = Xs
        return self
    def predict(self, X, return_std=False):
        Xs = self.sc.transform(np.asarray(X, float))
        Ks = self._K(Xs, self.Xs, self.ls, self.amp)
        mean = Ks @ self.alpha * self.sd + self.mu
        if not return_std:
            return mean
        v = cho_solve(self.cf, Ks.T)
        var = self.amp ** 2 - np.einsum("ij,ji->i", Ks, v) + self.sg ** 2 + self.sn ** 2   # 新研究：加回块方差
        return mean, np.sqrt(np.maximum(var, 1e-12)) * self.sd

def make_blockgp(seed, groups):
    return BlockGP(groups, seed=seed)

class PlainGPnp(BlockGP):
    """同一实现但去掉块项（s_g 固定为 0），作为 (b) 的严格对照。"""
    def fit(self, X, z):
        self.groups = np.arange(len(np.asarray(z)))       # 每行自成一组 → G = I，块项并入噪声
        return super().fit(X, z)

def make_plaingp(seed, groups):
    return PlainGPnp(groups, seed=seed)

# ---------------------------------------------------------------- (c) MixedLM
class MixedLMWrap:
    def __init__(self, groups):
        self.groups = np.asarray(groups)
    def fit(self, X, z):
        import statsmodels.api as sm
        X = np.asarray(X, float); z = np.asarray(z, float)
        self.sc = StandardScaler().fit(X); Xs = sm.add_constant(self.sc.transform(X), has_constant="add")
        md = sm.MixedLM(z, Xs, groups=self.groups)
        try:
            self.res = md.fit(reml=True, method=["lbfgs"], maxiter=500)
            self.beta = np.asarray(self.res.fe_params)
        except Exception:
            self.beta = np.linalg.lstsq(Xs, z, rcond=None)[0]
        return self
    def predict(self, X):
        import statsmodels.api as sm
        Xs = sm.add_constant(self.sc.transform(np.asarray(X, float)), has_constant="add")
        return Xs @ self.beta

def make_mixedlm(seed, groups):
    return MixedLMWrap(groups)

# ---------------------------------------------------------------- run
R = {"_desc": "M5 GP / 研究块核 GP / MixedLM", "compact_features": COMPACT, "runs": {}}
XC = X_compact()

def do(name, make, seeds, target="log", X=None):
    print(f"\n### {name}", flush=True)
    lo = C.run_loso(make, "ratio_d", target, seeds, X_override=X)
    ra = C.run_random_kfold(make, "ratio_d", target, seeds, X_override=X)
    R["runs"][name] = dict(fs="compact14" if X is XC else "ratio_d", target=target, loso=C.strip_preds(lo), rand=ra,
                           loso_pred_mean=np.nanmean(np.array([lo["preds"][s] for s in lo["preds"]]), axis=0).tolist())
    C.save_json("m5_gp_mixed", R)

do("MixedLM-randint|compact|log", make_mixedlm, [0], "log", XC)
do("GP-sklearn-ARD|compact|log", make_gp, [0, 1, 2], "log", XC)
do("GP-np-noblock|compact|log", make_plaingp, [0, 1, 2], "log", XC)
do("GP-block(study)|compact|log", make_blockgp, [0, 1, 2], "log", XC)
do("GP-block(study)|compact|none", make_blockgp, [0, 1, 2], "none", XC)
XR = C.X_of("ratio_d", True, fill_nan=2300.0)
do("GP-block(study)|ratio_d|log", make_blockgp, [0, 1, 2], "log", XR)

lines = ["## §5 M5：高斯过程 / 研究块核 GP / 线性混合效应", "",
         "脚本 `m5_gp_mixed.py`，结果 `results/m5_gp_mixed.json`。`compact` = 14 个物理特征："
         + ", ".join(COMPACT) + "（density_h 缺失以 2300 填补）。",
         "GP 的种子只影响超参优化的随机重启（3 个种子）；MixedLM 确定性。", "",
         "研究块核：训练时同研究行共享随机截距 b_g ~ N(0, s_g²)，预测未见研究时块项协方差为 0 → 收缩到总体函数；"
         "预测方差加回 s_g²（用于 conformal/区间）。", "", C.MD_HEADER]
for k, v in R["runs"].items():
    lines.append(C.md_row(k, v["loso"], v["rand"]))
best = max(R["runs"].items(), key=lambda kv: kv[1]["loso"]["pooled"]["r2"]["mean"])
lines += ["", f"M5 内最佳：**{best[0]}**", "", C.per_fold_table(best[0], best[1]["loso"])]
C.append_md("\n".join(lines))
print("\n-> RESULTS.md 追加 §5 完成")
