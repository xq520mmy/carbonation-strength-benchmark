#!/usr/bin/env python3
"""M2：LightGBM —— 无约束 vs 单调约束（按物理方向），固定超参 vs 训练研究内嵌套 leave-one-group-out 选超参。

单调方向（先验设定，不看测试折）：
  W/B ↓ (−1)、cw ↑、cement_frac ↑、T ↑、log_T/sqrt_T ↑、CC ↑、co2_dose/log_dose/sqrt_dose ↑、density_h ↑
  其余（P、骨料量、砂率等）不约束：P 的方向在 Shao 数据中为负、在台湾数据中为正，不能先验断言。
"""
import sys, os, json, numpy as np, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
import lightgbm as lgb

SEEDS = C.DEFAULT_SEEDS
MONO = {"W/B": -1, "wb": -1, "cw": 1, "cement_frac": 1, "T": 1, "log_T": 1, "sqrt_T": 1, "CC": 1,
        "co2_dose": 1, "log_dose": 1, "sqrt_dose": 1, "density_h": 1}
FIXED = dict(num_leaves=8, min_child_samples=5, learning_rate=0.05, n_estimators=300, reg_lambda=0.0,
             subsample=0.8, subsample_freq=1, colsample_bytree=0.8)
GRID = [dict(num_leaves=nl, min_child_samples=mcs, learning_rate=0.05, n_estimators=ne, reg_lambda=rl,
             subsample=0.8, subsample_freq=1, colsample_bytree=0.8)
        for nl, mcs, ne, rl in itertools.product([4, 15], [3, 8], [300], [0.0, 5.0])]
# 8 个配置；小网格是刻意的：训练研究只有 ~7 个 inner group，网格越大选择噪声越大。

def make_lgbm(fs, harm, target, mono, tune):
    ttf = C.TargetTf(target)
    cols = list(C.X_of(fs, harm).columns)
    mc = [MONO.get(c, 0) for c in cols] if mono else None
    def build(cfg, seed):
        kw = dict(cfg); kw.update(random_state=seed, verbose=-1, n_jobs=1)
        if mc is not None:
            kw.update(monotone_constraints=mc, monotone_constraints_method="advanced")
        return lgb.LGBMRegressor(**kw)
    def make(seed, groups):
        if tune:
            return C.NestedSelect(lambda cfg: build(cfg, seed), GRID, groups, ttf)
        return build(FIXED, seed)
    return make

R = {"_desc": "M2 LightGBM：无约束 vs 单调约束；固定超参 vs 嵌套选择", "grid": GRID, "fixed": FIXED, "mono": MONO, "runs": {}}
_prev = os.path.join(C.RESDIR, "m2_lgbm.json")
if os.path.exists(_prev):
    R["runs"] = json.load(open(_prev))["runs"]; print(f"resume: {len(R['runs'])} done")

def do(name, make, fs, harm, target, seeds):
    if name in R["runs"]:
        return
    print(f"\n### {name}", flush=True)
    lo = C.run_loso(make, fs, target, seeds, harmonize_units=harm)
    ra = C.run_random_kfold(make, fs, target, seeds, harmonize_units=harm)
    R["runs"][name] = dict(fs=fs, harm=harm, target=target, loso=C.strip_preds(lo), rand=ra,
                           loso_pred_mean=np.nanmean(np.array([lo["preds"][s] for s in lo["preds"]]), axis=0).tolist())
    C.save_json("m2_lgbm", R)

for fs in ("raw", "phys_d", "ratio_d"):
    for harm in ("flag", "rescale"):
        for target in ("none", "log"):
            for mono in (False, True):
                do(f"LGBM{'-mono' if mono else ''}|{fs}|{target}|{harm}|fixed",
                   make_lgbm(fs, harm, target, mono, False), fs, harm, target, SEEDS)
for fs in ("raw", "phys_d"):
    for target in ("none", "log"):
        for mono in (False, True):
            do(f"LGBM{'-mono' if mono else ''}|{fs}|{target}|rescale|nested",
               make_lgbm(fs, "rescale", target, mono, True), fs, "rescale", target, SEEDS[:5])

lines = ["## §2 M2：LightGBM，无约束 vs 单调约束，固定超参 vs 嵌套选择", "",
         "脚本 `m2_lgbm.py`，结果 `results/m2_lgbm.json`。`fixed` = 先验固定超参（num_leaves 8, min_child 5, lr 0.05, 300 轮, 行/列子采样 0.8），10 个种子；"
         "`nested` = 8 格网格（num_leaves {4,15} × min_child {3,8} × λ {0,5}）在训练研究内 leave-one-group-out 选（pooled RMSE 最小），5 个种子。"
         "`flag`/`rescale` = 单位调和模式（§0）。", "",
         "单调约束方向：" + ", ".join(f"{k}:{'+' if v > 0 else '−'}" for k, v in MONO.items()) + "；P 与骨料量不约束（P 的方向在 Shao 与台湾数据中相反）。", "",
         C.MD_HEADER]
for k, v in R["runs"].items():
    lines.append(C.md_row(k, v["loso"], v["rand"]))
best = max(R["runs"].items(), key=lambda kv: kv[1]["loso"]["pooled"]["r2"]["mean"])
lines += ["", f"M2 内最佳：**{best[0].replace('|', ' · ')}**", "", C.per_fold_table(best[0], best[1]["loso"])]
C.append_md("\n".join(lines))
print("\n-> RESULTS.md 追加 §2 完成")
