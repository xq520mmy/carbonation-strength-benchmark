#!/usr/bin/env python3
"""M10：更严格的 McGill 折（敏感性）。

M3 的最近邻诊断显示：ExtraTrees(min_samples_leaf=1) 在 McGill 折上对 `U_1-16 (C=414)` 这 16 行的改善
（RMSE 22.7 → 10.1），来自训练侧的未溯源行 176–180（C=426，P=0.15 MPa / 99% CO₂ / 2 h ——与行 1–16 同一养护制度）。
`U_MISC_putative` 这 15 行（27, 35–38, 86, 88–91, 176–180）大多用的是 0.15 MPa / ≥99% CO₂ / 2 h 这一 McGill 实验室的
经典制度，**很可能也是同实验室的行**。若是，则主口径的 McGill 折存在经由未溯源行的同实验室泄漏。

本脚本把 U_MISC 15 行并入 McGill 留出块（strict：91 行），其余不变，重跑主要模型；McGill 折同时报
(a) 全部 91 行 与 (b) 只对原 76 行打分（与主口径可比）。这是敏感性分析，不替代主口径；两者都写进论文。
"""
import sys, os, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, HistGradientBoostingRegressor
import lightgbm as lgb

SEEDS = C.DEFAULT_SEEDS
HARM = "rescale"
ORIG_MCGILL = set(C.BLOCKS["MCGILL_LAB"])
U_MISC = {i + 1 for i in range(198) if C.INNER_GROUP[i] == "U_MISC_putative"}
assert len(U_MISC) == 15
# ---- monkeypatch 折定义（只影响本进程主控；worker 收到的是显式的 tr/te 下标）
C.BLOCKS["MCGILL_LAB"] = ORIG_MCGILL | U_MISC
for r in U_MISC:
    C.INNER_GROUP[r - 1] = "MCGILL_LAB"
assert len(C.BLOCKS["MCGILL_LAB"]) == 91

def et(seed, groups, **kw):
    p = dict(n_estimators=300, random_state=seed, n_jobs=1); p.update(kw); return ExtraTreesRegressor(**p)
def rf(seed, groups): return RandomForestRegressor(n_estimators=300, random_state=seed, n_jobs=1)
def hgb(seed, groups): return HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=5, random_state=seed)
MONO_RAW = {"W/B": -1, "T": 1, "CC": 1}
def lgbm_mono(seed, groups):
    return lgb.LGBMRegressor(num_leaves=8, min_child_samples=5, learning_rate=0.05, n_estimators=300, subsample=0.8, subsample_freq=1,
                             colsample_bytree=0.8, random_state=seed, verbose=-1, n_jobs=1,
                             monotone_constraints=[MONO_RAW.get(c, 0) for c in C.RAW_COLS], monotone_constraints_method="advanced")

class TabPFNWrap:
    def __init__(self, seed):
        import torch; torch.set_num_threads(1)
        from tabpfn import TabPFNRegressor
        self.m = TabPFNRegressor(device="cpu", random_state=seed)
    def fit(self, X, y): self.m.fit(np.asarray(X, float), np.asarray(y, float)); return self
    def predict(self, X): return np.asarray(self.m.predict(np.asarray(X, float)), float)

MODELS = {
    "RF300 raw flag (原基线)": (rf, "flag", "raw", "none", None),
    "RF300 raw rescale": (rf, HARM, "raw", "none", None),
    "ET300 raw rescale (leaf=1)": (lambda s, g: et(s, g), HARM, "raw", "none", None),
    "ET300 raw rescale leaf=3": (lambda s, g: et(s, g, min_samples_leaf=3), HARM, "raw", "none", None),
    "ET300 raw rescale leaf=5": (lambda s, g: et(s, g, min_samples_leaf=5), HARM, "raw", "none", None),
    "ET300 raw rescale max_features=1/3": (lambda s, g: et(s, g, max_features=1 / 3), HARM, "raw", "none", None),
    "HGB raw rescale": (hgb, HARM, "raw", "none", None),
    "LGBM-mono raw rescale": (lgbm_mono, HARM, "raw", "none", None),
    # 物理特征在严格折上是否有帮助（主口径下无帮助）
    "ET300 phys_d rescale": (lambda s, g: et(s, g), HARM, "phys_d", "none", 2300.0),
    "ET300 ratio_d rescale": (lambda s, g: et(s, g), HARM, "ratio_d", "none", 2300.0),
    "HGB phys_d log rescale": (hgb, HARM, "phys_d", "log", None),
    "TabPFN raw rescale": (lambda s, g: TabPFNWrap(s), HARM, "raw", "none", None),
    "TabPFN phys_d rescale": (lambda s, g: TabPFNWrap(s), HARM, "phys_d", "none", None),
}

R = {"_desc": "M10 严格 McGill 折（+U_MISC 15 行）敏感性", "strict_rows_added": sorted(U_MISC), "runs": {}}
_prev = os.path.join(C.RESDIR, "m10_strict_mcgill.json")
if os.path.exists(_prev):
    R["runs"] = json.load(open(_prev))["runs"]; print(f"resume: {len(R['runs'])} done")

orig76 = np.array(sorted(r - 1 for r in ORIG_MCGILL))
def do(name, make, harm, fs="raw", target="none", fill_nan=None):
    if name in R["runs"]:
        return
    print(f"\n### {name}", flush=True)
    seeds = SEEDS[:5] if "TabPFN" in name else SEEDS
    lo = C.run_loso(make, fs, target, seeds, harmonize_units=harm, fill_nan=fill_nan,
                    n_jobs=(3 if "TabPFN" in name else C.N_JOBS))
    # McGill 折只对原 76 行打分 + 对应的 pooled(143)
    m76 = {"r2": [], "rmse": [], "mae": []}; pooled143 = {"r2": [], "rmse": [], "mae": []}
    for s in lo["preds"]:
        p = np.array(lo["preds"][s])
        m = C.metrics(C.Y[orig76], p[orig76])
        for k in m76: m76[k].append(m[k])
        idx = np.array(sorted(set(orig76.tolist()) | set(C.fold_indices("TAIWAN_LEE_WANG")[1].tolist()) | set(C.fold_indices("SHAO_DOE_BLOCK")[1].tolist())))
        mp = C.metrics(C.Y[idx], p[idx])
        for k in pooled143: pooled143[k].append(mp[k])
    lo = C.strip_preds(lo)
    lo["mcgill_orig76"] = {k: C._msd(v) for k, v in m76.items()}
    lo["pooled143_comparable"] = {k: C._msd(v) for k, v in pooled143.items()}
    R["runs"][name] = dict(loso=lo, harm=harm)
    C.save_json("m10_strict_mcgill", R)
    print(f"  strict: McGill91 RMSE={lo['per_fold']['MCGILL_LAB']['rmse']['mean']:.2f}  McGill orig76 RMSE={lo['mcgill_orig76']['rmse']['mean']:.2f} "
          f" pooled143(可比) R²={lo['pooled143_comparable']['r2']['mean']:+.3f}")

for name, (make, harm, fs, target, fill) in MODELS.items():
    do(name, make, harm, fs, target, fill)

# 主口径数字（从 M1/M3 JSON 取）以便并排
def main_numbers(fn, key):
    p = os.path.join(C.RESDIR, fn)
    if not os.path.exists(p): return None
    return json.load(open(p))["runs"].get(key, {}).get("loso")
MAIN = {"RF300 raw flag (原基线)": main_numbers("m1_baseline_fe.json", "RF300|raw|none"),
        "RF300 raw rescale": main_numbers("m1_baseline_fe.json", "RF300|raw|none|rescale"),
        "ET300 raw rescale (leaf=1)": main_numbers("m3_extratrees.json", "B|ET min_samples_leaf=1"),
        "ET300 raw rescale leaf=3": main_numbers("m3_extratrees.json", "B|ET min_samples_leaf=3"),
        "ET300 raw rescale leaf=5": main_numbers("m3_extratrees.json", "B|ET min_samples_leaf=5"),
        "ET300 raw rescale max_features=1/3": main_numbers("m3_extratrees.json", "A|ET max_features=1/3"),
        "HGB raw rescale": main_numbers("m1_baseline_fe.json", "HGB|raw|none|rescale"),
        "LGBM-mono raw rescale": main_numbers("m2_lgbm.json", "LGBM-mono|raw|none|rescale|fixed"),
        "ET300 phys_d rescale": main_numbers("m1_baseline_fe.json", "ET300|phys_d|none|rescale"),
        "ET300 ratio_d rescale": main_numbers("m1_baseline_fe.json", "ET300|ratio_d|none"),
        "HGB phys_d log rescale": None,
        "TabPFN raw rescale": main_numbers("m4_tabpfn.json", "TabPFN|raw|none|rescale"),
        "TabPFN phys_d rescale": main_numbers("m4_tabpfn.json", "TabPFN|phys_d|none|rescale")}

L = ["## §10 M10：更严格的 McGill 折（敏感性：U_MISC 15 行并入留出块）", "",
     f"脚本 `m10_strict_mcgill.py`，结果 `results/m10_strict_mcgill.json`。并入的行：{sorted(U_MISC)}（多为 0.15 MPa / ≥99% CO₂ / 2 h 的 McGill 经典制度，疑同实验室）。"
     "训练集因此从 122 行缩到 107 行（留出 McGill 时）。'pooled143 可比' = Taiwan 45 + Shao 22 + McGill 原 76 行。", "",
     "| 模型 | 主口径 McGill(76) RMSE | 主口径 pooled R² | strict McGill(91) RMSE | strict 下原 76 行 RMSE | strict pooled143(可比) R² | strict pooled(158) R² |",
     "|---|---:|---:|---:|---:|---:|---:|"]
for name in MODELS:
    lo = R["runs"][name]["loso"]; mn = MAIN.get(name)
    a = f"{mn['per_fold']['MCGILL_LAB']['rmse']['mean']:.2f}" if mn else "—"
    b = f"{mn['pooled']['r2']['mean']:+.3f}" if mn else "—"
    L.append(f"| {name} | {a} | {b} | {lo['per_fold']['MCGILL_LAB']['rmse']['mean']:.2f} | {lo['mcgill_orig76']['rmse']['mean']:.2f} | "
             f"{lo['pooled143_comparable']['r2']['mean']:+.3f} ± {lo['pooled143_comparable']['r2']['sd']:.3f} | {lo['pooled']['r2']['mean']:+.3f} |")
C.append_md("\n".join(L))
print("\n".join(L))
