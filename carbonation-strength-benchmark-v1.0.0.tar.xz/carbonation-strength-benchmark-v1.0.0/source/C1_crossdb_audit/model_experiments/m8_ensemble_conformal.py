#!/usr/bin/env python3
"""M8：集成 / 堆叠 / **诚实的模型选择** / conformal 预测区间。

前面各节的"最佳"都是看着 LOSO 分数挑出来的——这是在测试折上做选择，报出来的数字对"选择"这一步是乐观的。
本节回答：如果只看训练研究内的嵌套 leave-one-group-out（inner LOGO）分数来选模型 / 定权重，LOSO 上会得到什么？

对每个外层折 f、种子 s、候选 c：
  inner_oof_c = 训练行上的 inner LOGO out-of-group 预测（n_train 维）
  test_c      = 用全部训练行拟合后对留出折的预测
然后（全部只用 inner_oof 与训练标签）：
  select-by-inner : c* = argmin_c RMSE(inner_oof_c, y_train)            → test_{c*}
  mean-top2       : inner RMSE 最小的两个候选取平均
  stack-NNLS      : 非负最小二乘 y_train ≈ Σ w_c inner_oof_c，w 归一化为凸组合 → Σ w_c test_c
  uniform-mean    : 所有候选等权平均（不含选择）
conformal（split conformal，校准残差 = inner LOGO 残差，即"换研究"口径）：
  q_α = |r| 的 ceil((n+1)(1−α))/n 分位数 → 区间 test ± q_α；报留出研究上的覆盖率与平均宽度。
  对照：校准残差改为训练行内随机 5 折残差（"同研究"口径）——展示研究漂移下的欠覆盖。
"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.model_selection import LeaveOneGroupOut, KFold
from scipy.optimize import nnls
from joblib import Parallel, delayed
import lightgbm as lgb

SEEDS = [0, 1, 2, 3, 4]
HARM = "rescale"
ALPHAS = [0.1, 0.2]

MONO_RAW = {"W/B": -1, "T": 1, "CC": 1}

def mk_et(seed):   return ExtraTreesRegressor(n_estimators=300, random_state=seed, n_jobs=1)
def mk_hgb(seed):  return HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=5, random_state=seed)
def mk_lgbm(seed):
    cols = C.RAW_COLS
    return lgb.LGBMRegressor(num_leaves=8, min_child_samples=5, learning_rate=0.05, n_estimators=300, subsample=0.8,
                             subsample_freq=1, colsample_bytree=0.8, random_state=seed, verbose=-1, n_jobs=1,
                             monotone_constraints=[MONO_RAW.get(c, 0) for c in cols], monotone_constraints_method="advanced")
class TabPFNWrap:
    def __init__(self, seed):
        import torch; torch.set_num_threads(1)
        from tabpfn import TabPFNRegressor
        self.m = TabPFNRegressor(device="cpu", random_state=seed)
    def fit(self, X, y): self.m.fit(np.asarray(X, float), np.asarray(y, float)); return self
    def predict(self, X): return np.asarray(self.m.predict(np.asarray(X, float)), float)
def mk_tabpfn(seed): return TabPFNWrap(0)      # TabPFN 只用 1 个内部种子（贵），跨种子复用

CANDS = {"ET300 raw": mk_et, "HGB raw": mk_hgb, "LGBM-mono raw": mk_lgbm, "TabPFN raw": mk_tabpfn}
STRICT = os.environ.get("C1_STRICT", "0") == "1"          # 严格 McGill 折（U_MISC 15 行并入留出块，见 M10）
if STRICT:
    U_MISC = {i + 1 for i in range(198) if C.INNER_GROUP[i] == "U_MISC_putative"}
    C.BLOCKS["MCGILL_LAB"] = set(C.BLOCKS["MCGILL_LAB"]) | U_MISC
    for r in U_MISC:
        C.INNER_GROUP[r - 1] = "MCGILL_LAB"
OUTNAME = "m8_ensemble_conformal" + ("_strict" if STRICT else "")
SEC = "§8b M8-strict：同一集成/堆叠/conformal 流程在严格 McGill 折（91 行）下" if STRICT else "§8 M8：集成 / 堆叠 / 诚实的模型选择 / conformal 区间"
X = C.X_of("raw", HARM)
y = C.Y
G = C.INNER_GROUP

def inner_and_outer(name, f, seed, tr, te, gtr):
    # tr/te/gtr 由主进程算好后显式传入：loky worker 会重新 import common，看不到主进程对 C.BLOCKS/INNER_GROUP 的
    # 严格折 monkeypatch（第一版在 worker 里调 C.fold_indices，strict 模式下形状不匹配报错）。
    mk = CANDS[name]
    Xtr, ytr = X.iloc[tr], y[tr]
    oof = np.full(len(tr), np.nan)
    for itr, ite in LeaveOneGroupOut().split(Xtr, ytr, gtr):
        m = mk(seed); m.fit(Xtr.iloc[itr], ytr[itr]); oof[ite] = m.predict(Xtr.iloc[ite])
    # 随机 5 折校准残差（对照）
    oof_rand = np.full(len(tr), np.nan)
    for itr, ite in KFold(5, shuffle=True, random_state=seed).split(Xtr):
        m = mk(seed); m.fit(Xtr.iloc[itr], ytr[itr]); oof_rand[ite] = m.predict(Xtr.iloc[ite])
    m = mk(seed); m.fit(Xtr, ytr); pte = m.predict(X.iloc[te])
    return dict(name=name, fold=f, seed=seed, oof=oof, oof_rand=oof_rand, test=pte)

folds = C.QUANT_FOLDS + C.QUAL_FOLDS
FI = {f: C.fold_indices(f) for f in folds}
jobs = [delayed(inner_and_outer)(n, f, s, FI[f][0], FI[f][1], G[FI[f][0]]) for n in CANDS for f in folds for s in SEEDS]
print(f"{len(jobs)} 个 (候选, 折, 种子) 任务 ...", flush=True)
res = Parallel(n_jobs=C.N_JOBS)(jobs)
D = {(r["name"], r["fold"], r["seed"]): r for r in res}

def q_conf(absres, alpha):
    n = len(absres); k = int(np.ceil((n + 1) * (1 - alpha))); k = min(k, n)
    return float(np.sort(absres)[k - 1])

out = {"_desc": "M8 集成/堆叠/诚实选择/conformal", "candidates": list(CANDS), "seeds": SEEDS, "harm": HARM,
       "inner_scores": {}, "methods": {}, "conformal": {}}
names = list(CANDS)
methods = names + ["select-by-inner", "mean-top2-by-inner", "stack-NNLS", "uniform-mean"]
per_seed = {m: {} for m in methods}
sel_log = []
conf_rec = []
for s in SEEDS:
    for f in folds:
        tr, te = C.fold_indices(f)
        ytr = y[tr]
        inner_rmse = {n: float(np.sqrt(np.mean((ytr - D[(n, f, s)]["oof"]) ** 2))) for n in names}
        order = sorted(names, key=lambda n: inner_rmse[n])
        tests = {n: D[(n, f, s)]["test"] for n in names}
        for n in names:
            per_seed[n][(f, s)] = tests[n]
        per_seed["select-by-inner"][(f, s)] = tests[order[0]]
        per_seed["mean-top2-by-inner"][(f, s)] = (tests[order[0]] + tests[order[1]]) / 2
        A = np.column_stack([D[(n, f, s)]["oof"] for n in names])
        w, _ = nnls(A, ytr); w = w / w.sum() if w.sum() > 0 else np.ones(len(names)) / len(names)
        per_seed["stack-NNLS"][(f, s)] = np.column_stack([tests[n] for n in names]) @ w
        per_seed["uniform-mean"][(f, s)] = np.mean([tests[n] for n in names], axis=0)
        sel_log.append(dict(fold=f, seed=s, inner_rmse=inner_rmse, selected=order[0], stack_w=dict(zip(names, map(float, w)))))
        # conformal：对每个候选与 stack
        if f in C.QUANT_FOLDS:
            for n in names:
                r_logo = np.abs(ytr - D[(n, f, s)]["oof"]); r_rand = np.abs(ytr - D[(n, f, s)]["oof_rand"])
                for a in ALPHAS:
                    for cal, rr in (("LOGO", r_logo), ("random5fold", r_rand)):
                        q = q_conf(rr, a)
                        cov = float(np.mean(np.abs(y[te] - tests[n]) <= q))
                        conf_rec.append(dict(model=n, fold=f, seed=s, alpha=a, calib=cal, q=q, coverage=cov, width=2 * q))
            r_stack = np.abs(ytr - A @ w)
            for a in ALPHAS:
                q = q_conf(r_stack, a)
                conf_rec.append(dict(model="stack-NNLS", fold=f, seed=s, alpha=a, calib="LOGO", q=q,
                                     coverage=float(np.mean(np.abs(y[te] - per_seed["stack-NNLS"][(f, s)]) <= q)), width=2 * q))

def summarize(method):
    pf = {f: {"r2": [], "rmse": [], "mae": []} for f in C.QUANT_FOLDS}; pooled = {"r2": [], "rmse": [], "mae": []}; macro = []; qual = []
    for s in SEEDS:
        ys, ps, r2s = [], [], []
        for f in C.QUANT_FOLDS:
            _, te = C.fold_indices(f); p = per_seed[method][(f, s)]; m = C.metrics(y[te], p)
            for k in pf[f]: pf[f][k].append(m[k])
            r2s.append(m["r2"]); ys.append(y[te]); ps.append(p)
        mp = C.metrics(np.concatenate(ys), np.concatenate(ps))
        for k in pooled: pooled[k].append(mp[k])
        macro.append(float(np.mean(r2s)))
        _, teq = C.fold_indices("LI_HE_CHEN_2019"); qual.append(float(np.mean(np.abs(y[teq] - per_seed[method][("LI_HE_CHEN_2019", s)]))))
    return dict(per_fold={f: {k: C._msd(v) for k, v in pf[f].items()} for f in C.QUANT_FOLDS},
                per_fold_n={f: len(C.BLOCKS[f]) for f in C.QUANT_FOLDS},
                pooled={k: C._msd(v) for k, v in pooled.items()}, macro_r2=C._msd(macro), n_seeds=len(SEEDS),
                qual={"LI_HE_CHEN_2019": dict(n=2, true=float(y[C.fold_indices("LI_HE_CHEN_2019")[1]][0]), mae=C._msd(qual))})

for m in methods:
    out["methods"][m] = summarize(m)
out["selection_log"] = sel_log
cf = pd.DataFrame(conf_rec)
out["conformal"] = cf.groupby(["model", "calib", "alpha", "fold"]).agg(coverage=("coverage", "mean"), width=("width", "mean"), q=("q", "mean")).reset_index().to_dict(orient="records")
out["conformal_pooled"] = []
for (mname, cal, a), g in cf.groupby(["model", "calib", "alpha"]):
    # pooled 覆盖率：按折行数加权
    wts = g["fold"].map(lambda f: len(C.BLOCKS[f]))
    out["conformal_pooled"].append(dict(model=mname, calib=cal, alpha=a, coverage=float(np.average(g["coverage"], weights=wts)),
                                        width=float(np.average(g["width"], weights=wts))))
out["strict_mcgill"] = STRICT
C.save_json(OUTNAME, out)

# ---- 渲染
L = [f"## {SEC}", "",
     f"脚本 `m8_ensemble_conformal.py`{'（C1_STRICT=1）' if STRICT else ''}，结果 `results/{OUTNAME}.json`。候选：{', '.join(names)}（raw 特征 + rescale，原值目标）；{len(SEEDS)} 个种子（TabPFN 内部种子固定）。"
     + ("McGill 折 = 91 行（原 76 + U_MISC 15），其 RMSE 列不与主口径直接可比；pooled 为 158 行。" if STRICT else ""),
     "**选择/权重全部只用训练研究内 inner LOGO 的 out-of-group 预测**，测试折不参与。", "",
     "| 方法 | LOSO pooled R² | LOSO pooled RMSE | LOSO MAE | LOSO macro R² | RMSE Taiwan(45) | RMSE Shao(22) | RMSE McGill(76) |",
     "|---|---:|---:|---:|---:|---:|---:|---:|"]
for m in methods:
    o = out["methods"][m]; pf = o["per_fold"]
    L.append(f"| {m} | {o['pooled']['r2']['mean']:+.3f} ± {o['pooled']['r2']['sd']:.3f} | {o['pooled']['rmse']['mean']:.2f} ± {o['pooled']['rmse']['sd']:.2f} | "
             f"{o['pooled']['mae']['mean']:.2f} | {o['macro_r2']['mean']:+.3f} | {pf['TAIWAN_LEE_WANG']['rmse']['mean']:.1f} | {pf['SHAO_DOE_BLOCK']['rmse']['mean']:.1f} | {pf['MCGILL_LAB']['rmse']['mean']:.1f} |")
L += ["", "**inner LOGO 分数（训练研究内，pooled RMSE，种子均值）与被选中的候选**：", "",
      "| 留出折 | " + " | ".join(names) + " | 选中 | stack 权重 |", "|---|" + "---:|" * len(names) + "---|---|"]
sl = pd.DataFrame(sel_log)
for f in folds:
    g = sl[sl.fold == f]
    means = {n: np.mean([d[n] for d in g.inner_rmse]) for n in names}
    sel = g.selected.value_counts().to_dict()
    wmean = {n: np.mean([d[n] for d in g.stack_w]) for n in names}
    L.append(f"| {f} | " + " | ".join(f"{means[n]:.2f}" for n in names) + f" | {sel} | " + ", ".join(f"{n.split()[0]}:{wmean[n]:.2f}" for n in names) + " |")
L += ["", f"**Conformal 区间**（split conformal；校准残差 = inner LOGO 残差（换研究口径）vs 训练行内随机 5 折残差（同研究口径））：", "",
      "| 模型 | 校准口径 | 1−α | 覆盖率 Taiwan | Shao | McGill | pooled 覆盖率 | 平均宽度 (MPa) |", "|---|---|---:|---:|---:|---:|---:|---:|"]
cfd = pd.DataFrame(out["conformal"]); cfp = pd.DataFrame(out["conformal_pooled"])
for _, r in cfp.iterrows():
    sub = cfd[(cfd.model == r.model) & (cfd.calib == r.calib) & (cfd.alpha == r.alpha)].set_index("fold")
    L.append(f"| {r.model} | {r.calib} | {1 - r.alpha:.1f} | " + " | ".join(f"{sub.loc[f, 'coverage']:.2f}" for f in C.QUANT_FOLDS)
             + f" | {r.coverage:.2f} | {r.width:.1f} |")
C.append_md("\n".join(L))
print("\n".join(L[:14]))
print("\n-> RESULTS.md 追加 §8 完成")
