#!/usr/bin/env python3
"""C1 model_experiments 公共模块：数据、折定义、物理特征、LOSO / 随机 5 折协议、结果落盘。

纪律（见 RESULTS.md §0）：
- 评价只在 leave-one-study-out（LOSO）：折定义与 experiment/loso_calibration.py 的 V0_PRIMARY 完全一致
  （TAIWAN_LEE_WANG 45 行 / SHAO_DOE_BLOCK 22 行 / MCGILL_LAB 76 行 = leave-one-lab-out；
  LI_HE_CHEN_2019 只有 2 行，不进定量表；93 行未溯源行永远只在训练侧）。
- 所有需要拟合的预处理（标准化、目标变换的统计量、超参选择）都封装在 make_model 返回的
  estimator 内部，只在训练行上 fit。本模块的特征工程 make_features() 是纯逐行变换，不含任何
  跨行统计量，故按构造无泄漏。
- 超参用训练研究内的嵌套 leave-one-group-out（inner_groups）选，测试折从不参与。
"""
from __future__ import annotations
import os, json, time, hashlib, platform, importlib, datetime
# 线程纪律：每个 worker 单线程（HistGradientBoosting / BLAS 默认吃满全部核，×joblib 会把机器压到 load 25）
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.model_selection import KFold, LeaveOneGroupOut
from sklearn.base import clone
from joblib import Parallel, delayed

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "../probe/data/scirep_MOESM1.xlsx")
PROV = os.path.join(HERE, "../probe/row_provenance.json")
UCI = os.path.join(HERE, "data/uci_concrete.csv")
RESDIR = os.path.join(HERE, "results")
RESULTS_MD = os.path.join(HERE, "RESULTS.md")
os.makedirs(RESDIR, exist_ok=True)

N_JOBS = int(os.environ.get("C1_NJOBS", "6"))          # 机器上有别的任务，≤ 8
DEFAULT_SEEDS = list(range(10))

RAW_COLS = ["C", "CA", "FA", "W", "blast furnace slag", "fly ash", "W/B",
            "CCU-steam curing time", "T", "CC", "P"]
TARGET = "CS"

# ----------------------------------------------------------------------------- 数据与折
_df = pd.read_excel(DATA)
assert _df.shape == (198, 12), _df.shape
assert list(_df.columns) == RAW_COLS + [TARGET], list(_df.columns)
_prov = json.load(open(PROV))["rows"]
assert len(_prov) == 198
CL = np.array([(r["study_cluster"] or "") for r in _prov])
CONF = np.array([r["confidence"] for r in _prov])
ROW1 = np.arange(1, 199)                                   # 1-based 行号

# 与 loso_calibration.py 逐字一致
MCGILL_EXTRA_CORE = sorted(set([34, 39, 40, 41, 64, 65, 87]) | set(range(188, 199)))
MCGILL_EXTRA_WIDE = sorted(set(MCGILL_EXTRA_CORE) | set(range(1, 17)) | set(range(28, 34)))

def _cl_rows(name):
    return {i + 1 for i in range(198) if CL[i] == name}

BLOCKS = {
    "TAIWAN_LEE_WANG": _cl_rows("TAIWAN_LEE_WANG"),
    "SHAO_DOE_BLOCK": _cl_rows("SHAO_DOE_BLOCK"),
    "MCGILL_LAB": _cl_rows("MCGILL_LWCMU") | _cl_rows("MCGILL_LIU_WETMIX") | set(MCGILL_EXTRA_WIDE),
    "LI_HE_CHEN_2019": _cl_rows("LI_HE_CHEN_2019"),
}
assert {k: len(v) for k, v in BLOCKS.items()} == {"TAIWAN_LEE_WANG": 45, "SHAO_DOE_BLOCK": 22,
                                                  "MCGILL_LAB": 76, "LI_HE_CHEN_2019": 2}
QUANT_FOLDS = ["TAIWAN_LEE_WANG", "SHAO_DOE_BLOCK", "MCGILL_LAB"]     # 进定量表的折（>=10 行）
QUAL_FOLDS = ["LI_HE_CHEN_2019"]                                        # 只作定性（n=2）

# 外层折标签（每行一个）。未溯源行按溯源笔记 §3 的配合比族给**推定**标签，仅用于
# 训练侧的嵌套分组 CV，永远不作为外层测试折。
OUTER = np.array([""] * 198, dtype=object)
for k, rows in BLOCKS.items():
    for r in rows:
        OUTER[r - 1] = k
INNER_GROUP = OUTER.copy()
for i in range(198):
    r = i + 1
    if INNER_GROUP[i]:
        continue
    if 93 <= r <= 117:
        INNER_GROUP[i] = "U_MORTAR_putative"        # C=719 砂浆，20% CO2（疑 ref64/67）
    elif 118 <= r <= 120:
        INNER_GROUP[i] = "U_PERVIOUS_putative"      # 透水混凝土
    elif 166 <= r <= 175:
        INNER_GROUP[i] = "U_BRICK_putative"         # 水泥砖（疑 ref60）
    else:
        INNER_GROUP[i] = "U_MISC_putative"
assert (OUTER != "").sum() == 145 and (INNER_GROUP != "").all()

Y = _df[TARGET].values.astype(float)
FEATKEY = np.array(["|".join(f"{v:.6g}" for v in r) for r in _df[RAW_COLS].values])

def fold_indices(fold):
    """返回 (train_idx, test_idx)，0-based。训练 = 198 − 该折整块（含 93 行未溯源 + 其它折）。"""
    te = np.array(sorted(r - 1 for r in BLOCKS[fold]), dtype=int)
    tr = np.array(sorted(set(range(198)) - set(te.tolist())), dtype=int)
    return tr, te

# ----------------------------------------------------------------------------- 物理特征
EPS = 1e-9

def make_features(df: pd.DataFrame, fs: str = "raw", harmonize_units: bool = True) -> pd.DataFrame:
    """纯逐行变换（无任何跨行统计量）。

    fs:
      raw        11 原始列
      phys       raw + 物理派生特征
      ratio      只保留尺度不变量（配比比例 + 养护参数），丢掉 kg/m³ 原始量
      ratio_d    ratio + 调和后的密度（total mass）
      phys_d     phys + 调和后的密度
    harmonize_units: 溯源笔记 §2.1 确证 SHAO_DOE_BLOCK 的部分行是按"总质量归一到 1000 kg"记的
      （C=100, W=56, CA=343, FA=519，合计 1018），不是 kg/m³。规则：total < 1200 的行视为
      归一化记录，其绝对量不可比，密度记缺失（树模型原生 NaN；其它模型用常数 2300 填补）。
      该规则是确定性的、不含任何标签信息、对训练/测试行一视同仁，故不是泄漏；但它是设计
      选择，RESULTS.md 中给出开/关消融。
    """
    d = df[RAW_COLS].copy().astype(float)
    mass_cols = ["C", "CA", "FA", "W", "blast furnace slag", "fly ash"]
    total0 = d[mass_cols].sum(axis=1)
    # harmonize_units: False/"off" | True/"flag"（默认）| "rescale"
    #   flag    : total<1200 的行 density_h=NaN、unit_normalized=1；绝对量原样保留
    #   rescale : 在 flag 之上，把 total<1200 且有骨料记录的行的 6 个质量列乘 2200/total
    #             （假设其为归一化记录，换算回近似 kg/m³；2200 为干硬性预制块的典型密度，
    #             是先验常数，不来自任何标签）。骨料未记录的行（195/196）不缩放。
    mode = {True: "flag", False: "off"}.get(harmonize_units, harmonize_units)
    if mode == "rescale":
        resc = (total0 < 1200) & ((d["CA"] + d["FA"] + d["blast furnace slag"]) > 0)
        fac = np.where(resc, 2200.0 / total0.replace(0, np.nan), 1.0)
        d[mass_cols] = d[mass_cols].mul(fac, axis=0)
    C, CA, FA, W = d["C"], d["CA"], d["FA"], d["W"]
    SLAG, ASH, WB, STEAM = d["blast furnace slag"], d["fly ash"], d["W/B"], d["CCU-steam curing time"]
    T, CC, P = d["T"], d["CC"], d["P"]
    out = pd.DataFrame(index=d.index)
    if fs in ("raw", "phys", "phys_d"):
        for c in RAW_COLS:
            out[c] = d[c].astype(float)
    if fs == "raw":
        return out

    binder = C + ASH                       # 溯源笔记 §1.1：slag 列在本库里是膨胀矿渣轻骨料，不是掺合料
    agg = CA + FA + SLAG
    total = C + CA + FA + W + SLAG + ASH
    normalized = (total0 < 1200) if mode in ("flag", "rescale") else pd.Series(False, index=d.index)

    feat = {}
    feat["wb"] = WB
    feat["cw"] = 1.0 / (WB + EPS)                     # Bolomey 线性项 c/w
    feat["cement_frac"] = C / (total + EPS)
    feat["water_frac"] = W / (total + EPS)
    feat["agg_frac"] = agg / (total + EPS)
    feat["paste_frac"] = (C + W + ASH) / (total + EPS)
    feat["fine_frac"] = FA / (agg + EPS)              # 砂率
    feat["agg_binder"] = agg / (binder + EPS)
    feat["ash_frac"] = ASH / (binder + EPS)
    feat["slag_agg_frac"] = SLAG / (agg + EPS)
    feat["log_agg_binder"] = np.log1p(feat["agg_binder"])
    # CO2 养护
    feat["T"] = T
    feat["log_T"] = np.log(T)
    feat["sqrt_T"] = np.sqrt(T)                       # 扩散控制的碳化深度 ∝ √t
    feat["CC"] = CC
    feat["P"] = P
    feat["log_P"] = np.log(P)
    feat["co2_pp"] = CC * P                           # CO2 分压 (MPa)
    feat["co2_dose"] = CC * P * T                     # 剂量 = 分压 × 时长 (MPa·h)
    feat["log_dose"] = np.log(feat["co2_dose"] + EPS)
    feat["sqrt_dose"] = np.sqrt(feat["co2_dose"])
    feat["steam"] = STEAM
    feat["steam_flag"] = (STEAM > 0).astype(float)
    # 密度（调和后）
    dens = total.astype(float).copy()
    dens[normalized] = np.nan
    feat["density_h"] = dens
    feat["unit_normalized"] = normalized.astype(float)

    F = pd.DataFrame(feat, index=d.index)
    if fs in ("phys", "phys_d"):
        F = F.drop(columns=["T", "CC", "P", "steam"])      # 这些已在 raw 列里
        out = pd.concat([out, F], axis=1)
        if fs == "phys":
            out = out.drop(columns=["density_h", "unit_normalized"])
        return out
    if fs in ("ratio", "ratio_d"):
        if fs == "ratio":
            F = F.drop(columns=["density_h", "unit_normalized"])
        return F
    raise ValueError(fs)

FEATURE_SETS = ["raw", "phys", "phys_d", "ratio", "ratio_d"]

def X_of(fs, harmonize_units=True, fill_nan=None):
    X = make_features(_df, fs, harmonize_units)
    if fill_nan is not None:
        X = X.fillna(fill_nan)
    return X

# ----------------------------------------------------------------------------- 目标变换
class TargetTf:
    """'none' | 'log'；只做确定性变换，无需拟合。"""
    def __init__(self, kind="log"):
        self.kind = kind
    def fwd(self, y):
        return np.log(y) if self.kind == "log" else np.asarray(y, float)
    def inv(self, z):
        # log 目标还原时把 z 截在 [log 0.1, log 500] MPa：防止线性/混合模型越界外推得到 inf（M1 Ridge、M5 MixedLM 实测）；
        # 截断只影响本来就已荒谬的预测，记入 RESULTS.md。
        return np.exp(np.clip(np.asarray(z, float), np.log(0.1), np.log(500.0))) if self.kind == "log" else np.asarray(z, float)

# ----------------------------------------------------------------------------- 指标
def metrics(yt, p):
    yt = np.asarray(yt, float); p = np.asarray(p, float)
    return dict(r2=float(r2_score(yt, p)), rmse=float(np.sqrt(mean_squared_error(yt, p))),
                mae=float(mean_absolute_error(yt, p)), n=int(len(yt)))

def _msd(vals):
    a = np.asarray(vals, float)
    return dict(mean=float(np.nanmean(a)), sd=float(np.nanstd(a, ddof=1)) if len(a) > 1 else 0.0, n=int(len(a)))

# ----------------------------------------------------------------------------- 协议
def _fit_predict(make_model, X, y, tr, te, seed, ttf, inner_groups=None, sample_weight_fn=None):
    """make_model(seed, inner_groups_of_train) -> estimator with fit/predict。
    inner_groups 只包含训练行的分组标签，供嵌套 CV 选超参。"""
    m = make_model(seed, inner_groups[tr] if inner_groups is not None else None)
    Xtr, Xte = X.iloc[tr], X.iloc[te]
    kw = {}
    if sample_weight_fn is not None:
        kw["sample_weight"] = sample_weight_fn(tr)
    m.fit(Xtr, ttf.fwd(y[tr]), **kw)
    return ttf.inv(m.predict(Xte))

def run_loso(make_model, fs="raw", target="log", seeds=DEFAULT_SEEDS, harmonize_units=True,
             fill_nan=None, n_jobs=N_JOBS, sample_weight_fn=None, X_override=None, verbose=True):
    """LOSO 主协议。返回 dict：
       per_fold[fold] = {r2/rmse/mae: mean±sd over seeds}, pooled (143 行) mean±sd, macro (3 折 R² 均值) mean±sd,
       qual (LI_HE_CHEN, n=2) 的绝对误差, preds[seed] 每行预测（用于集成/conformal）。"""
    X = X_override if X_override is not None else X_of(fs, harmonize_units, fill_nan)
    ttf = TargetTf(target)
    folds = QUANT_FOLDS + QUAL_FOLDS
    jobs, meta = [], []
    for s in seeds:
        for f in folds:
            tr, te = fold_indices(f)
            jobs.append(delayed(_fit_predict)(make_model, X, Y, tr, te, s, ttf, INNER_GROUP, sample_weight_fn))
            meta.append((s, f))
    t0 = time.time()
    preds = Parallel(n_jobs=n_jobs)(jobs)
    el = time.time() - t0
    per_seed = {s: {} for s in seeds}
    for (s, f), p in zip(meta, preds):
        per_seed[s][f] = np.asarray(p, float)
    out = dict(per_fold={}, pooled={}, macro={}, qual={}, seconds=el, n_seeds=len(seeds),
               fs=fs, target=target, harmonize_units=harmonize_units)
    pf = {f: {"r2": [], "rmse": [], "mae": []} for f in QUANT_FOLDS}
    pooled = {"r2": [], "rmse": [], "mae": []}
    macro = []
    qual = []
    pred_rows = {}
    for s in seeds:
        ys, ps = [], []
        r2s = []
        for f in QUANT_FOLDS:
            _, te = fold_indices(f)
            m = metrics(Y[te], per_seed[s][f])
            for k in ("r2", "rmse", "mae"):
                pf[f][k].append(m[k])
            r2s.append(m["r2"])
            ys.append(Y[te]); ps.append(per_seed[s][f])
        mp = metrics(np.concatenate(ys), np.concatenate(ps))
        for k in ("r2", "rmse", "mae"):
            pooled[k].append(mp[k])
        macro.append(float(np.mean(r2s)))
        _, teq = fold_indices("LI_HE_CHEN_2019")
        qual.append(float(np.mean(np.abs(Y[teq] - per_seed[s]["LI_HE_CHEN_2019"]))))
        full = np.full(198, np.nan)
        for f in folds:
            _, te = fold_indices(f)
            full[te] = per_seed[s][f]
        pred_rows[s] = full
    out["per_fold"] = {f: {k: _msd(v) for k, v in pf[f].items()} for f in QUANT_FOLDS}
    out["per_fold_n"] = {f: int(len(BLOCKS[f])) for f in QUANT_FOLDS}
    out["pooled"] = {k: _msd(v) for k, v in pooled.items()}
    out["macro_r2"] = _msd(macro)
    out["qual"] = {"LI_HE_CHEN_2019": dict(n=2, true=float(Y[fold_indices("LI_HE_CHEN_2019")[1]][0]),
                                          mae=_msd(qual))}
    out["preds"] = {int(s): pred_rows[s].tolist() for s in seeds}     # 行预测（含 LI 折）；用于集成/conformal
    if verbose:
        print(fmt_loso(out))
    return out

def run_random_kfold(make_model, fs="raw", target="log", seeds=DEFAULT_SEEDS, k=5, harmonize_units=True,
                     fill_nan=None, n_jobs=N_JOBS, sample_weight_fn=None, X_override=None, verbose=True):
    """文献协议：全 198 行随机 5 折（shuffle，seed）。同时给出只在 143 行可溯源行上打分的口径。
    嵌套超参选择仍用 INNER_GROUP（与 LOSO 一致），使两协议的差别只在外层划分。"""
    X = X_override if X_override is not None else X_of(fs, harmonize_units, fill_nan)
    ttf = TargetTf(target)
    jobs, meta = [], []
    for s in seeds:
        kf = KFold(n_splits=k, shuffle=True, random_state=s)
        for i, (tr, te) in enumerate(kf.split(X)):
            jobs.append(delayed(_fit_predict)(make_model, X, Y, tr, te, s, ttf, INNER_GROUP, sample_weight_fn))
            meta.append((s, i, te))
    t0 = time.time()
    preds = Parallel(n_jobs=n_jobs)(jobs)
    el = time.time() - t0
    full = {s: np.full(198, np.nan) for s in seeds}
    for (s, i, te), p in zip(meta, preds):
        full[s][te] = p
    traced = np.array(sorted(r - 1 for f in QUANT_FOLDS for r in BLOCKS[f]))
    leak = []
    for s in seeds:
        kf = KFold(n_splits=k, shuffle=True, random_state=s)
        for tr, te in kf.split(X):
            keys = set(FEATKEY[tr]); leak.append(np.mean([FEATKEY[i] in keys for i in te]))
    out = dict(k=k, n_seeds=len(seeds), seconds=el, fs=fs, target=target,
               all198={kk: _msd([metrics(Y, full[s])[kk] for s in seeds]) for kk in ("r2", "rmse", "mae")},
               traced143={kk: _msd([metrics(Y[traced], full[s][traced])[kk] for s in seeds]) for kk in ("r2", "rmse", "mae")},
               test_leak_rate=float(np.mean(leak)))
    if verbose:
        print(f"  random {k}-fold  all198 R²={out['all198']['r2']['mean']:.3f}±{out['all198']['r2']['sd']:.3f} "
              f"RMSE={out['all198']['rmse']['mean']:.2f} | traced143 R²={out['traced143']['r2']['mean']:.3f} "
              f"RMSE={out['traced143']['rmse']['mean']:.2f} | leak={out['test_leak_rate']*100:.0f}%  [{el:.0f}s]")
    return out

def fmt_loso(o):
    s = (f"  LOSO pooled R²={o['pooled']['r2']['mean']:+.3f}±{o['pooled']['r2']['sd']:.3f} "
         f"RMSE={o['pooled']['rmse']['mean']:.2f}±{o['pooled']['rmse']['sd']:.2f} MAE={o['pooled']['mae']['mean']:.2f} | "
         f"macro R²={o['macro_r2']['mean']:+.3f} | ")
    s += " ".join(f"{f[:6]}: R²={o['per_fold'][f]['r2']['mean']:+.2f} RMSE={o['per_fold'][f]['rmse']['mean']:.1f}"
                  for f in QUANT_FOLDS)
    s += f" | LI(n=2) |err|={o['qual']['LI_HE_CHEN_2019']['mae']['mean']:.1f}  [{o['seconds']:.0f}s]"
    return s

# ----------------------------------------------------------------------------- 嵌套超参选择
class NestedSelect:
    """在训练行内做 leave-one-group-out，按 pooled RMSE（MPa 尺度）选配置；然后用全部训练行重训。
    estimator 的 fit(X, z) 接收的是已变换目标 z（log 或原值），故这里通过 ttf 把预测还原后打分。"""
    def __init__(self, build, configs, groups, ttf, min_group=1, n_jobs=1):
        self.build, self.configs, self.groups, self.ttf = build, list(configs), np.asarray(groups), ttf
        self.n_jobs = n_jobs
        self.best_ = None
    def fit(self, X, z, sample_weight=None):
        X = X.reset_index(drop=True) if hasattr(X, "reset_index") else X
        z = np.asarray(z, float)
        y = self.ttf.inv(z)
        logo = LeaveOneGroupOut()
        splits = list(logo.split(X, z, self.groups))
        scores = []
        for cfg in self.configs:
            pred = np.full(len(z), np.nan)
            for tr, te in splits:
                m = self.build(cfg)
                kw = {} if sample_weight is None else {"sample_weight": np.asarray(sample_weight)[tr]}
                m.fit(X.iloc[tr] if hasattr(X, "iloc") else X[tr], z[tr], **kw)
                pred[te] = self.ttf.inv(m.predict(X.iloc[te] if hasattr(X, "iloc") else X[te]))
            scores.append(float(np.sqrt(np.mean((y - pred) ** 2))))
        self.inner_scores_ = scores
        self.best_ = self.configs[int(np.argmin(scores))]
        self.model_ = self.build(self.best_)
        kw = {} if sample_weight is None else {"sample_weight": sample_weight}
        self.model_.fit(X, z, **kw)
        return self
    def predict(self, X):
        return self.model_.predict(X)

# ----------------------------------------------------------------------------- 落盘
def env_info():
    e = {"python": platform.python_version(), "platform": platform.platform(), "machine": platform.machine(),
         "generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
         "data_sha256_16": hashlib.sha256(open(DATA, "rb").read()).hexdigest()[:16]}
    for mod in ["numpy", "pandas", "scipy", "sklearn", "xgboost", "lightgbm", "catboost", "tabpfn", "torch", "statsmodels"]:
        try:
            e[mod] = getattr(importlib.import_module(mod), "__version__", "?")
        except Exception:
            e[mod] = "NOT INSTALLED"
    return e

def save_json(name, obj):
    path = os.path.join(RESDIR, f"{name}.json")
    obj = dict(obj); obj["_env"] = env_info()
    json.dump(obj, open(path, "w"), indent=1, ensure_ascii=False)
    return path

def strip_preds(o):
    o = dict(o); o.pop("preds", None); return o

def append_md(text):
    with open(RESULTS_MD, "a") as f:
        f.write(text.rstrip() + "\n\n")

def md_row(name, loso, rand=None):
    """方法 × 协议 一行。"""
    pf = loso["per_fold"]
    cells = [name.replace("|", " · "),
             f"{loso['pooled']['r2']['mean']:+.3f} ± {loso['pooled']['r2']['sd']:.3f}",
             f"{loso['pooled']['rmse']['mean']:.2f} ± {loso['pooled']['rmse']['sd']:.2f}",
             f"{loso['pooled']['mae']['mean']:.2f}",
             f"{loso['macro_r2']['mean']:+.3f}",
             f"{pf['TAIWAN_LEE_WANG']['rmse']['mean']:.1f}", f"{pf['SHAO_DOE_BLOCK']['rmse']['mean']:.1f}",
             f"{pf['MCGILL_LAB']['rmse']['mean']:.1f}"]
    if rand is not None:
        cells += [f"{rand['all198']['r2']['mean']:.3f} ± {rand['all198']['r2']['sd']:.3f}",
                  f"{rand['all198']['rmse']['mean']:.2f}"]
    else:
        cells += ["—", "—"]
    return "| " + " | ".join(cells) + " |"

MD_HEADER = ("| 方法 | LOSO pooled R² | LOSO pooled RMSE | LOSO MAE | LOSO macro R² | RMSE Taiwan(45) | RMSE Shao(22) | RMSE McGill(76) | 随机5折 R² (198行) | 随机5折 RMSE |\n"
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|")

def per_fold_table(name, loso):
    rows = [f"**{name.replace('|', ' · ')}** — 每个留出研究（{loso['n_seeds']} 个种子 mean ± SD）", "",
            "| 留出研究 | n | R² | RMSE (MPa) | MAE (MPa) |", "|---|---:|---:|---:|---:|"]
    for f in QUANT_FOLDS:
        d = loso["per_fold"][f]
        rows.append(f"| {f} | {loso['per_fold_n'][f]} | {d['r2']['mean']:+.3f} ± {d['r2']['sd']:.3f} | "
                    f"{d['rmse']['mean']:.2f} ± {d['rmse']['sd']:.2f} | {d['mae']['mean']:.2f} |")
    q = loso["qual"]["LI_HE_CHEN_2019"]
    rows.append(f"| LI_HE_CHEN_2019（定性） | 2 | — | — | {q['mae']['mean']:.2f}（真值 {q['true']:.1f}） |")
    rows.append(f"| **pooled 143** | 143 | **{loso['pooled']['r2']['mean']:+.3f} ± {loso['pooled']['r2']['sd']:.3f}** | "
                f"{loso['pooled']['rmse']['mean']:.2f} ± {loso['pooled']['rmse']['sd']:.2f} | {loso['pooled']['mae']['mean']:.2f} |")
    rows.append(f"| macro（3 折 R² 均值） | — | {loso['macro_r2']['mean']:+.3f} ± {loso['macro_r2']['sd']:.3f} | — | — |")
    return "\n".join(rows)

if __name__ == "__main__":
    print("folds:", {k: len(v) for k, v in BLOCKS.items()})
    print("inner groups:", dict(zip(*np.unique(INNER_GROUP, return_counts=True))))
    for fs in FEATURE_SETS:
        X = X_of(fs)
        print(fs, X.shape, "nan:", int(X.isna().sum().sum()))
    print(X_of("ratio_d").describe().T.round(3).to_string())
