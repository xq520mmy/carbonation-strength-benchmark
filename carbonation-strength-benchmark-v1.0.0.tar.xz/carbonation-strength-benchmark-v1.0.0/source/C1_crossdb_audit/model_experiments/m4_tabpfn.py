#!/usr/bin/env python3
"""M4：TabPFN v2（tabpfn==2.2.1，CPU，预训练权重已缓存于 ~/Library/Caches/tabpfn）。
零超参；只换特征集与目标变换。顺序执行（n_jobs=1），torch 线程 ≤ 4。"""
import sys, os, numpy as np
os.environ.setdefault("OMP_NUM_THREADS", "4")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
import torch
torch.set_num_threads(4)
from tabpfn import TabPFNRegressor

SEEDS = list(range(5))

class TabPFNWrap:
    """TabPFN 2.2.1 接口：fit(X, y) / predict(X) 返回均值。X 可含 NaN。"""
    def __init__(self, seed):
        self.m = TabPFNRegressor(device="cpu", random_state=seed)
    def fit(self, X, y):
        self.m.fit(np.asarray(X, float), np.asarray(y, float)); return self
    def predict(self, X):
        return np.asarray(self.m.predict(np.asarray(X, float)), float)

def make(seed, groups):
    return TabPFNWrap(seed)

R = {"_desc": "M4 TabPFN v2 (2.2.1, CPU)", "runs": {}}
import json
_prev = os.path.join(C.RESDIR, "m4_tabpfn.json")
if os.path.exists(_prev):
    R["runs"] = json.load(open(_prev))["runs"]; print(f"resume: {len(R['runs'])} done")

def do(name, fs, target, harm="flag"):
    if name in R["runs"]:
        return
    print(f"\n### {name}", flush=True)
    lo = C.run_loso(make, fs, target, SEEDS, harmonize_units=harm, n_jobs=1)
    ra = C.run_random_kfold(make, fs, target, SEEDS, harmonize_units=harm, n_jobs=1)
    R["runs"][name] = dict(fs=fs, target=target, harm=harm, loso=C.strip_preds(lo), rand=ra,
                           loso_pred_mean=np.nanmean(np.array([lo["preds"][s] for s in lo["preds"]]), axis=0).tolist())
    C.save_json("m4_tabpfn", R)

do("TabPFN|raw|none|flag", "raw", "none", "flag")
do("TabPFN|raw|none|rescale", "raw", "none", "rescale")
do("TabPFN|raw|log|rescale", "raw", "log", "rescale")
do("TabPFN|phys_d|none|rescale", "phys_d", "none", "rescale")
do("TabPFN|ratio_d|log|flag", "ratio_d", "log", "flag")

lines = ["## §4 M4：TabPFN v2（预训练表格 transformer，零超参，CPU）", "",
         f"脚本 `m4_tabpfn.py`，结果 `results/m4_tabpfn.json`。{len(SEEDS)} 个种子（random_state 只影响集成内部的置换）。", "", C.MD_HEADER]
for k, v in R["runs"].items():
    lines.append(C.md_row(k, v["loso"], v["rand"]))
best = max(R["runs"].items(), key=lambda kv: kv[1]["loso"]["pooled"]["r2"]["mean"])
lines += ["", f"M4 内最佳：**{best[0]}**", "", C.per_fold_table(best[0], best[1]["loso"])]
C.append_md("\n".join(lines))
print("\n-> RESULTS.md 追加 §4 完成")
