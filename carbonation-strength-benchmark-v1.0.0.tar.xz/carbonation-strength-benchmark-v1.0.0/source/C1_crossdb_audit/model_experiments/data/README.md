# UCI concrete data used for transfer pretraining

`uci_concrete.csv` contains the 1,030-row, 9-column UCI Machine Learning Repository **Concrete Compressive Strength** dataset. It is used only for transfer pretraining and never for evaluation in this package. The CSV is a delimiter-based conversion of the UCI tabular fields for use by the supplied Python scripts; the nine variable columns and held row order are retained in this package copy.

See `THIRD_PARTY_NOTICES.md` at the release root for the UCI license link, dataset identifier, and citation. The data include 25 exactly duplicated rows (996 unique feature vectors), so their repeated structure is not used as an independent evaluation set.
