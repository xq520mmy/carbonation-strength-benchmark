#!/usr/bin/env python3
"""M9：选择偏差的诚实核算。

M1–M7 的每个"最佳"都是在 3 个 LOSO 测试折上挑出来的。本脚本汇总所有已跑配置（results/m*.json 里带 per_fold 的 run），做：
  (1) 计数：一共试了多少个配置；
  (2) select-by-other-studies：对每个留出折 f，只用**其余两个折**的 pooled RMSE 选配置 c*(f)，再报 c*(f) 在 f 上的 RMSE。
      把 3 个折拼起来就是"选择也被留出"的 LOSO 估计——选择过程从未看到被评估折。
  (3) 与"全局最佳（看了 3 折挑的）"对比，差值 = 选择乐观度。
  (4) 同时给 M8 的 select-by-inner（训练研究内 inner LOGO 选）结果做对照。
"""
import sys, os, json, glob, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C

runs = {}
for path in sorted(glob.glob(os.path.join(C.RESDIR, "m[1-7]_*.json"))):
    R = json.load(open(path)); tag = os.path.basename(path).split("_")[0].upper()
    for k, v in R.get("runs", {}).items():
        lo = v["loso"]
        if not np.isfinite(lo["pooled"]["r2"]["mean"]):
            continue
        runs[f"{tag}:{k}"] = lo
print(f"{len(runs)} 个配置")

F = C.QUANT_FOLDS
n = {f: len(C.BLOCKS[f]) for f in F}
tab = pd.DataFrame({name: {f: lo["per_fold"][f]["rmse"]["mean"] for f in F} for name, lo in runs.items()}).T
tab["pooled_rmse"] = np.sqrt(sum(tab[f] ** 2 * n[f] for f in F) / sum(n.values()))
tab["pooled_r2_json"] = [runs[k]["pooled"]["r2"]["mean"] for k in tab.index]
tab["macro_r2_json"] = [runs[k]["macro_r2"]["mean"] for k in tab.index]
VAR143 = float(np.var(C.Y[np.array(sorted(r - 1 for f in F for r in C.BLOCKS[f]))]))

def r2_from_rmse(rmse): return 1 - rmse ** 2 / VAR143

# (2) select-by-other-studies
sel = {}
for f in F:
    others = [g for g in F if g != f]
    score = np.sqrt(sum(tab[g] ** 2 * n[g] for g in others) / sum(n[g] for g in others))
    c = score.idxmin()
    sel[f] = dict(selected=c, rmse_on_f=float(tab.loc[c, f]), selection_score_others=float(score.min()))
pooled_sel_rmse = float(np.sqrt(sum(sel[f]["rmse_on_f"] ** 2 * n[f] for f in F) / sum(n.values())))
best_global = tab["pooled_rmse"].idxmin()
out = dict(n_configs=len(runs), select_by_other_studies=sel, pooled_rmse_select_by_others=pooled_sel_rmse,
           pooled_r2_select_by_others=r2_from_rmse(pooled_sel_rmse),
           best_global=dict(name=best_global, pooled_rmse=float(tab.loc[best_global, "pooled_rmse"]),
                            pooled_r2=r2_from_rmse(float(tab.loc[best_global, "pooled_rmse"]))),
           table=tab.sort_values("pooled_rmse").round(3).reset_index().rename(columns={"index": "config"}).to_dict(orient="records"))
# 每折上的"最佳" vs 被选中的
per_fold_best = {f: dict(best=tab[f].idxmin(), rmse=float(tab[f].min())) for f in F}
out["per_fold_oracle"] = per_fold_best
# M8 对照
m8p = os.path.join(C.RESDIR, "m8_ensemble_conformal.json")
if os.path.exists(m8p):
    M8 = json.load(open(m8p))["methods"]
    out["m8_select_by_inner"] = M8["select-by-inner"]["pooled"]; out["m8_stack"] = M8["stack-NNLS"]["pooled"]
C.save_json("m9_honest_selection", out)

L = ["## §9 M9：选择偏差的诚实核算", "",
     f"脚本 `m9_honest_selection.py`，结果 `results/m9_honest_selection.json`。汇总 M1–M7 共 **{len(runs)} 个配置**（每个配置的每折 RMSE 取种子均值）。", "",
     "| 口径 | 选择看到了什么 | LOSO pooled RMSE | LOSO pooled R² |", "|---|---|---:|---:|",
     f"| 全局最佳（{best_global.replace('|', ' · ')}） | 3 个测试折全部 | {out['best_global']['pooled_rmse']:.2f} | {out['best_global']['pooled_r2']:+.3f} |",
     f"| **select-by-other-studies** | 只看其余两个折 | **{pooled_sel_rmse:.2f}** | **{out['pooled_r2_select_by_others']:+.3f}** |"]
if "m8_select_by_inner" in out:
    L.append(f"| M8 select-by-inner（4 候选） | 只看训练研究内 inner LOGO | {out['m8_select_by_inner']['rmse']['mean']:.2f} | {out['m8_select_by_inner']['r2']['mean']:+.3f} |")
    L.append(f"| M8 stack-NNLS（4 候选） | 只看训练研究内 inner LOGO | {out['m8_stack']['rmse']['mean']:.2f} | {out['m8_stack']['r2']['mean']:+.3f} |")
L += ["", "select-by-other-studies 的逐折明细：", "", "| 被评估折 | 用其余两折选出的配置 | 其余两折 pooled RMSE | 在被评估折上的 RMSE | 该折上的事后最佳（oracle） |", "|---|---|---:|---:|---|"]
for f in F:
    L.append(f"| {f} | {sel[f]['selected'].replace('|', ' · ')} | {sel[f]['selection_score_others']:.2f} | {sel[f]['rmse_on_f']:.2f} | {per_fold_best[f]['best'].replace('|', ' · ')} ({per_fold_best[f]['rmse']:.2f}) |")
L += ["", "前 15 名配置（按 pooled RMSE）：", "", "| 配置 | RMSE Taiwan | RMSE Shao | RMSE McGill | pooled RMSE | pooled R² |", "|---|---:|---:|---:|---:|---:|"]
for r in out["table"][:15]:
    L.append(f"| {r['config'].replace('|', ' · ')} | {r['TAIWAN_LEE_WANG']:.2f} | {r['SHAO_DOE_BLOCK']:.2f} | {r['MCGILL_LAB']:.2f} | {r['pooled_rmse']:.2f} | {r['pooled_r2_json']:+.3f} |")
C.append_md("\n".join(L))
print("\n".join(L))
