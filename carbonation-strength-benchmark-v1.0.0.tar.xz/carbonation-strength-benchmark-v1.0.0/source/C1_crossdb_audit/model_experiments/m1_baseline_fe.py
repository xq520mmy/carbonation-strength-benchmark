#!/usr/bin/env python3
"""M1：基线复现 + 物理特征工程 × 目标变换消融（sklearn 模型族：RF / ExtraTrees / HistGB / Ridge）。

- RF(300) raw + none 目标 = experiment/loso_calibration.py 的基线（其 pooled 0.499 为 seed 0 单种子）。
- 之后在 5 个特征集 × 2 个目标变换上扫 RF / ET / HGB；Ridge（log 目标，StandardScaler + 嵌套选 alpha）作物理线性模型。
- 每个配置同时跑 LOSO 与随机 5 折。
"""
import sys, os, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

SEEDS = C.DEFAULT_SEEDS          # 10 个种子

def rf(seed, groups):
    return RandomForestRegressor(n_estimators=300, random_state=seed, n_jobs=1)

def et(seed, groups):
    return ExtraTreesRegressor(n_estimators=300, random_state=seed, n_jobs=1)

def hgb(seed, groups):
    return HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=15,
                                         min_samples_leaf=5, random_state=seed)

def ridge_nested(target):
    ttf = C.TargetTf(target)
    def make(seed, groups):
        build = lambda a: make_pipeline(StandardScaler(), Ridge(alpha=a))
        return C.NestedSelect(build, [0.01, 0.03, 0.1, 0.3, 1, 3, 10, 30, 100], groups, ttf)
    return make

R = {"_desc": "M1 基线 + 特征工程 × 目标变换消融", "runs": {}}
_prev = os.path.join(C.RESDIR, "m1_baseline_fe.json")
if os.path.exists(_prev):                     # 断点续跑：已完成的配置直接沿用
    R["runs"] = json.load(open(_prev))["runs"]
    print(f"resume: {len(R['runs'])} runs already done")

def do(name, make, fs, target, seeds, fill_nan=None, harmonize=True):
    if name in R["runs"]:
        return None, None
    print(f"\n### {name}  fs={fs} target={target} harmonize={harmonize}", flush=True)
    lo = C.run_loso(make, fs, target, seeds, harmonize_units=harmonize, fill_nan=fill_nan)
    ra = C.run_random_kfold(make, fs, target, seeds, harmonize_units=harmonize, fill_nan=fill_nan)
    R["runs"][name] = dict(model=name.split("|")[0], fs=fs, target=target, harmonize=harmonize,
                           loso=C.strip_preds(lo), rand=ra)
    # 保存行预测（种子均值）供后续集成
    P = np.nanmean(np.array([lo["preds"][s] for s in lo["preds"]]), axis=0)
    R["runs"][name]["loso_pred_mean"] = P.tolist()
    C.save_json("m1_baseline_fe", R)
    return lo, ra

# ---- 1. 基线复现：RF raw none
do("RF300|raw|none", rf, "raw", "none", SEEDS)

# ---- 2. 特征集 × 目标变换：RF / ET / HGB
for model_name, make in [("RF300", rf), ("ET300", et), ("HGB", hgb)]:
    for fs in C.FEATURE_SETS:
        for target in ("none", "log"):
            key = f"{model_name}|{fs}|{target}"
            if key in R["runs"]:
                continue
            fill = None if model_name == "HGB" else 2300.0     # RF/ET 不吃 NaN
            do(key, make, fs, target, SEEDS, fill_nan=fill)

# ---- 3. 物理线性模型：Ridge（确定性，1 个种子）
for fs in ("phys", "phys_d", "ratio", "ratio_d"):
    for target in ("none", "log"):
        do(f"Ridge|{fs}|{target}", ridge_nested(target), fs, target, [0], fill_nan=2300.0)

# ---- 4. 单位调和规则消融
#   noharm : 关掉 harmonize（density_h = 原始总质量，无 NaN）
#   rescale: total<1200 且有骨料记录的行，质量列乘 2200/total 换算回近似 kg/m³（先验常数 2200）
for model_name, make in [("RF300", rf), ("HGB", hgb)]:
    for fs in ("phys_d", "ratio_d"):
        do(f"{model_name}|{fs}|log|noharm", make, fs, "log", SEEDS, fill_nan=None if model_name == "HGB" else 2300.0,
           harmonize=False)
for model_name, make in [("RF300", rf), ("ET300", et), ("HGB", hgb)]:
    for fs in ("raw", "phys_d"):
        do(f"{model_name}|{fs}|none|rescale", make, fs, "none", SEEDS, fill_nan=None if model_name == "HGB" else 2300.0,
           harmonize="rescale")

# ---- 渲染到 RESULTS.md
lines = ["## §1 M1：基线复现 + 物理特征工程 × 目标变换（sklearn 族）", "",
         f"脚本 `m1_baseline_fe.py`，结果 `results/m1_baseline_fe.json`。随机模型 {len(SEEDS)} 个种子；Ridge 确定性（1 个种子）。",
         "RF/ET 的 density_h 缺失以常数 2300 填补；HGB 原生处理 NaN。", "", C.MD_HEADER]
for k, v in R["runs"].items():
    lines.append(C.md_row(k, v["loso"], v["rand"]))
base = R["runs"]["RF300|raw|none"]["loso"]
lines += ["", f"基线复现：RF300 raw none 的 LOSO pooled R² = {base['pooled']['r2']['mean']:+.3f} ± {base['pooled']['r2']['sd']:.3f}"
          f"（loso_calibration.py 报 seed 0 单种子 +0.499）。", ""]
# 最佳配置的每研究表
best = max(R["runs"].items(), key=lambda kv: kv[1]["loso"]["pooled"]["r2"]["mean"])
lines += [f"M1 内 LOSO pooled R² 最高的配置：**{best[0]}**", "", C.per_fold_table(best[0], best[1]["loso"])]
C.append_md("\n".join(lines))
print("\n-> RESULTS.md 追加 §1 完成")
