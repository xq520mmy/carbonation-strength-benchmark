# Data pointer (no data file is distributed in this repository)

The 198-row database analysed in the paper is **not** included here. It is the supplementary
table of one of the three studies examined, distributed by that study's publisher under a
CC BY-NC-ND 4.0 licence (per the Crossref record of the DOI below). We do not redistribute it;
obtain it from the publisher and place it in this directory under the exact file name the
scripts expect.

| Item | Value |
|---|---|
| Expected path | `probe/data/scirep_MOESM1.xlsx` |
| Source article | Scientific Reports, DOI `10.1038/s41598-026-56278-y` (labelled SciRep2026 in the paper) |
| Where on the article page | "Supplementary Information" -> Supplementary Information 1 (file name on download: `41598_2026_56278_MOESM1_ESM.xlsx`; rename to `scirep_MOESM1.xlsx`) |
| Obtained | 2026-09-17, manually from the article page (the publisher's static-content URL pattern did not resolve for scripted download) |
| Size | 22,321 bytes |
| SHA-256 | `f9e9e195e680d39ea89ebcaf9c50dbf90118c47dc63afcb675f22f7feb9b406b` |
| Layout | one sheet (`Sheet1`); header row + 198 data rows; 12 named columns `C, CA, FA, W, blast furnace slag, fly ash, W/B, CCU-steam curing time, T, CC, P, CS` plus one empty unnamed trailing column (dropped by the scripts) |

Verify before running anything:

```
shasum -a 256 probe/data/scirep_MOESM1.xlsx
# f9e9e195e680d39ea89ebcaf9c50dbf90118c47dc63afcb675f22f7feb9b406b
```

If the hash differs, the publisher has re-issued the file (the article was marked "Article in
Press" when we downloaded it) and every number in the paper should be recomputed with
`experiment/fingerprint_check.py` before anything else is compared.

Column meanings were decoded and cross-checked against four source publications; see
`probe/row_provenance.json` -> `_meta.columns_decoded` (note that `T` is the CO2-curing duration
in hours, not a temperature, and `P` is in MPa).

The second supplementary file of the same article (MOESM2, a `.docx` containing the learning-curve /
cross-validation / overfitting diagnostics discussed in Section 4.7 of the paper) is likewise not
redistributed and is not read by any script. For reference: 2,681,347 bytes,
SHA-256 `4ff30da45005bd9a56169062488fea282e81e36a9dc45895c7517a8c56a6944b`.
