"""Explicit opt-in portable refit of the original, frozen 319-job matrix.

Imports unchanged original estimator/worker functions. Supply lawful local data.
This does not rerun later GUI/source-guided or TabPFN extensions.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, math

ROOT = Path(__file__).resolve().parents[1]

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--carbonation', type=Path, required=True)
    p.add_argument('--yeh', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    assert not args.output.exists(), 'Never overwrite saved or earlier refit outputs'
    import numpy as np
    import pandas as pd
    from importlib.metadata import version
    metadata = json.loads((ROOT / 'data/DATA_ACCESS_AND_HASHES.json').read_text())
    spec = importlib.util.spec_from_file_location('unchanged_original_cpu_matrix', ROOT / 'original/run_cpu_reconstruction.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    module.DATA = {}
    for key, path in [('carbonation198', args.carbonation), ('yeh1030', args.yeh)]:
        assert sha(path) == metadata['inputs'][key]['sha256'], 'Exact original input bytes required for ' + key
        df = pd.read_excel(path) if path.suffix == '.xlsx' else pd.read_csv(path)
        a = df.to_numpy(float); assert np.isfinite(a).all()
        assert list(a.shape) == metadata['statistics'][key]['shape']
        groups = np.array([hashlib.sha256('|'.join(float(x).hex() for x in row).encode()).hexdigest() for row in a])
        module.DATA[key] = (df, a[:, -1], groups)
    plan = json.loads((ROOT / 'original/FROZEN_CPU_PLAN.json').read_text())
    actual_versions = {k: version(k) for k in plan['versions']}
    assert actual_versions == plan['versions'], 'Use the exact frozen dependency versions; no silent environment equivalence'
    args.output.mkdir(parents=True)
    records = []
    for job in plan['jobs']:
        record = module.worker(job)
        path = args.output / (job['job_id'] + '.json')
        path.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
        records.append({'job': job['job_id'], 'sha256': sha(path), 'actual_fits': record['actual_fits']})
        print(json.dumps({'completed': len(records), 'total': len(plan['jobs'])}), flush=True)
    assert len(records) == 319 and sum(r['actual_fits'] for r in records) == 1488
    (args.output / 'REFIT_COMPLETE.json').write_text(json.dumps({
        'status': 'COMPLETE_OPT_IN_ORIGINAL319_REFIT', 'files': records, 'versions': actual_versions,
        'original_source_sha256': sha(ROOT / 'original/run_cpu_reconstruction.py'),
        'portable_wrapper_sha256': sha(__file__), 'scope': 'Original 319 jobs only; no claim of bitwise equality without separately comparing saved predictions.'
    }, indent=2) + '\n')
