"""Portable arithmetic replay of all 1,151 saved final prediction cells.

Standard library only. No estimator import, data download, refit or resampling.
The original 1,128 cells and later source-driven extensions remain distinct.
"""
from pathlib import Path
import csv, hashlib, json, math, argparse, collections

ROOT = Path(__file__).resolve().parents[1]
CHECKS = 0

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def ck(value, message):
    global CHECKS
    CHECKS += 1
    if not value:
        raise AssertionError(message)

def load(p):
    return json.loads(Path(p).read_text(), parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))

def quantile(v, p):
    a = sorted(v); index = (len(a) - 1) * p
    lo = int(math.floor(index)); hi = int(math.ceil(index))
    return a[lo] + (a[hi] - a[lo]) * (index - lo)

def metrics(record):
    y, pred = record['y_true'], record['y_pred']
    te, tr = record['test_rows'], record['train_rows']
    ck(len(y) == len(pred) == len(te) and len(te) > 0, 'Complete saved test rows')
    ck(len(set(te)) == len(te) and len(set(tr)) == len(tr) and not set(te) & set(tr), 'Disjoint unique row IDs')
    ck(all(type(v) in [int, float] and math.isfinite(v) for v in y + pred), 'Finite predictions and targets')
    n = len(y); mu = math.fsum(y) / n
    sse = math.fsum((a - b) ** 2 for a, b in zip(y, pred))
    sst = math.fsum((v - mu) ** 2 for v in y)
    result = {'r2': None if sst == 0 else 1 - sse / sst,
              'rmse': math.sqrt(sse / n), 'mae': math.fsum(abs(a - b) for a, b in zip(y, pred)) / n}
    saved = record.get('metrics', record)
    for k, value in result.items():
        ck((value is None and saved[k] is None) or
           (value is not None and saved[k] is not None and abs(value - saved[k]) < 1e-11), 'Independent ' + k)
    return result

def main(output):
    ck(not output.exists(), 'Never overwrite a replay receipt')
    manifest = load(ROOT / 'PUBLIC_PAYLOAD_MANIFEST.json')
    for name, digest in manifest['files'].items():
        ck(sha(ROOT / name) == digest, 'Unchanged archive member ' + name)
    plan = load(ROOT / 'original/FROZEN_CPU_PLAN.json')
    terminal = load(ROOT / 'saved/cpu_results/ALL_COMPLETED.json')
    ck(terminal['status'] == 'COMPLETE' and len(terminal['jobs']) == 319, 'Complete original 319 jobs')
    ck(terminal['actual_fits'] == terminal['planned_fits'] == plan['total_planned_fits'] == 1488, 'Original 1,488 fits')
    declared = {r['job_id']: r for r in plan['jobs']}
    seen = set(); paired = []; total_cells = 0; fit_sum = 0; truths = collections.defaultdict(dict)
    for entry in terminal['jobs']:
        path = ROOT / 'saved/cpu_results' / entry['path']
        ck(sha(path) == entry['sha256'], 'Original job binding')
        rec = load(path); job = rec['job']; jid = job['job_id']
        ck(jid not in seen and job == declared[jid] and rec['status'] == 'COMPLETE', 'Frozen complete original job')
        seen.add(jid); fit_sum += rec['actual_fits']; results = {}
        for arm, cell in rec['arms'].items():
            ck(cell['train_rows'] == job['arms'][arm]['train'] and cell['test_rows'] == job['arms'][arm]['test'], 'Frozen row membership')
            results[arm] = metrics(cell); total_cells += 1
            for row_id, target in zip(cell['test_rows'], cell['y_true']):
                ck(row_id not in truths[job['dataset']] or truths[job['dataset']][row_id] == target, 'Consistent repeated targets')
                truths[job['dataset']][row_id] = target
        if 'purge_twin' in results:
            a, b, c = [rec['arms'][x] for x in ['row_random', 'purge_twin', 'size_control']]
            ck(a['test_rows'] == b['test_rows'] == c['test_rows'], 'Fixed test across deletion arms')
            ck(len(b['train_rows']) == len(c['train_rows']), 'Matched deletion size')
            ck(a['model_params'] == b['model_params'] == c['model_params'], 'Matched model configuration')
            for name in ['r2', 'rmse', 'mae']:
                paired.append({'stage': job['stage'], 'dataset': job['dataset'], 'model': job['model'],
                               'seed': job['seed'], 'metric': name,
                               'delta': results['purge_twin'][name] - results['size_control'][name]})
    ck(len(seen) == 319 and total_cells == 1128 and fit_sum == 1488, 'Entire original matrix retained')
    summaries = list(csv.DictReader((ROOT / 'saved/independent_cpu_qa/split_distribution_summary.csv').open()))
    for row in summaries:
        selected = [r for r in paired if all(str(r[k]) == row[k] for k in ['stage', 'dataset', 'model', 'metric'])]
        ck(sorted(r['seed'] for r in selected) == list(range(50)), 'All 50 seeds per contrast')
        v = [r['delta'] for r in selected]
        values = {'mean_purge_minus_control': math.fsum(v) / 50,
                  'split_quantile_025': quantile(v, .025), 'split_quantile_975': quantile(v, .975)}
        for name, value in values.items():
            ck(abs(float(row[name]) - value) < 1e-11, 'Saved split summary ' + name)
        for name, value in [('negative_splits', sum(x < 0 for x in v)), ('positive_splits', sum(x > 0 for x in v)), ('zero_splits', sum(x == 0 for x in v))]:
            ck(int(row[name]) == value, 'All sign reversals retained')
    for kind in ['wani_gui_source_amendment', 'tabpfn_cpu_approximation']:
        extension = load(ROOT / 'saved' / kind / 'RESULTS.json')
        ck(len(extension['arms']) == 4, 'Complete source-driven four-arm extension')
        for cell in extension['arms'].values():
            metrics(cell); total_cells += 1
    source = load(ROOT / 'saved/source_pipeline_amendment/RESULTS.json')
    ck(source['status'] == 'COMPLETE_15_SOURCE_SENSITIVITY_CELLS' and len(source['cells']) == 15, 'Complete source sensitivity')
    for cell in source['cells']:
        metrics(cell); total_cells += 1
    ck(total_cells == 1151, 'All 1,151 final prediction cells')
    # Validate the exact expectation for every supplied curve row without raw data.
    stats = load(ROOT / 'data/DATA_ACCESS_AND_HASHES.json')['statistics']
    formula_rows = 0
    for row in csv.DictReader((ROOT / 'saved/duplicate_exposure/uniform_random_split_curves.csv').open()):
        n, N = int(row['test_n']), int(row['N']); s = stats[row['dataset']]
        sizes = [int(k) for k, count in s['duplicate_group_sizes'].items() for _ in range(count)]
        sizes += [1] * (N - sum(sizes))
        value = math.fsum(m / N * (1 - (math.comb(n - 1, m - 1) / math.comb(N - 1, m - 1) if m <= n else 0)) for m in sizes)
        ck(abs(value - float(row['expected_exposed_test_fraction'])) < 1e-14, 'Exact arbitrary-group expectation')
        formula_rows += 1
    ck(formula_rows == 1226, 'All formula curve rows')
    result = {'status': 'PASS_PORTABLE_SAVED_REVISION_ARITHMETIC', 'checks': CHECKS, 'errors': [],
              'original_jobs': len(seen), 'final_prediction_cells': total_cells, 'formula_curve_rows': formula_rows,
              'original_fit_count': 1488, 'archive_manifest_sha256': sha(ROOT / 'PUBLIC_PAYLOAD_MANIFEST.json'),
              'verifier_sha256': sha(__file__), 'limits': [
                  'This verifies saved arithmetic and declared row membership, not refit equivalence or physical-origin independence.',
                  'Raw-input duplicate identity remains separately bound to lawful source files; the archive does not contain the workbooks.',
                  'Split quantiles are variation across 50 partitions, not population confidence intervals.',
                  'Original 1488-fit count excludes later 540 CV fits, 16 final fits and seven TabPFN context fits; all extensions remain separately labelled.',
                  'The TabPFN approximation is not a recovered unavailable exact original implementation; negative and reverse comparisons are retained.']}
    with output.open('x') as f:
        json.dump(result, f, indent=2, allow_nan=False); f.write('\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'original_jobs', 'final_prediction_cells', 'formula_curve_rows']}))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path, required=True)
    main(parser.parse_args().output)
