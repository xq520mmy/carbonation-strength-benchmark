"""Exact expected fraction of test rows with a training twin.

Only a uniform split without replacement with fixed test size is covered.
"""
import argparse, importlib.util, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--sizes', type=int, nargs='+', required=True)
    p.add_argument('--test-n', type=int, required=True)
    args = p.parse_args()
    spec = importlib.util.spec_from_file_location('original_exact_exposure', ROOT / 'original/general_duplicate_exposure.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    print(json.dumps({'group_sizes': args.sizes, 'test_n': args.test_n,
                      'expected_exposed_test_fraction': module.expectation(args.sizes, args.test_n),
                      'scope': 'Uniform fixed-size random partition; not group-disjoint or constrained stratified splitting.'}))
