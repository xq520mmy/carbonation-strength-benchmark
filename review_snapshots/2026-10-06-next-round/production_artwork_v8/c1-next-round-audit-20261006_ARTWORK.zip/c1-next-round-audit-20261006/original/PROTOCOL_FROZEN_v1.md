# C1 → CSCM: next-round frozen protocol v1

Status: FROZEN_BEFORE_NEW_FITS following root review on 2026-10-06. No new model fit has run. Local prospective analysis, not an external preregistration. Historical results and all old files remain separate and unchanged.

## Questions and interpretation

1. Can a stated headline be reproduced with the information actually available? Absolute R² difference ≤0.01 is a reporting category, never a stopping/tuning target. Report the pre-fixed seed-0 result even if outside tolerance, with all missing specifications. No split or model is selected by test R².
2. Does removing exact full-row training twins change prediction relative to removing the same number of non-twin training rows, on the identical fixed test rows? The treatment is numeric record availability, not specimen identity or proof of misconduct.
3. Does the same intervention have the same direction on a second concrete dataset? Yeh is a secondary tabular benchmark, not an independent carbonation experiment, external validation population, or same physical mechanism.
4. Generalize expected twin exposure under a uniform fixed-size random split to arbitrary duplicate groups, including sizes 3 and 4. Do not apply the formula unchanged to stratified or group-disjoint designs.

## Input facts and missing original specifications

- Chu/Alsharedah public numeric table: 198 rows, 11 stored inputs plus CS, 165 unique complete rows, 33 duplicate groups of size 2, 66 participating rows. Numeric equality does not identify physical specimens or copying direction.
- Chu (2025), DOI 10.1016/j.cscm.2025.e04589: seven inputs C, CA, FA, W/B, T (curing duration), P, CC; 80:20 random split, input z-score, training 10-fold grid search. Targets RF .9709, GBRT .9696, XGB .9594. Original final hyperparameters, grid, split/estimator/CV seeds and package versions are not located in the paper. Our finite grids below are explicitly reconstruction choices, not recovered original settings.
- Alsharedah–Wani (2026), DOI 10.1038/s41598-026-56278-y: 70:30 random split; Table 3 RF n_estimators=265, max_depth=10, min_samples_split=2, min_samples_leaf=1, max_features=.565, max_samples=.888, min_impurity_decrease=.00001. Target Table 5 R²=.9551 (abstract rounds .955). Paper describes 12 inputs including curing temperature; public table has only 11 inputs plus target. Do not invent a temperature column. Split/model seed, original software versions and exact PSO search history are not available. The Table-3 refit on public 11 inputs is a partial reconstruction, not a full PSO replay.
- Wang (2026), DOI 10.3390/buildings16010089: seven inputs, 80:20, five quantile strata for five-fold CV. Table 2 TabPFN device=cuda, num_iter=32, batch_size=64, prior_type=default. Target .959. Original raw table not recovered; lineage is probable from printed signatures, not established by numeric row identity. Version, checkpoint, usable API mapping and split/ensemble seeds unknown. No substitute TabPFN execution will be called the original pipeline. GPU/MPS/CUDA awaits root coordination; a future separately authorized CPU smoke may only establish compatibility.
- Yeh local CSV: 1030 rows, 1005 unique complete rows, 996 eight-input vectors, 428 seven-component mixtures without age. Eleven exact-duplicate groups: one size-2, six size-3, four size-4; 36 participating / 25 redundant rows / 43 unordered pairs. Seven-component mix identity is not an exact row twin. Historical mirror provenance retained; official UCI page now verifies N=1030/eight features, DOI 10.24432/C5PK67 and CC BY 4.0. Current official data bytes must be compared before calling the local mirror byte-verified against UCI.

## Fixed CPU design and budget (approved)

Use the existing read-only C1 model_experiments/.venv (NumPy 2.4.6, pandas 2.3.3, sklearn 1.6.1, XGBoost 3.2.0). Do not change this environment. At most two CPU workers, n_jobs=1 per estimator, BLAS/OpenMP=1. Wall-clock hard budget 120 minutes for the new matrix; each job and failures retained. No partial matrix may be labelled complete. Disk target <100 MB without weights. Runtime estimate is provisional, not measured.

A. Headline-oriented fixed seed-0 reconstruction: Chu 3 models × 4 arms, with six grid candidates and training-only shuffled KFold(10, random_state=0) on baseline training; full-row-group uses its own training-only selection, scorer negative MSE; ties use declared grid order. Refit selected candidate once. StandardScaler is fitted inside each fold and inside each final training arm. Candidate grids:
- RF: n_estimators=300; max_depth ∈ [None, 5, 10]; max_features ∈ [1.0, 'sqrt']; remaining sklearn defaults recorded explicitly in model.get_params.
- GBRT: n_estimators ∈ [100, 300]; max_depth ∈ [2, 3, 5]; learning_rate=.1; remaining defaults pinned by sklearn version.
- XGB: n_estimators ∈ [100, 300]; max_depth ∈ [2, 3, 5]; learning_rate=.1, objective=reg:squarederror, tree_method=hist, n_jobs=1; remaining defaults captured.
These are bounded reconstructions because original grids are unknown. Wani Table-3 RF: 4 arms, no optimization, bootstrap=True required for max_samples, squared_error criterion. Within a given seed, the baseline-training-selected hyperparameters are frozen and reused for baseline, twin purge and size-control. Each final scaler/estimator refits on the retained training rows. The deleted rows may therefore have influenced the original baseline hyperparameter choice; this is explicitly a deletion-policy contrast conditional on that selection history, not full erasure of their influence. Full-row-group independently selects on its own training rows because its test set differs. No per-deletion-arm re-selection is part of the primary matrix; such a sensitivity would need its own prospective amendment. 3×(2×6×10+4)+4 = 376 fits.

B. Separate fixed-configuration 50-split sensitivity: seeds 0–49, four arms per seed. Chu-seven-input RF300, GBRT100/depth3/lr.1, XGB100/depth3/lr.1 use predetermined configurations above, not the selected seed-0 result. Wani Table-3 RF uses public 11 inputs. Chu-family test fraction .2; Wani fraction .3. Thus no pure cross-model comparison across these different splits. 4×50×4 = 800 fits. This is explicitly a standardized sensitivity study, not an exact headline replication or the complete original tuning pipeline. No result-dependent best seed/configuration selection.

C. Yeh fixed-test twin experiment: seeds 0–49, test fraction .2, raw eight inputs; RF300 and ET300 with sklearn defaults, random_state=seed/n_jobs=1. Three arms row_random, purge_twin, size_control; 2×50×3=300 fits. Age stays an input; group definition uses all nine numeric columns. No seven-component mix purge is substituted. Row_random test is fixed for both deletion contrasts.

D. Source-held-out check on carbonation: the three existing auditable *putative/source-cluster* folds, without relabelling as independently confirmed source studies or laboratories. Preserve row map and evidence confidence; verify overlap and row indices before use. Four pre-fixed models from B × three folds =12 fits. Unknown source rows remain training-only. No 146-configuration search.

Total proposed supervised CPU fits: 1488. No TabPFN fit included in that total. No reconstruction is promised to achieve the reported headline.

## Four arms and controls

1. row_random: sklearn train_test_split(arange(N), test_size=fraction, random_state=seed), no stratification.
2. purge_twin: same test, delete *all* training rows whose complete numeric row key occurs in test.
3. size_control: same test, sample an equal number from training rows without a test twin using NumPy default_rng(seed+100000). Retain all test-twin training rows. Refuse if insufficient eligible controls.
4. full_row_group: GroupShuffleSplit with same fraction and seed on complete-row groups; test row count can differ and is reported. It is a separate deployment estimand, not a paired comparison with row_random test.

Matched purge-v-control contrasts use identical test rows, model random seed and equal training size. Differences are not proof of a biological/material causal mechanism. Exact row membership/hash, train/test exposure, selected parameters, all predictions and every failure are saved before summary.

## Outcomes and intervals

Save unrounded R², RMSE (MPa), MAE (MPa), sample counts, exact exposure and train size. For identical-test deletion comparisons save paired signed differences for every split. Main report gives arithmetic mean and the 2.5th/97.5th empirical split quantiles over 50 fixed seeds, labelled *split-distribution intervals*, not population CI or 50 independent experiments. No inferential p-values, additional bootstrap, win-probability claims or test-based model selection. Constant-target R² is null with explicit reason, not silently finite-forced; empty strata null. Keep all negative and zero differences. An optional conditional interval would require a separate prospective amendment, not improvised after outcomes.

## General exposure formula

For N rows partitioned into groups of complete-row multiplicities m_g and a uniformly sampled test set of fixed size n (1≤n<N),
E[exposed test fraction] = Σ_g (m_g/N)[1 − C(n−1,m_g−1)/C(N−1,m_g−1)].
Choose(a,b)=0 when b>a. Singleton contribution is zero. This follows by conditioning on one test row: no training twin iff every other group member is also in test. For d duplicate pairs and other singletons it reduces to (2d/N)(N−n)/(N−1). Validate against exhaustive small-N enumeration, pair reduction, all-unique and all-identical edge cases; save curves for every n for both datasets. No fitting is necessary.

## Completion and reporting gates

Freeze source/data/config/split-plan digests before fitting; root accepted this separation, fixed configuration reuse within seed, and 120-minute/2-thread budget before the matrix starts. Resume only exact frozen jobs, never overwrite results. Independent saved-prediction arithmetic checks plus source/fit-count/current-hash checks precede COMPLETE. New receipts live only under next_round_20261006/C1. The old 2200-fit/800-strata/source-delete/trainlookup results remain separately identified; no new PASS is inferred from them. Scientific source claims, bibliography relevance, official journal requirements and rendered manuscript/≤40-page SI each require their own recorded checks.

## Zero-dose and infeasible cases

A split with no baseline training twin is retained as zero-dose, with identical deletion sets and no artificial exposure inserted. If the eligible non-twin pool is smaller than the purge count, mark control INFEASIBLE and retain that split; never redraw it to seek an effect. Frozen test observations all retain unit weight. The size-control arm retains exposure but deletes different content, so the contrast is not a pure isolated twin mechanism. The uniform-split expectation above is not the fixed-observed-test/eligible-training hypergeometric expectation.
