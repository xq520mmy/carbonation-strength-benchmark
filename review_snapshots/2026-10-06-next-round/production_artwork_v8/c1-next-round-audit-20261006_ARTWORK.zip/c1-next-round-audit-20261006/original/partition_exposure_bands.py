"""Frozen random-partition predictive bands; no model fitting."""
from pathlib import Path
import json,hashlib,argparse,csv
import numpy as np
import pandas as pd
N=Path(__file__).resolve().parent;O=N/'partition_exposure';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');a.add_argument('--run',action='store_true');args=a.parse_args()
 inv=json.loads((N/'INPUT_INVENTORY.json').read_text());paths={k:Path(inv['inputs'][k]['path'])for k in ['carbonation198','yeh1030']}
 bindings={k:sha(p)for k,p in paths.items()};assert all(bindings[k]==inv['inputs'][k]['sha256']for k in paths)
 seal={'status':'FROZEN_BEFORE_RANDOM_PARTITION_OUTPUT','script_sha256':sha(Path(__file__)),'input_sha256':bindings,'seed':20261006,'draws_per_dataset':2000,'dataset_order':list(paths),'rng':'NumPy default_rng PCG64; one sequential stream','sampling':'uniform random permutation without replacement; every prefix n=1..N-1 is a test set','bands':'pointwise 2.5th and 97.5th quantiles, NumPy linear method, of actual test exposed fraction; partition distribution, not confidence interval for mean','no_model_fits':True,'no_changes_to_frozen_model_protocols':True,'check':'all permutation rows unique; incremental exposures match direct bincount on every n for first 10 permutations and ten fixed n for all remaining permutations'}
 if args.prepare:
  with (O/'PRE_EXECUTION_SEAL.json').open('x') as f:json.dump(seal,f,indent=2)
  print('SEALED');return
 assert args.run and json.loads((O/'PRE_EXECUTION_SEAL.json').read_text())==seal
 assert not (O/'PREDICTIVE_BANDS.csv').exists()
 rng=np.random.default_rng(seal['seed']);out=[];checks=0
 for k,p in paths.items():
  df=pd.read_excel(p)if p.suffix=='.xlsx'else pd.read_csv(p)
  keys=[tuple(float(v).hex()for v in row)for row in df.to_numpy(float)];unique={};labels=np.array([unique.setdefault(key,len(unique))for key in keys]);sizes=np.bincount(labels);nn=len(labels);draws=np.empty((2000,nn-1),dtype=np.float64);perms=np.empty((2000,nn),dtype=np.int16)
  for b in range(2000):
   order=rng.permutation(nn);perms[b]=order;assert np.array_equal(np.sort(order),np.arange(nn));counts=np.zeros(len(sizes),dtype=int);exposed=0
   for j,rowid in enumerate(order[:-1]):
    g=labels[rowid];old=counts[g];counts[g]+=1;exposed+=1 if counts[g]<sizes[g] else -old;draws[b,j]=exposed/(j+1)
   ns=range(1,nn)if b<10 else np.unique(np.linspace(1,nn-1,10,dtype=int))
   for n in ns:
    c=np.bincount(labels[order[:n]],minlength=len(sizes));direct=int(np.sum(c[c<sizes]));assert draws[b,n-1]==direct/n;checks+=1
  np.savez_compressed(O/(k+'_partition_draws.npz'),permutations=perms,exposed_fraction=draws)
  q=np.quantile(draws,[.025,.975],axis=0,method='linear')
  for j in range(nn-1):out.append(dict(dataset=k,N=nn,test_n=j+1,q025=q[0,j],q975=q[1,j],draw_mean=float(draws[:,j].mean())))
 with (O/'PREDICTIVE_BANDS.csv').open('x',newline='')as f:w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
 qa={'status':'PASS_PARTITION_DISTRIBUTION_NOT_MODEL_UNCERTAINTY','seal_sha256':sha(O/'PRE_EXECUTION_SEAL.json'),'direct_count_checks':checks,'draws':4000,'curve_rows':len(out),'outputs':{p.name:sha(p)for p in O.iterdir()if p.suffix in ['.csv','.npz']},'errors':[]}
 (O/'PARTITION_QA.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa))
if __name__=='__main__':main()
