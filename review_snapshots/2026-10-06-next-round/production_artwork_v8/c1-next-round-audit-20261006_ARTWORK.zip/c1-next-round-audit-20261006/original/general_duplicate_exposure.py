#!/usr/bin/env python3
"""Exact uniform fixed-test-size exposure expectation; no estimators or randomness."""
import csv, hashlib, itertools, json, math
from collections import Counter
from pathlib import Path

def expectation(sizes,n):
    N=sum(sizes)
    if not sizes or any(type(m) is not int or m<1 for m in sizes) or not 1<=n<N:
        raise ValueError('positive group sizes and 1<=test_n<N required')
    return math.fsum(m/N*(1-(math.comb(n-1,m-1)/math.comb(N-1,m-1) if m<=n else 0)) for m in sizes)

def exhaustive(sizes,n):
    labels=[g for g,m in enumerate(sizes) for _ in range(m)]
    vals=[]
    for test in itertools.combinations(range(len(labels)),n):
        t=set(test); train={labels[i] for i in range(len(labels)) if i not in t}
        vals.append(sum(labels[i] in train for i in test)/n)
    return math.fsum(vals)/len(vals)

def main():
    import pandas as pd
    here=Path(__file__).resolve().parent
    inv=json.loads((here/'INPUT_INVENTORY.json').read_text())
    checks=[]
    for sizes in ([1,1,1,1],[2,1,1],[3,2,1],[4,1,1],[2,2,2],[6]):
        for n in range(1,sum(sizes)):
            a=expectation(sizes,n);b=exhaustive(sizes,n)
            assert abs(a-b)<1e-14
            checks.append({'sizes':sizes,'n':n,'formula':a,'enumerated':b})
    for N in range(3,14):
        for d in range(N//2+1):
            for n in range(1,N):
                assert abs(expectation([2]*d+[1]*(N-2*d),n)-(2*d/N)*(N-n)/(N-1))<1e-14
    rows=[]; sources={}
    for key in ['carbonation198','yeh1030']:
        p=Path(inv['inputs'][key]['path']);digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest==inv['inputs'][key]['sha256']
        df=pd.read_excel(p) if p.suffix=='.xlsx' else pd.read_csv(p)
        sizes=list(Counter(tuple(float(x).hex() for x in row) for row in df.to_numpy(float)).values())
        sources[key]={'sha256':digest,'group_size_counts':dict(Counter(sizes))}
        for n in range(1,len(df)):
            rows.append({'dataset':key,'N':len(df),'test_n':n,'train_n':len(df)-n,'expected_exposed_test_fraction':expectation(sizes,n)})
    out=here/'duplicate_exposure';out.mkdir(exist_ok=True)
    with (out/'uniform_random_split_curves.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    qa={'status':'PASS_EXACT_ENUMERATION_AND_PAIR_REDUCTION','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_bindings':sources,'enumeration_checks':checks,'curve_rows':len(rows),'scope':'Uniform without-replacement split with fixed test size; NOT stratified/group-disjoint/fixed observed test with constrained eligible train pool. No model fits.'}
    (out/'FORMULA_QA.json').write_text(json.dumps(qa,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':qa['status'],'curve_rows':len(rows),'enumeration_checks':len(checks)}))
if __name__=='__main__':main()
