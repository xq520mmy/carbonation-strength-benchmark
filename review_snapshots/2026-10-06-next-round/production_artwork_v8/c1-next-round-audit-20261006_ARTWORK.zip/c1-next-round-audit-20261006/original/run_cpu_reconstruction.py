#!/usr/bin/env python3
"""New prospective CPU matrix. Never imports old experiment functions or writes outside HERE."""
import os
for _k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_k]='1'
import argparse, datetime, hashlib, itertools, json, math, multiprocessing as mp, sys, time
from pathlib import Path
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
    tmp=Path(str(p)+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def load(p):return json.loads(Path(p).read_text())

def data():
    import numpy as np,pandas as pd
    inv=load(HERE/'INPUT_INVENTORY.json');out={}
    for key in ('carbonation198','yeh1030'):
        rec=inv['inputs'][key];p=Path(rec['path']);assert sha(p)==rec['sha256']
        df=pd.read_excel(p) if p.suffix=='.xlsx' else pd.read_csv(p)
        a=df.to_numpy(float);assert np.isfinite(a).all()
        groups=np.array([hashlib.sha256('|'.join(float(x).hex() for x in row).encode()).hexdigest() for row in a])
        out[key]=(df,a[:,-1],groups)
    return out

def partitions(N,groups,seed,frac):
    import numpy as np
    from sklearn.model_selection import train_test_split,GroupShuffleSplit
    tr,te=train_test_split(np.arange(N),test_size=frac,random_state=seed)
    twin=tr[np.isin(groups[tr],groups[te])];eligible=tr[~np.isin(groups[tr],groups[te])]
    arms={'row_random':(tr,te),'purge_twin':(tr[~np.isin(tr,twin)],te)}
    if len(eligible)<len(twin):arms['size_control']=None
    else:
        remove=np.random.default_rng(seed+100000).choice(eligible,len(twin),replace=False)
        arms['size_control']=(tr[~np.isin(tr,remove)],te)
    gtr,gte=next(GroupShuffleSplit(n_splits=1,test_size=frac,random_state=seed).split(np.arange(N),groups=groups))
    arms['full_row_group']=(gtr,gte)
    return arms

CONFIGS={
 'RF300':{'n_estimators':300,'max_depth':None,'max_features':1.0,'n_jobs':1},
 'ET300':{'n_estimators':300,'max_depth':None,'max_features':1.0,'n_jobs':1},
 'GBRT100':{'n_estimators':100,'max_depth':3,'learning_rate':.1},
 'XGB100':{'n_estimators':100,'max_depth':3,'learning_rate':.1,'objective':'reg:squarederror','tree_method':'hist','n_jobs':1},
 'WANI_RF265':{'n_estimators':265,'max_depth':10,'min_samples_split':2,'min_samples_leaf':1,'max_features':.565,'max_samples':.888,'min_impurity_decrease':.00001,'bootstrap':True,'criterion':'squared_error','n_jobs':1}}
GRIDS={
 'RF300':{'model__max_depth':[None,5,10],'model__max_features':[1.0,'sqrt']},
 'GBRT100':{'model__n_estimators':[100,300],'model__max_depth':[2,3,5]},
 'XGB100':{'model__n_estimators':[100,300],'model__max_depth':[2,3,5]}}

def estimator(name,seed):
    from sklearn.ensemble import RandomForestRegressor,ExtraTreesRegressor,GradientBoostingRegressor
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from xgboost import XGBRegressor
    cls={'RF300':RandomForestRegressor,'ET300':ExtraTreesRegressor,'GBRT100':GradientBoostingRegressor,'XGB100':XGBRegressor,'WANI_RF265':RandomForestRegressor}[name]
    return Pipeline([('scale',StandardScaler()),('model',cls(random_state=seed,**CONFIGS[name]))])

def source_folds():
    inv=load(HERE/'INPUT_INVENTORY.json');p=Path(inv['inputs']['row_provenance']['path']);assert sha(p)==inv['inputs']['row_provenance']['sha256'];rows=load(p)['rows'];assert len(rows)==198
    def rowset(name):return {i for i,r in enumerate(rows) if r.get('study_cluster')==name}
    extra={34,39,40,41,64,65,87}|set(range(188,199))|set(range(1,17))|set(range(28,34))
    blocks={'TAIWAN_LEE_WANG':rowset('TAIWAN_LEE_WANG'),'SHAO_DOE_BLOCK':rowset('SHAO_DOE_BLOCK'),'MCGILL_LAB_PUTATIVE':rowset('MCGILL_LWCMU')|rowset('MCGILL_LIU_WETMIX')|{i-1 for i in extra}}
    assert {k:len(v) for k,v in blocks.items()}=={'TAIWAN_LEE_WANG':45,'SHAO_DOE_BLOCK':22,'MCGILL_LAB_PUTATIVE':76}
    for a,b in itertools.combinations(blocks.values(),2):assert not a&b
    return {k:sorted(v) for k,v in blocks.items()}

def make_plan():
    from importlib.metadata import version
    d=data();jobs=[]
    def add(stage,dataset,name,seed,frac,arms,selection='none',fold=None):
        df,y,g=d[dataset]
        ps=partitions(len(y),g,seed,frac) if fold is None else {'source_heldout':([i for i in range(len(y)) if i not in source_folds()[fold]],source_folds()[fold])}
        rr=ps.get('row_random');selected={}
        for arm in arms:
            if ps[arm] is None:selected[arm]={'status':'INFEASIBLE_NON_TWIN_POOL'};continue
            tr,te=ps[arm]
            selected[arm]={'train':[int(i) for i in tr],'test':[int(i) for i in te],'exposed_test_rows':int(sum(x in set(g[tr]) for x in g[te]))}
            assert not set(tr)&set(te)
            if arm in ('purge_twin','full_row_group'):assert selected[arm]['exposed_test_rows']==0
        jobs.append({'job_id':f'{stage}__{dataset}__{name}__seed{seed:02d}'+('___'+fold if fold else '')+('__group' if arms==['full_row_group'] else ''),'stage':stage,'dataset':dataset,'model':name,'seed':seed,'test_fraction':frac,'selection':selection,'arms':selected,'zero_dose':bool(rr is not None and not any(x in set(g[rr[1]]) for x in g[rr[0]]))})
    for name in GRIDS:
        add('headline_reconstruction','carbonation198',name,0,.2,['row_random','purge_twin','size_control'],'base_training_10fold_reuse_selected')
        add('headline_reconstruction','carbonation198',name,0,.2,['full_row_group'],'own_training_10fold')
    add('headline_reconstruction','carbonation198','WANI_RF265',0,.3,['row_random','purge_twin','size_control','full_row_group'])
    for seed in range(50):
        for name in ('RF300','GBRT100','XGB100','WANI_RF265'):
            add('fixed_config_split_audit','carbonation198',name,seed,.3 if name=='WANI_RF265' else .2,['row_random','purge_twin','size_control','full_row_group'])
        for name in ('RF300','ET300'):
            add('yeh_matched_deletion','yeh1030',name,seed,.2,['row_random','purge_twin','size_control'])
    for fold in source_folds():
        for name in ('RF300','GBRT100','XGB100','WANI_RF265'):add('putative_source_heldout','carbonation198',name,0,None,['source_heldout'],fold=fold)
    return {'schema_version':1,'jobs':jobs,'job_count':len(jobs),'final_predictions_cells':sum(len(j['arms']) for j in jobs),'cv_fits':360,'total_planned_fits':sum(len(j['arms']) for j in jobs)+360,'configs':CONFIGS,'grids':GRIDS,'versions':{k:version(k) for k in ('numpy','pandas','scikit-learn','xgboost')},'resource_budget':{'max_workers':2,'threads_per_worker':1,'wall_seconds':7200},'source_folds':source_folds(),'interpretation':'Deletion-policy contrast conditional on one fixed test and the baseline-training-selected hyperparameters. Not complete erasure of selection history, physical specimen identification, or population CI.'}

DATA=None
def init_worker():
    global DATA;DATA=data()

def worker(job):
    import numpy as np
    from sklearn.base import clone
    from sklearn.model_selection import GridSearchCV,KFold
    from threadpoolctl import threadpool_limits
    t=time.monotonic();df,y,groups=DATA[job['dataset']]
    cols=list(df.columns[:-1]) if job['dataset']=='yeh1030' or job['model']=='WANI_RF265' else ['C','CA','FA','W/B','T','P','CC']
    X=df[cols].to_numpy(float);base=estimator(job['model'],job['seed']);selection=None
    with threadpool_limits(limits=1):
        if job['selection']!='none':
            a=job['arms']['row_random'] if 'row_random' in job['arms'] else job['arms']['full_row_group'];tr=a['train']
            cv=GridSearchCV(base,GRIDS[job['model']],scoring='neg_mean_squared_error',cv=KFold(10,shuffle=True,random_state=job['seed']),n_jobs=1,refit=False,error_score='raise')
            cv.fit(X[tr],y[tr]);base.set_params(**cv.best_params_)
            selection={'selected_params':cv.best_params_,'selection_train_rows':tr,'candidate_results':[{'params':p,'mean_cv_negative_mse':float(s),'rank':int(r)} for p,s,r in zip(cv.cv_results_['params'],cv.cv_results_['mean_test_score'],cv.cv_results_['rank_test_score'])],'fit_count':60}
        results={};fits=60 if selection else 0
        for arm,p in job['arms'].items():
            if p.get('status'):results[arm]=p;continue
            tr,te=p['train'],p['test'];m=clone(base);m.fit(X[tr],y[tr]);pred=np.asarray(m.predict(X[te]),float);assert np.isfinite(pred).all();fits+=1
            truth=y[te];sse=float(np.sum((pred-truth)**2));sst=float(np.sum((truth-truth.mean())**2))
            results[arm]={'train_rows':tr,'test_rows':te,'y_true':truth.tolist(),'y_pred':pred.tolist(),'metrics':{'r2':None if sst==0 else 1-sse/sst,'rmse':float(np.sqrt(sse/len(te))),'mae':float(np.mean(np.abs(pred-truth)))},'r2_null_reason':'constant_target' if sst==0 else None,'model_params':{k:({'special_float':'NaN missing-value sentinel, not outcome'} if isinstance(v,float) and math.isnan(v) else v) for k,v in m.named_steps['model'].get_params().items() if v is not None},'exposed_test_rows':p['exposed_test_rows']}
    return {'status':'COMPLETE','job':job,'selection':selection,'features':cols,'arms':results,'actual_fits':fits,'elapsed_seconds':time.monotonic()-t}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--freeze',action='store_true');ap.add_argument('--run',action='store_true');args=ap.parse_args();assert args.freeze!=args.run
    if args.freeze:
        assert not (HERE/'FROZEN_CPU_PLAN.json').exists();p=make_plan();dump(HERE/'FROZEN_CPU_PLAN.json',p)
        seal={'status':'FROZEN_BEFORE_NEW_FITS','files':{x:sha(HERE/x) for x in ('run_cpu_reconstruction.py','PROTOCOL_FROZEN_v1.md','INPUT_INVENTORY.json','FROZEN_CPU_PLAN.json')},'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorization':'Parent root protocol messages 2026-10-06: 2 CPU threads/2 hours, fixed-seed reconstruction and 50-seed fixed-config audit approved; no TabPFN/GPU.'};dump(HERE/'PRE_EXECUTION_SEAL.json',seal);print(json.dumps({k:p[k] for k in ('job_count','final_predictions_cells','cv_fits','total_planned_fits')}));return
    seal=load(HERE/'PRE_EXECUTION_SEAL.json')
    for k,v in seal['files'].items():assert sha(HERE/k)==v,(k,'seal mismatch')
    plan=load(HERE/'FROZEN_CPU_PLAN.json');out=HERE/'cpu_results';out.mkdir(exist_ok=False);(out/'jobs').mkdir();t=time.monotonic();deadline=t+plan['resource_budget']['wall_seconds'];pool=mp.get_context('spawn').Pool(2,initializer=init_worker);pending=[(j,pool.apply_async(worker,(j,))) for j in plan['jobs']];errors=[];done=[]
    dump(out/'ACTION_STATUS.json',{'status':'RUNNING','seal_sha256':sha(HERE/'PRE_EXECUTION_SEAL.json'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    try:
        for job,f in pending:
            r=f.get(timeout=max(.001,deadline-time.monotonic()));assert time.monotonic()<=deadline,'deadline exceeded after result'
            p=out/'jobs'/(job['job_id']+'.json');dump(p,r);done.append({'path':str(p.relative_to(out)),'sha256':sha(p),'actual_fits':r['actual_fits']});print(json.dumps({'job':job['job_id'],'completed_jobs':len(done),'total_jobs':len(pending),'seconds':round(time.monotonic()-t,2)}),flush=True)
        pool.close();pool.join();assert time.monotonic()<=deadline,'deadline exceeded after worker shutdown'
        dump(out/'ALL_COMPLETED.json',{'status':'COMPLETE','jobs':done,'actual_fits':sum(x['actual_fits'] for x in done),'planned_fits':plan['total_planned_fits'],'seal_sha256':sha(HERE/'PRE_EXECUTION_SEAL.json'),'elapsed_seconds':time.monotonic()-t})
        assert time.monotonic()<=deadline,'deadline exceeded after completion seal'
        dump(out/'ACTION_STATUS.json',{'status':'COMPLETE','all_completed_sha256':sha(out/'ALL_COMPLETED.json'),'elapsed_seconds':time.monotonic()-t,'errors':[]})
    except BaseException as e:
        pool.terminate();pool.join();errors.append({'type':type(e).__name__,'message':str(e)})
        dump(out/'ACTION_STATUS.json',{'status':'FAILED_OR_PARTIAL','completed_jobs':len(done),'elapsed_seconds':time.monotonic()-t,'errors':errors});raise
if __name__=='__main__':main()
