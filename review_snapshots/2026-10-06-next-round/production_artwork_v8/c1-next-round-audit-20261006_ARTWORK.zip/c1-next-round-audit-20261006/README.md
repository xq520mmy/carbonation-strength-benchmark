# Carbonation / Yeh next-round numerical audit

This is a **new staging archive**, not a Zenodo publication or archival DOI. It adds the 6 October 2026 experiments to the unchanged earlier public versions. The main manuscript and supplement are separate submission files.

The archive includes every original 319 job, all 1,151 final saved-prediction cells, every 50-seed matched-deletion contrast, all 1,226 exact exposure expectations, and the saved predictive partition bands. Original source and numerical records are byte identical; ORIGINAL_AND_DELIVERED_FILE_HASHES.json maps both hashes. DATA_ACCESS_AND_HASHES.json is a separately identified portable metadata projection of the private input inventory, rather than the original inventory bytes. No original pre-execution seal has been rewritten. Original seals can refer to source inputs intentionally absent here; use the public payload manifest and portable verifier for this subset.

## Saved-result reproduction

Use Python 3.11 or later; only the standard library is required:

    python tools/verify_saved_revision.py --output /tmp/c1-replay-receipt.json
    python tools/exposure_cli.py --sizes 4 3 2 1 --test-n 3

The verifier checks archive member hashes, all saved metrics, row membership, repeated targets, matched model configurations, all paired split summaries and all expectation-curve rows. It does not fit a model or download data. It does not reconstruct physical specimen identities, or independently check raw-data duplicate equality without the separate source tables. The archived NPZ partition evidence is retained unchanged; its original direct-count QA is separate from the standard-library numerical replay.

## Optional original-matrix refitting

The original dependency versions are frozen in requirements-refit.txt. With lawful copies of both data files matching their exact archived hashes:

    python tools/refit_original319.py --carbonation /path/to/scirep_MOESM1.xlsx --yeh /path/to/uci_concrete.csv --output /path/to/new-refit-output

This wrapper calls the unchanged original worker on the frozen plan. It writes a new output directory and never overwrites saved results. It refits the original 319 jobs / 1,488 tree fits only. Later source-driven GUI and source-test extensions and the seven CPU TabPFN contexts are **saved-result-only** in this portable wrapper; they are not silently substituted into the original matrix. Total revision accounting is 900 cross-validation tree fits + 1,144 final tree fits = 2,044 tree fits; seven final TabPFN contexts are separate, as is one discarded training-only smoke context.

## Interpretation and permissions

The exact formula assumes a uniform fixed-size random split without replacement. It is not a formula for group-disjoint or constrained stratified splitting. The 50-seed intervals describe partition variation, not population confidence intervals. The source blocks are putative groups, not proven independent laboratories. Reaching R² >= 0.95 remains possible after full-row grouping. The source-guided RF and CPU TabPFN approximation miss their prespecified headline agreement criterion; reverse deletion effects and Yeh intervals crossing zero are retained. The source-test extension is explicitly post-outcome sensitivity.

No publisher full texts, article extracts, unlicensed third-party GUI source/notebook, private provenance, correspondence, identity records, model weights, environment, credentials or adapters are included. Original author code has no new blanket license assigned by this staging operation. Authors must select and approve an applicable code license before claiming licensed public reuse or completing a Zenodo record. Third-party data and TabPFN software/model terms are independent of the author-code license; the supplied TabPFN license is a notice, not a grant over this entire package.
