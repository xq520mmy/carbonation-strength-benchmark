#!/usr/bin/env python3
"""Reproduce C1's descriptive lookup and leakage-free random-fold comparator.

Supply the original supplementary scirep_MOESM1.xlsx workbook from
https://doi.org/10.1038/s41598-026-56278-y. The workbook is not redistributed.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold


EXPECTED_SHA256 = "f9e9e195e680d39ea89ebcaf9c50dbf90118c47dc63afcb675f22f7feb9b406b"
FEATURES = [
    "C", "CA", "FA", "W", "blast furnace slag", "fly ash", "W/B",
    "CCU-steam curing time", "T", "CC", "P",
]


def scores(y: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    return {
        "r2": float(r2_score(y, prediction)),
        "rmse": float(np.sqrt(mean_squared_error(y, prediction))),
        "mae": float(mean_absolute_error(y, prediction)),
    }


def reproduce(workbook: Path) -> dict:
    digest = sha256(workbook.read_bytes()).hexdigest()
    if digest != EXPECTED_SHA256:
        raise ValueError(f"Workbook SHA-256 mismatch: {digest}; expected {EXPECTED_SHA256}")
    frame = pd.read_excel(workbook)
    if frame.shape != (198, 12) or list(frame.columns) != FEATURES + ["CS"]:
        raise ValueError(f"Unexpected workbook schema: {frame.shape}; {list(frame.columns)}")
    y = frame["CS"].to_numpy(dtype=float)
    keys = np.asarray([
        "|".join(f"{float(value):.6g}" for value in row)
        for row in frame[FEATURES].to_numpy()
    ], dtype=object)

    # This full-table group mean includes each focal target. It is descriptive.
    all_groups: dict[str, list[int]] = defaultdict(list)
    for index, key in enumerate(keys):
        all_groups[str(key)].append(index)
    oracle = np.empty_like(y)
    for indices in all_groups.values():
        oracle[indices] = y[indices].mean()

    by_seed = []
    seen_total = 0
    for seed in range(10):
        prediction = np.full(len(y), np.nan)
        seen = 0
        for training, test in KFold(n_splits=5, shuffle=True, random_state=seed).split(y):
            training_groups: dict[str, list[float]] = defaultdict(list)
            for index in training:
                training_groups[str(keys[index])].append(float(y[index]))
            lookup = {key: float(np.mean(values)) for key, values in training_groups.items()}
            fallback = float(np.mean(y[training]))
            for index in test:
                key = str(keys[index])
                if key in lookup:
                    prediction[index] = lookup[key]
                    seen += 1
                else:
                    prediction[index] = fallback
        if not np.isfinite(prediction).all():
            raise AssertionError("Each row must have an out-of-fold prediction")
        by_seed.append({"seed": seed, **scores(y, prediction), "seen_exact_key": seen})
        seen_total += seen

    summary = {}
    for metric in ("r2", "rmse", "mae"):
        values = np.asarray([item[metric] for item in by_seed], dtype=float)
        summary[metric] = {"mean": float(values.mean()), "sd": float(values.std(ddof=1))}
    return {
        "source_sha256": digest,
        "rows": len(y),
        "exact_vector_groups": len(all_groups),
        "singleton_groups": sum(len(members) == 1 for members in all_groups.values()),
        "full_data_group_mean_descriptive_only": scores(y, oracle),
        "train_only_random_five_fold_by_seed": by_seed,
        "train_only_random_five_fold_summary": summary,
        "exact_vector_seen_in_training": seen_total,
        "total_seed_test_rows": len(y) * 10,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workbook", type=Path, help="Original publisher supplementary XLSX")
    args = parser.parse_args()
    print(json.dumps(reproduce(args.workbook), indent=2))


if __name__ == "__main__":
    main()
