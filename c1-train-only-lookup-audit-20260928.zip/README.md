# C1 exact-vector lookup audit

The old R² = 0.9914 exact-vector group mean used every row's own target. It is
an **in-sample descriptive statistic**, not a predictive baseline. The revised
manuscript reports a fold-trained exact-vector lookup under the same ten
five-fold random splits as its model comparison. This baseline gives R² =
0.733 ± 0.025, RMSE = 9.70 ± 0.45 MPa, MAE = 4.84 ± 0.24 MPa. Exact-vector
matches account for 1,544 of 1,980 out-of-fold predictions; these metrics do
not estimate performance on a new mixture or independent material batch.

Obtain the original `scirep_MOESM1.xlsx` supplementary workbook from
[Alsharedah and Wani (2026)](https://doi.org/10.1038/s41598-026-56278-y).
It is omitted from this attachment. Its expected SHA-256 is
`f9e9e195e680d39ea89ebcaf9c50dbf90118c47dc63afcb675f22f7feb9b406b`.

With Python, NumPy, pandas, scikit-learn and an XLSX reader installed, run:

```bash
python3 audit_train_only_lookup.py /path/to/scirep_MOESM1.xlsx
```

The script checks the exact workbook hash and schema, prints all ten seed
metrics and the mean/sample SD, and writes no data. `expected_metrics.json`
contains aggregate reference values only. No source rows, individual targets,
or predictions are bundled here.
