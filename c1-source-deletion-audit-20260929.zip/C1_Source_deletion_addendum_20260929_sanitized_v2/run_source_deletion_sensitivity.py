#!/usr/bin/env python3
"""Standard-library reproduction of the restricted lab-group sensitivity."""
import csv, json, math
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev

HERE=Path(__file__).resolve().parent
rows=list(csv.DictReader((HERE/'inputs/primary_cohort_anonymized.csv').open(newline='',encoding='utf-8')))
preds=defaultdict(dict)
for row in csv.DictReader((HERE/'inputs/fixed_et_seed_predictions_anonymized.csv').open(newline='',encoding='utf-8')):
    preds[int(row['seed'])][row['record_id']]=float(row['prediction_mpa'])
baseline=json.loads((HERE/'inputs/fixed_training_mean_baseline.json').read_text())['constant_mpa']
by_id={r['record_id']:r for r in rows}
if sorted(preds)!=list(range(10)) or any(set(p)!=set(by_id) for p in preds.values()): raise RuntimeError('saved prediction coverage mismatch')
def one(ids, prediction):
    y=[float(by_id[i]['strength_mpa']) for i in ids]; p=[prediction[i] for i in ids]; mu=mean(y); ss=sum((x-mu)**2 for x in y); e=[a-b for a,b in zip(p,y)]
    return {'r2':1-sum(x*x for x in e)/ss,'rmse_mpa':math.sqrt(sum(x*x for x in e)/len(y)),'mae_mpa':mean(abs(x) for x in e),'bias_mpa':mean(e)}
def summarize(ids):
    per=[{'seed':s,**one(ids,preds[s])} for s in sorted(preds)]
    return {'n_seeds':len(per),'metrics':{k:{'mean':mean(x[k] for x in per),'seed_sd':stdev(x[k] for x in per)} for k in ('r2','rmse_mpa','mae_mpa','bias_mpa')},'per_seed':per}
def fixed(ids): return one(ids,{i:baseline for i in ids})
groups=sorted({r['group_key'] for r in rows}); all_ids=sorted(by_id)
out=[]
for group in [None,*groups]:
    ids=[i for i in all_ids if group is None or by_id[i]['group_key']!=group]
    out.append({'cohort':'full_primary' if group is None else 'primary_minus_one_lab_group','omitted_group_key':group,'n_records':len(ids),'n_age_28d':sum(float(by_id[i]['measurement_age_days'])==28 for i in ids),'extra_trees':summarize(ids),'training_mean_baseline':{'constant_mpa':baseline,'metrics':fixed(ids)}})
(HERE/'source_deletion_sensitivity.json').write_text(json.dumps({'design':'restricted leave-one-anonymous-lab-group-out reporting sensitivity; saved predictions only','cohorts':out},indent=2)+'\n')
with (HERE/'source_deletion_sensitivity.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['cohort','omitted_group_key','n_records','n_age_28d','extra_trees_rmse_mean_mpa','extra_trees_r2_mean','training_mean_rmse_mpa','training_mean_r2'])
    for x in out:w.writerow([x['cohort'],x['omitted_group_key'] or '',x['n_records'],x['n_age_28d'],x['extra_trees']['metrics']['rmse_mpa']['mean'],x['extra_trees']['metrics']['r2']['mean'],x['training_mean_baseline']['metrics']['rmse_mpa'],x['training_mean_baseline']['metrics']['r2']])
print(json.dumps({'passed':True,'records':len(rows),'groups':len(groups),'outputs':['source_deletion_sensitivity.json','source_deletion_sensitivity.csv']}))
