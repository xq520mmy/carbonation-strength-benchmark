# Anonymization provenance

The package retains only the numerical fields required for the fixed saved-prediction calculation. Anonymous `R` record keys and `G` author-merged laboratory-group keys are generated inside the restricted build step; no mapping is included. Excluded material includes raw source text, quotations, locators, publication and study identifiers, mixture descriptions, laboratory labels, pressure notes, and all non-primary records.

`inputs/INPUT_MANIFEST.json` contains hashes of the restricted numerical inputs only.
