# Restricted C1 lab-group-deletion addendum v2

This package reproduces a descriptive saved-prediction sensitivity for the corrected 41-record primary cohort. Its inputs contain only anonymized record and group keys plus numerical strength, age, seed, prediction, and fixed-baseline values. It contains no source text, quotations, locators, publication, study, mixture, or laboratory identifiers.

Run with Python 3.9+ and only the standard library:

```sh
python3 run_source_deletion_sensitivity.py
```

The runner writes full-cohort and one anonymous lab-group-deletion result. It does not fit, tune, calibrate, select, or rank models. Seed variation is not independent-experiment uncertainty.
