#!/usr/bin/env python3
"""Post-hoc, descriptive C1 external-cohort schema-alignment sensitivity.

The input-semantic flag was already present in the extracted-data inventory. This
script joins frozen pressure cohorts and frozen seed predictions; it fits nothing,
does not choose a model, and does not impute missing chemistry. Its subset results
must not be described as prospective or independently selected validation.
"""

from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, stdev


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
EXTRACT = PROJECT / "C1_crossdb_audit/external_validation/extracted_data.csv"
PRESSURE = HERE / "pressure_audit_rows.csv"
PREDICTIONS = HERE / "rerun_seed_predictions.csv"
OUTPUT = HERE / "schema_alignment_sensitivity.json"
MODEL_KEY = "ET300 raw rescaled (recommended)"  # frozen historical CSV identifier
MODEL_DISPLAY = "development-selected fixed ExtraTrees, raw inputs rescaled"
TRAIN_MEAN_MPA = 32.22887513  # 198-row table; already printed in the supplement


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def stable_numbers(value):
    """Serialize descriptive values to precision stable across Python builds."""
    if isinstance(value, float):
        return round(value, 10)
    if isinstance(value, dict):
        return {key: stable_numbers(item) for key, item in value.items()}
    if isinstance(value, list):
        return [stable_numbers(item) for item in value]
    return value


def summarize(ids: list[str], extracted: dict[str, dict[str, str]],
              by_seed: dict[int, dict[str, float]]) -> dict:
    y = [float(extracted[rec_id]["CS_MPa"]) for rec_id in ids]
    assert len(y) >= 2
    cohort_mean = mean(y)
    denominator = sum((value - cohort_mean) ** 2 for value in y)
    assert denominator > 0
    per_seed = []
    for seed, preds in sorted(by_seed.items()):
        assert all(rec_id in preds for rec_id in ids), (seed, len(ids))
        errors = [preds[rec_id] - target for rec_id, target in zip(ids, y)]
        ss = sum(error * error for error in errors)
        per_seed.append({
            "seed": seed,
            "rmse_mpa": math.sqrt(ss / len(ids)),
            "mae_mpa": mean(abs(error) for error in errors),
            "r2": 1 - ss / denominator,
        })

    def summary(key: str) -> dict[str, float]:
        vals = [entry[key] for entry in per_seed]
        return {"mean": mean(vals), "seed_sd": stdev(vals)}

    return {
        "n": len(ids),
        "source_counts": dict(sorted(Counter(extracted[i]["doi"] for i in ids).items())),
        "age_28d_n": sum(float(extracted[i]["cs_age_d"]) == 28 for i in ids),
        "target_mean_mpa": cohort_mean,
        "target_sd_mpa": math.sqrt(denominator / len(ids)),
        "model_rmse_mpa": summary("rmse_mpa"),
        "model_mae_mpa": summary("mae_mpa"),
        "model_r2": summary("r2"),
        "training_mean_rmse_mpa": math.sqrt(
            mean((target - TRAIN_MEAN_MPA) ** 2 for target in y)
        ),
        "per_seed": per_seed,
    }


def main() -> None:
    pressure = {r["rec_id"]: r for r in read_rows(PRESSURE)}
    extracted = {r["rec_id"]: r for r in read_rows(EXTRACT)}
    predictions: dict[int, dict[str, float]] = defaultdict(dict)
    for row in read_rows(PREDICTIONS):
        if row["configuration"] == MODEL_KEY:
            seed = int(row["seed"])
            rec_id = row["rec_id"]
            assert rec_id not in predictions[seed]
            predictions[seed][rec_id] = float(row["prediction_mpa"])
    assert sorted(predictions) == list(range(10))

    primary = sorted(i for i, r in pressure.items()
                     if r["cohort_primary_explicit_pressure"] == "True")
    aligned = sorted(i for i in primary
                     if extracted[i]["slag_semantics_ok"] == "True")
    mismatched = sorted(i for i in primary
                        if extracted[i]["slag_semantics_ok"] == "False")
    aligned_28d = sorted(i for i in aligned
                         if float(extracted[i]["cs_age_d"]) == 28)
    assert (len(primary), len(aligned), len(mismatched), len(aligned_28d)) == (39, 17, 22, 5)
    assert set(primary) == set(aligned) | set(mismatched)

    result = {
        "design": "post-hoc descriptive schema-alignment sensitivity; no refitting or model selection",
        "model": MODEL_DISPLAY,
        "prediction_configuration_key": MODEL_KEY,
        "cohort_rule": "frozen primary explicit-pressure records; split by pre-existing slag_semantics_ok",
        "caveat": "Aligned records still span ages and include two source publications. No independence, chemical extrapolation, or 28-day performance claim follows.",
        "primary_39": summarize(primary, extracted, predictions),
        "schema_aligned_17": summarize(aligned, extracted, predictions),
        "schema_mismatched_22": summarize(mismatched, extracted, predictions),
        "schema_aligned_28d_5": summarize(aligned_28d, extracted, predictions),
    }
    result = stable_numbers(result)
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for key in ("primary_39", "schema_aligned_17", "schema_mismatched_22", "schema_aligned_28d_5"):
        s = result[key]
        print(key, "n", s["n"], "RMSE", round(s["model_rmse_mpa"]["mean"], 3),
              "R2", round(s["model_r2"]["mean"], 3))


if __name__ == "__main__":
    main()
