# C1 bounded lineage and exact twin audit

This portable staging bundle contains the completed 2026-10-05 C1 lineage and exact-twin analyses: original frozen source code, split indices, 2,200 saved prediction groups, seed-level metrics, 800 fixed-Test stratum records, 33 duplicate pairs, publication registry, and original figures. It is an additive research artifact, not a new public release yet. It neither replaces nor modifies earlier releases. No models, environments, third-party workbooks, publisher PDFs/HTML, long source quotations, private conversations or contact records are included.

## Scientific scope

All 50 prespecified seeds (0–49), both Test fractions (0.20 and 0.30), both 300-tree learners (RF and ExtraTrees), and all declared feature/split cells are retained, including adverse and reverse effects. The main matrix contains 2,000 fits already completed historically; the separately frozen true seven-input sensitivity contributes 200. This package's verification performs **no model fitting**.

The 198-row table contains 165 unique full rows and 33 size-two duplicate groups: 66 participating rows and 33 redundant rows. Full-row identity includes all eleven stored inputs and strength. Identical reported measurements do not prove identical physical specimens. The official Chu table and the Mendeley deposit have different source-file bytes but identical 2,376 numeric cells after the documented header mapping and serial-column removal.

High R² values remain possible outside row-random splits. In stored11 full-row groups at nominal 20% Test, RF has 26/50 and ExtraTrees 29/50 splits with R² ≥ 0.95. The original Chu7 `input_vector_group` arm groups by eleven stored inputs, not the model's seven inputs; the separate amendment supplies actual seven-input grouping. Its high-score splits are also retained. Grouped Test cohorts and achieved row counts differ, so their whole score gaps cannot be attributed to duplicates.

The fixed-Test intervention removes all training twins of the original Test and compares that removal with an equal-size removal of non-twins. Strata are defined from the original Train/Test membership and remain fixed across arms. This identifies sensitivity to known twins under these learners, not new-campaign performance or all sources of leakage. The 800 stratum rows were produced from saved predictions after the overall results were available to complete prespecified reporting. Repeated-split SDs and percentiles are descriptive split variability, not independent-population confidence intervals.

The literature frame is bounded, not a demonstrated census. The broad eight-compilation frame yields **6–7 distinct complete compilations**; a curing-only frame holding out the broader Xu process scope yields 5–6. Neither is a count K of independent physical experiments or mutually row-disjoint datasets. The own-experiment papers and unresolved entries are retained. The earlier 143-row partially traced source-held-out cohort and 41-row mixed-age external stress test are separate historical analyses, not new validation supplied by this bundle. There is no new native or target-matched 28-day physical validation.

## Fast verification without third-party workbooks

Keep the folder named `pub_portfolio_20260916`; unchanged historical runners resolve that ancestor. From this release root, in an already suitable Python environment:

```sh
python tools/verify_saved_results.py
```

This read-only independent verifier checks release hashes, preserved source bytes and frozen seals, all 500 original plus 100 amendment split definitions, all 2,200 prediction groups, saved labels, 40 aggregate cells, 400 paired contrasts, 800 stratum rows and all 16 summary cells, 20,000 split-only twin-rate simulations, every 50-seed cell and registry structure. It uses no fit implementation. Without workbooks it establishes internal consistency of the saved labels/hashes, not independent source-byte binding or reconstruction of seven-feature values. Its JSON explicitly reports this limitation.

## Source-bound verification in an extracted local copy

Third-party workbooks are deliberately excluded. Use your lawful local copies, or opt into inbound downloads from the exact official provider URLs:

```sh
python tools/place_inputs.py --provider-local /path/to/provider.xlsx --chu-local /path/to/official-chu.xlsx
# Alternatively, explicit inbound fetches; no upload occurs:
python tools/place_inputs.py --download-provider --download-chu
python tools/verify_saved_results.py --bind-workbooks
```

`place_inputs.py` only verifies bytes and places the provider workbook in the two original locations and the Chu workbook in its original relative location. It neither changes workbook content nor edits historic code or seals. It refuses mismatched hashes and overwrites. Run it in a disposable extracted copy; do not add downloaded workbooks to a public archive. The source-bound verifier reconstructs every canonical full/input row hash and label, all 2,376 cross-provider numeric cells, duplicate rows and true seven-input group disjointness. The independent portable verifier also checks all 16 saved stratum-summary cells at a 1e-12 absolute tolerance. The unchanged historical fixed-strata verifier regenerates identical CSV bytes but fails its strict summary-dictionary equality on six SD last bits under Python 3.11 (maximum 2.22e-16); see PORTABILITY_NOTES.md. This limitation is retained, not hidden by editing the original code or saved QA. No-fit internal extraction QA was performed using pre-existing lawful local inputs; package creation made no HTTP requests.

## Original code and regeneration boundaries

Historical code files in the experiment directory are byte-identical to their originals, checked by `provenance/SOURCE_BYTE_MANIFEST.json` and the original freeze files. The new `tools/` scripts are separately hashed adapters/verifiers; they are not presented as frozen pre-analysis code. The original `FROZEN_MANIFEST.json`, `CHU7_GROUP_FROZEN.json`, predictions, metrics and original QA remain unchanged.

`run_exact_twin_audit.py` and `run_chu7_group_sensitivity.py` **fit models and overwrite historical output names if executed**. They are retained for provenance and possible separate future reproductions, but are not verification commands and were not run during staging. Do not execute them against retained evidence. `verify_and_plot_results.py` performs no fits but rewrites QA/figure outputs; use only a disposable copy if explicitly regenerating figures. Its path ancestry works in the retained folder structure after inputs are placed.

`build_lineage_registry.py` can rebuild the registry using the included minimal derived `C1_crossdb_audit/probe/expanded_search.json`. This input preserves only the adjacent-record DOI/title/own screening notes consumed by the unchanged builder. It is a public derivative with distinct source/output hashes in `provenance/DERIVED_SOURCE_MAP.json`, not a claim that the full historical search export is redistributed. The historical notes include superseded decisions; the registry builder contains their explicit corrections. Query logs are retained, but are not a complete chronological record of all conversational searches. Publisher text must be accessed separately under its own terms; the registry contains our factual classification and paraphrase.

`provenance/fetch_training_workbook.py` is the unchanged older public helper, retained for provider URL/hash/attribution provenance; its original `common.py` guard expects the older benchmark archive. Use the new path-only `tools/place_inputs.py` for this bundle. `provenance/build_research_report.py` is the unchanged historical scientific-report/manuscript builder. Its numerical inputs and report are included; its older manuscript-branch dependency is deliberately excluded, so its full manuscript-authoring workflow is not a portable command in this package. This bundle contains no submission manuscript or DOCX and makes no authorship or submission-readiness claim.

## Dependencies and actual QA environment

The frozen primary manifest records Python 3.9.6, NumPy 2.0.2, pandas 2.3.3 and scikit-learn 1.6.1. The original auxiliary package versions were not captured there. `requirements.txt` pins those three known numerical packages and uses the observed existing C1 QA environment's openpyxl, joblib, matplotlib and scipy versions for auxiliary reproducibility; it is not an assertion of a fully recovered original lockfile. Python 3.11 is needed for this combined auxiliary stack. No environment or global installation is included or performed.

Actual staging QA used the existing C1 environment: Python 3.11.15, NumPy 2.4.6, pandas 2.3.3, scikit-learn 1.6.1, openpyxl 3.1.5, joblib 1.6.0, matplotlib 3.11.2, scipy 1.17.1. `qa_environment.json` records this difference. Recomputed saved metrics pass numerical tolerances without refitting; this does not establish that a refit under a different NumPy/Python would be byte-identical.

## Integrity and rights

`FILE_LIST.txt` is the exact relative file inventory. `MANIFEST.sha256` hashes every payload file except itself; its own checksum and archive checksums are sealed externally in staging QA. `provenance/SOURCE_BYTE_MANIFEST.json` binds unchanged original files. Newly generated adapters and the minimal derived search input have their own release hashes. The ZIP and tar.xz contain exactly this payload, no workbooks or QA copies.

See `THIRD_PARTY_NOTICES.md` for provider attribution and limits. This is staging only; no Git mutation, upload, release creation or remote publication has occurred. Before publication, the responsible author must confirm distribution rights for their original code, analyses and derived values and select an appropriate license; no new blanket license grant is invented here. The CC BY 4.0 provider attribution does not extend to publisher full texts or all supplementary files.
