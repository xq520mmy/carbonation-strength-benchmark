#!/usr/bin/env python3
"""Close the prespecified fixed-Test stratum reporting omission; no fitting.

Stratum membership derives only from ORIGINAL frozen row-random Train/Test
indices and canonical complete-row hashes, and stays fixed in all three arms.
The existing arm-specific `full_twin_in_train` prediction flags are never used.
All existing inputs are read-only. --verify-only recomputes without any writes.
"""
from pathlib import Path
from collections import Counter, defaultdict
from zipfile import ZipFile
from hashlib import sha256
from datetime import datetime, timezone
import argparse, csv, io, json, math, statistics, sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
ARMS = ('row_random', 'row_random_purge_twin', 'row_random_size_control')
SCHEMAS = ('stored11', 'Chu7')
MODELS = ('RF300', 'ET300')
INPUTS = ('PROTOCOL.md', 'FROZEN_MANIFEST.json', 'run_exact_twin_audit.py',
          'predictions.csv', 'split_metrics.csv', 'aggregate_metrics.csv',
          'paired_twin_intervention.csv', 'row_hashes.csv', 'DATA_IDENTITY.json',
          'CHU_WANI_ROW_IDENTITY.json', 'sources/Chu2025_official_mmc1.xlsx')

def digest(p): return sha256(p.read_bytes()).hexdigest()
def read_csv(name):
    with (ROOT / name).open(newline='') as f: return list(csv.DictReader(f))
def canonical(row):
    text = '|'.join(float(0.0 if float(x) == 0 else x).hex() for x in row)
    return sha256(text.encode()).hexdigest()
def official_rows():
    ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with ZipFile(ROOT / 'sources/Chu2025_official_mmc1.xlsx') as z:
        strings = [''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si', ns)]
        sheet = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
        rows = []
        for r in sheet.findall('s:sheetData/s:row', ns):
            cells = {}
            for c in r:
                v = c.find('s:v', ns)
                if v is None: continue
                col = ''.join(x for x in c.attrib['r'] if x.isalpha())
                cells[col] = strings[int(v.text)] if c.get('t') == 's' else float(v.text)
            if cells: rows.append(cells)
    columns = list('ABCDEFGHIJKLM')
    headers = [rows[0][c] for c in columns]
    assert headers == ['序号','C','CA','FA','W','高炉矿渣','粉煤灰','W/B','CCU-蒸养时间','T','CC','P','CS']
    numeric = [[r[c] for c in columns[1:]] for r in rows[1:]]
    assert len(numeric) == 198 and all(len(r) == 12 and all(math.isfinite(v) for v in r) for r in numeric)
    assert [r['A'] for r in rows[1:]] == list(range(1,199))
    return numeric

def score(y, prediction):
    assert len(y) == len(prediction) > 0
    sse = sum((a-b)**2 for a,b in zip(y,prediction))
    sst = sum((a-statistics.mean(y))**2 for a in y)
    return {'r2': 1-sse/sst if len(y)>1 and sst>0 else None,
            'rmse': math.sqrt(sse/len(y)),
            'mae': statistics.mean(abs(a-b) for a,b in zip(y,prediction))}
def quantile(values, p):
    a=sorted(values);v=(len(a)-1)*p;lo=math.floor(v);hi=math.ceil(v)
    return a[lo]*(hi-v)+a[hi]*(v-lo) if hi!=lo else a[lo]
def summary(values):
    v=[x for x in values if x is not None]
    return {'defined_n':len(v),'mean':statistics.mean(v) if v else None,
            'split_sd':statistics.stdev(v) if len(v)>1 else None,
            'split_p025':quantile(v,.025) if v else None,
            'split_p975':quantile(v,.975) if v else None,
            'negative_n':sum(x<0 for x in v),'zero_n':sum(x==0 for x in v),'positive_n':sum(x>0 for x in v)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');args=ap.parse_args()
    dest=ROOT/'fixed_test_strata_metrics.csv';qa_path=ROOT/'FIXED_TEST_STRATA_QA.json'
    if not args.verify_only: assert not dest.exists() and not qa_path.exists(), 'New-only outputs already exist; use --verify-only'
    before={n:digest(ROOT/n) for n in INPUTS}
    frozen=json.loads((ROOT/'FROZEN_MANIFEST.json').read_text())
    assert before['PROTOCOL.md']==frozen['protocol_sha256'] and before['run_exact_twin_audit.py']==frozen['code_sha256']
    identity=json.loads((ROOT/'CHU_WANI_ROW_IDENTITY.json').read_text())
    assert before['sources/Chu2025_official_mmc1.xlsx']==identity['Chu_official_sha256']
    data=official_rows();hashes=[canonical(r) for r in data]
    stored=read_csv('row_hashes.csv');assert len(stored)==198
    assert all(int(r['row_1based'])==i+1 and r['full_row_sha256']==hashes[i] for i,r in enumerate(stored))
    counts=Counter(hashes);assert len(counts)==165 and Counter(c for c in counts.values() if c>1)=={2:33}
    splits={(float(r['fraction']),int(r['seed']),r['arm']):r for r in frozen['splits']}
    membership={}
    for fraction in (.2,.3):
        for seed in range(50):
            base=splits[(fraction,seed,'row_random')];train=base['train'];test=base['test'];assert len(set(train))==len(train) and len(set(test))==len(test)
            assert set(train).isdisjoint(test) and set(train)|set(test)==set(range(198))
            train_hash={hashes[i] for i in train};test_hash={hashes[i] for i in test}
            twin=[i for i in test if hashes[i] in train_hash];other=[i for i in test if hashes[i] not in train_hash]
            removed={i for i in train if hashes[i] in test_hash}
            purge=splits[(fraction,seed,'row_random_purge_twin')];control=splits[(fraction,seed,'row_random_size_control')]
            assert purge['test']==control['test']==test and len(purge['train'])==len(control['train'])
            assert set(purge['train'])==set(train)-removed
            control_removed=set(train)-set(control['train']);assert len(control_removed)==len(removed) and not control_removed&removed
            assert set(control['train'])<=set(train) and removed<=set(control['train'])
            assert set(twin).isdisjoint(other) and set(twin)|set(other)==set(test) and twin and other
            membership[(fraction,seed)]={'twin':twin,'non_twin':other,'total_test_n':len(test),'original_train_n':len(train),'matched_train_n':len(purge['train'])}
    preqa={'all_198_canonical_full_row_hashes_recomputed_from_official_Chu_workbook':True,
           'original_protocol_and_fitting_source_hashes_match':True,'all_100_original_splits_valid':True,
           'strata_defined_from_original_membership_before_outcome_scoring':True,
           'original_test_fixed_across_three_arms':True,'purge_and_control_train_n_equal':True,
           'all_test_twins_removed_only_in_purge':True,'control_removes_same_n_non_twins_and_retains_all_twins':True,
           'no_arm_specific_seen_flags_used':True}
    print('PRE_OUTCOME_MEMBERSHIP_QA PASS: 198 canonical rows, 100 frozen splits',flush=True)
    # Only after the membership gates, load and compute saved prediction outcomes.
    groups=defaultdict(dict)
    for r in read_csv('predictions.csv'):
        if r['arm'] not in ARMS: continue
        key=(float(r['fraction']),int(r['seed']),r['schema'],r['model'],r['arm']);i=int(r['row_1based'])-1
        assert i not in groups[key];assert float(r['y'])==data[i][-1] and math.isfinite(float(r['prediction']))
        groups[key][i]=float(r['prediction'])
    assert len(groups)==1200
    result=[]
    for fraction in (.2,.3):
        for seed in range(50):
            member=membership[(fraction,seed)]
            for schema in SCHEMAS:
                for model in MODELS:
                    for arm in ARMS: assert set(groups[(fraction,seed,schema,model,arm)])==set(splits[(fraction,seed,'row_random')]['test'])
                    for label in ('twin','non_twin'):
                        ii=member[label];y=[data[i][-1] for i in ii]
                        row={'fraction':fraction,'seed':seed,'schema':schema,'model':model,'fixed_original_test_stratum':label,
                             'test_n':len(ii),'total_test_n':member['total_test_n'],'original_train_n':member['original_train_n'],
                             'matched_train_n':member['matched_train_n'],'test_rows_1based':'|'.join(str(i+1) for i in ii)}
                        scores={arm:score(y,[groups[(fraction,seed,schema,model,arm)][i] for i in ii]) for arm in ARMS}
                        for arm in ARMS:
                            for metric,value in scores[arm].items():row[arm+'_'+metric]=value
                        for metric in ('r2','rmse','mae'):
                            a=scores['row_random_purge_twin'][metric];b=scores['row_random_size_control'][metric]
                            delta=a-b if a is not None and b is not None else None
                            row['purge_minus_equalN_control_'+metric]=delta
                            row['purge_improved_'+metric]=None if delta is None else (delta>0 if metric=='r2' else delta<0)
                        result.append(row)
    assert len(result)==800
    buffer=io.StringIO(newline='');writer=csv.DictWriter(buffer,fieldnames=list(result[0]),lineterminator='\n');writer.writeheader();writer.writerows(result);payload=buffer.getvalue().encode()
    summaries=[]
    for fraction in (.2,.3):
        for schema in SCHEMAS:
            for model in MODELS:
                for label in ('twin','non_twin'):
                    rows=[r for r in result if (r['fraction'],r['schema'],r['model'],r['fixed_original_test_stratum'])==(fraction,schema,model,label)]
                    assert {r['seed'] for r in rows}==set(range(50)) and len(rows)==50
                    rec={'fraction':fraction,'schema':schema,'model':model,'stratum':label,'n_splits':50,
                         'test_n_mean':statistics.mean(r['test_n'] for r in rows),'test_n_min':min(r['test_n'] for r in rows),'test_n_max':max(r['test_n'] for r in rows)}
                    for metric in ('r2','rmse','mae'):
                        rec['delta_'+metric]=summary([r['purge_minus_equalN_control_'+metric] for r in rows]);rec['purge_improved_'+metric+'_n']=sum(r['purge_improved_'+metric] is True for r in rows)
                    summaries.append(rec)
    after={n:digest(ROOT/n) for n in INPUTS};assert before==after,'An original input changed during the analysis'
    qa={'status':'PASS','created_utc':datetime.now(timezone.utc).isoformat(),'no_refit':True,
        'purpose':'Complete the fixed-Test twin/non-twin output prespecified in PROTOCOL.md line19; no new model or tuning.',
        'scope':'Fixed original row-random Train/Test, canonical complete-row keys including CS; matched-N purge versus non-twin control. Descriptive repeated-split variability, not independent-population confidence intervals.',
        'source_code_sha256':digest(Path(__file__)),'python':sys.version,'input_sha256':before,'all_existing_inputs_unchanged':True,
        'pre_outcome_qa':preqa,'original_split_count':100,'saved_prediction_groups_used':1200,'output_metric_rows':800,
        'complete_summary_cells':16,'all_50_seeds_in_every_cell':True,'undefined_r2_rows':sum(r['purge_minus_equalN_control_r2'] is None for r in result),
        'output_csv_sha256':sha256(payload).hexdigest(),'summary':summaries}
    if args.verify_only:
        assert dest.read_bytes()==payload
        prior=json.loads(qa_path.read_text());assert prior['source_code_sha256']==qa['source_code_sha256'] and prior['input_sha256']==before and prior['summary']==summaries and prior['output_csv_sha256']==qa['output_csv_sha256']
        print('VERIFY_ONLY PASS: identical CSV bytes and all 16 summary cells')
    else:
        with dest.open('xb') as f:f.write(payload)
        with qa_path.open('x') as f:json.dump(qa,f,indent=2,allow_nan=False);f.write('\n')
        print('PASS: 800 fixed-stratum rows; 16 complete summary cells; no original files changed')
    print('| Test | Features | Model | Stratum | Mean Test N | Mean ΔR² | Mean ΔRMSE | Mean ΔMAE | RMSE improvement splits |')
    print('|---|---|---|---|---:|---:|---:|---:|---:|')
    for r in summaries:
        print(f"| {r['fraction']:.0%} | {r['schema']} | {r['model']} | {r['stratum']} | {r['test_n_mean']:.2f} | {r['delta_r2']['mean']:+.4f} | {r['delta_rmse']['mean']:+.3f} | {r['delta_mae']['mean']:+.3f} | {r['purge_improved_rmse_n']}/50 |")
if __name__=='__main__':main()
