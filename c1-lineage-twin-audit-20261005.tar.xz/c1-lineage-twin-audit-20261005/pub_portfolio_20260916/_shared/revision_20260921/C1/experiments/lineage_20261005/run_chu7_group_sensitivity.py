#!/usr/bin/env python3
import json, time
from pathlib import Path
from joblib import Parallel, delayed
import run_exact_twin_audit as R

def main():
    started=time.time();df=R.pd.read_excel(R.DATA);cols=R.FEATURES['Chu7'];X=df[cols].to_numpy(float);y=df.CS.to_numpy(float)
    groups=R.keys(X);assert len(set(groups))==83
    splits=[]
    for f in (.2,.3):
        for s in R.SEEDS:
            a,b=next(R.GroupShuffleSplit(n_splits=1,test_size=f,random_state=s).split(X,groups=groups))
            assert not R.np.isin(groups[a],groups[b]).any()
            splits.append({'fraction':f,'seed':s,'train':a.tolist(),'test':b.tolist()})
    freeze={'amendment_sha256':R.sha(R.HERE/'AMENDMENT_01.md'),'code_sha256':R.sha(Path(__file__)),
            'data_sha256':R.sha(R.DATA),'status':'FROZEN_BEFORE_ADDITIONAL_FITS','splits':splits}
    (R.HERE/'CHU7_GROUP_FROZEN.json').write_text(json.dumps(freeze,indent=2))
    def run(c,name):
        a=R.np.array(c['train']);b=R.np.array(c['test']);mk=R.RandomForestRegressor if name=='RF300' else R.ExtraTreesRegressor
        m=mk(n_estimators=300,n_jobs=1,random_state=c['seed']);m.fit(X[a],y[a]);p=m.predict(X[b])
        z={'fraction':c['fraction'],'seed':c['seed'],'model':name,'schema':'Chu7','arm':'Chu7_input_vector_group',
           'train_n':len(a),'test_n':len(b),'model_input_seen_rate':float(R.np.isin(groups[b],groups[a]).mean()),**R.metrics(y[b],p)}
        pred=[{**{k:z[k] for k in ('fraction','seed','model','arm')},'row_1based':int(i+1),'y':float(y[i]),'prediction':float(v)} for i,v in zip(b,p)]
        return z,pred
    rs=Parallel(n_jobs=6)(delayed(run)(c,m) for c in splits for m in ('RF300','ET300'))
    d=R.pd.DataFrame([r[0] for r in rs]);d.to_csv(R.HERE/'chu7_group_metrics.csv',index=False)
    R.pd.DataFrame([p for r in rs for p in r[1]]).to_csv(R.HERE/'chu7_group_predictions.csv',index=False)
    assert (d.model_input_seen_rate==0).all()
    q={'status':'COMPLETE','n_model_fits':len(d),'zero_actual_seven_input_overlap':True,'elapsed_seconds':time.time()-started}
    (R.HERE/'CHU7_GROUP_QA.json').write_text(json.dumps(q,indent=2));print(json.dumps(q))

if __name__=='__main__':main()
