# Bounded publication lineage registry

Search window: 2025-01-01 through 2026-10-05. This registry supersedes the initial inventory’s overconfident independence and all-SD-match notes; it does not delete the historical records.

Ten confirmed full research works are identified: eight literature-compilation works and two papers with own experimental components. One further experimental/SVR paper remains eligible pending target verification. One extended abstract and one thesis are separate strata. The two versions of Davies–Zhang count once.

For the eight identified strength-compilation works, including Xu’s broader post-carbonation process scope, the six reported strength-table sizes are 198, 280, 293, 333, 399 and 423. Chu and Alsharedah–Wani are one numerically identical table. Wang is a strong printed-signature match with a retained exception; therefore the number of distinct complete compilations is bounded by 6–7. A curing-only frame that withholds Xu until full-text process verification has seven works and 5–6 complete compilations. Neither bound is **K independent physical experiments** or a count of mutually row-disjoint tables.

| Work | N strength | Relationship to anchor | Evidence | Access |
|---|---:|---|---|---|
| [Chu2025](https://doi.org/10.1016/j.cscm.2025.e04589) | 198 | same-table | exact_numeric_rows | fulltext_and_official_table |
| [Wang2026](https://www.mdpi.com/2075-5309/16/1/89) | 198 | indeterminate | probable_same_table_printed_signature | fulltext; raw data on request |
| [AlsharedahWani2026](https://www.nature.com/articles/s41598-026-56278-y) | 198 | same-table | exact_numeric_rows | fulltext_and_public_table |
| [Han2026](https://link.springer.com/article/10.1186/s40069-026-00956-8) | 423 | indeterminate | different_full_compilation | fulltext; no complete machine-readable compiled table recovered |
| [Hilaloglu2026](https://doi.org/10.1016/j.cscm.2026.e05910) | 280 | indeterminate | declared_source_overlap | author full text read; official repository PDF response was 212-byte HTML, retained as BLOCKED |
| [ChoKim2026](https://www.jkci.or.kr/jkci/XmlViewer/f450880) | 333 | indeterminate | declared_source_overlap | fulltext HTML saved; compiled raw table not recovered |
| [DaviesZhang2026](https://link.springer.com/chapter/10.1007/978-3-032-27698-8_84) | 399 | indeterminate | different_full_compilation | fulltext PDF downloaded |
| [XuChenLiu2026](https://www.sciencedirect.com/science/article/abs/pii/S0952197626007220) | 293 | indeterminate | different_full_compilation | publisher abstract read; full text access blocked |
| [Talip2026](https://link.springer.com/article/10.1007/s40243-026-00356-8) | unknown | independent | reported_own_experimental_origin | fulltext PDF/HTML and official summary table downloaded |
| [Padavala2026](https://link.springer.com/article/10.1007/s41024-026-00847-1) | unknown | indeterminate | own_experiment_claim_abstract_only | official preview; subscription full text not accessed |
| [ChenBiochar2025](https://www.sciencedirect.com/science/article/abs/pii/S0950061825028855) | unknown | indeterminate | own_experiment_ml_target_unresolved | publisher abstract; full text pending |
| [CaiMa2025](https://docs.lib.purdue.edu/c3_2025/2025/carbon/9/) | unknown | indeterminate | abstract_only | official repository HTML saved; linked download HTTP403 |
| [HilalogluThesis2026](https://doi.org/10.25781/kaust-6gt1y) | unknown | indeterminate | abstract_only | repository abstract; full text not recovered |

The same-table relationship is symmetric. Publication/deposit chronology does not establish who physically copied a table or prove misconduct. Identical measurements may reflect legitimate reuse, transcription, or repeated reporting; physical specimen identity requires source-level records.

## Record evidence

### Chu2025

Official supplementary table: 198 rows, 12 numeric measurements after dropping serial. Anchor full-row multiset identity.

Primary reference: [10.1016/j.cscm.2025.e04589](https://doi.org/10.1016/j.cscm.2025.e04589).

### Wang2026

Matching N, schema, extensive printed moments/extrema strongly suggest the anchor. No raw table was recovered. Cement SD printed 171.18 differs from Chu 171.8; the old claim that ddof explains every difference is withdrawn.

Primary reference: [10.3390/buildings16010089](https://www.mdpi.com/2075-5309/16/1/89).

### AlsharedahWani2026

Public deposit and recovered supplemental table are byte-identical. All 2376 numeric cells match original Chu official supplement, in the same row order, after documented header mapping; source file bytes differ.

Primary reference: [10.1038/s41598-026-56278-y](https://www.nature.com/articles/s41598-026-56278-y).

### Han2026

423 strength records, 131 separate uptake records, chemistry/preconditioning schema. Different complete compilation from the 198-row anchor; raw partial overlap and independent experimental-origin counts unresolved. Own mortar validation is a separate cohort.

Primary reference: [10.1186/s40069-026-00956-8](https://link.springer.com/article/10.1186/s40069-026-00956-8).

### Hilaloglu2026

Author-posted full text explicitly declares data-source references [28,31-54], including Chu as [54]. Numerous named original sources overlap. This establishes compilation dependency/source overlap, not row membership. N=280 and printed range differ. Original numeric rows remain unavailable.

Primary reference: [10.1016/j.cscm.2026.e05910](https://doi.org/10.1016/j.cscm.2026.e05910).

### ChoKim2026

Official Korean full text and publisher article landing page use DOI suffix .091: 333 records/23 declared sources, includes both Chen-Gao 2019/2020 and Zhang-Shao 2016 source papers also named in Chu. Target moments and age/time schema differ; row-level intersection unknown. Institutional index spelling .91 is retained as a variant, with publisher .091 primary.

Primary reference: [10.4334/JKCI.2026.38.1.091](https://www.jkci.or.kr/jkci/XmlViewer/f450880).

### DaviesZhang2026

Full OA chapter: 399 observations from 37 articles as declared. Different complete compilation; partial row intersection unresolved. The 2025 HKUST record and 2026 chapter have the same title/authors/N/results and count as one work.

Primary reference: [10.1007/978-3-032-27698-8_84](https://link.springer.com/chapter/10.1007/978-3-032-27698-8_84).

### XuChenLiu2026

Publisher abstract reports 293 literature records and cube strength, Bayesian ET/RF/XGB/ANN models. The accessible introduction includes both curing and broader post-carbonation mechanical changes; eligibility for a curing-only frame needs full text. Different N proves a nonidentical full compilation, not independent experimental origin.

Primary reference: [10.1016/j.engappai.2026.114441](https://www.sciencedirect.com/science/article/abs/pii/S0952197626007220).

### Talip2026

Full text explicitly derives ML data from its own mortar tests. Table2 displays 14 composition/curing summaries, of which 9 are CO2-cured and 5 normal; exact number of training records not separately stated. Different material/schema and own origin are documented; this is an independence statement from methods, not forensic proof of zero coincident numeric values.

Primary reference: [10.1007/s40243-026-00356-8](https://link.springer.com/article/10.1007/s40243-026-00356-8).

### Padavala2026

Publisher abstract describes four newly tested mixes under normal and two CO2 regimes, with ANN/SVM/RF performance prediction. Full text unavailable and exact ML training provenance not established. Publisher data-availability statement says no data generated/analysed, inconsistent with abstract; preserve discrepancy and request full text.

Primary reference: [10.1007/s41024-026-00847-1](https://link.springer.com/article/10.1007/s41024-026-00847-1).

### ChenBiochar2025

Publisher abstract/highlights describe new ACC mortar experiments and SVR-assisted optimization, but exact SVR target and training cohort cannot be verified from accessible abstract. Retain as potentially eligible; do not exclude because it weakens a reuse claim.

Primary reference: [10.1016/j.conbuildmat.2025.142734](https://www.sciencedirect.com/science/article/abs/pii/S0950061825028855).

### CaiMa2025

Primary symposium repository describes ensemble predictions of uptake and strength in carbonated calcium-silicate materials. N and original sources unknown. Document type is extended abstract, counted separately from full research articles.

Primary reference: [10.5703/1288284317986](https://docs.lib.purdue.edu/c3_2025/2025/carbon/9/).

### HilalogluThesis2026

Same first author as Hilaloglu journal paper; ML table relationship unverified. Own experimental component in abstract does not prove ML training table is independently compiled. Potential version relationship is flagged, not counted as a proven duplicate publication.

Primary reference: [10.25781/kaust-6gt1y](https://doi.org/10.25781/kaust-6gt1y).

### Bawab2026

Predicts CO2 uptake, not compressive strength.

Primary reference: [10.1016/j.mtcomm.2026.116010](https://doi.org/10.1016/j.mtcomm.2026.116010).

### Rashid2025

CO2 dosage during mixing, not accelerated carbonation curing; excluded by process scope, not by result.

Primary reference: [10.7717/peerj-cs.3316](https://peerj.com/articles/cs-3316/).

### ChenCMES2026

Primary full text Sections 2.2–2.3 describe recycled aggregate carbonated before batching; concrete specimens then undergo standard curing and sulfate wet-dry exposure. Thus this is aggregate pretreatment, outside the frozen concrete/carbonated-composite curing process scope. The 297 physical cubes are not inferred to be the number of ML training rows.

Primary reference: [10.32604/cmes.2026.089217](https://www.techscience.com/CMES/v148n3/69015/html).

### Sun2025

Carbonation-depth prediction, not strength; a citing paper describing this as strength modelling is not accepted as primary evidence.

Primary reference: [10.1038/s44296-025-00053-z](https://www.nature.com/articles/s44296-025-00053-z).

### Adjacent_2

文献派生库 + ML + CO2 固碳，但材料体系是钢渣浆相碳化，不是 CO2 养护混凝土；目标是钢渣碳化反应活性。

Primary reference: [10.1021/acs.est.2c06133](https://doi.org/10.1021/acs.est.2c06133).

### Adjacent_3

碳化处理的是再生骨料（RA），不是对混凝土构件做 CO2 养护；且数据为文献 + 自有实验混合。

Primary reference: [10.3390/buildings16132602](https://doi.org/10.3390/buildings16132602).

### Adjacent_4

Rechecked primary Nature full text: carbonated recycled aggregates are subsequently used in concrete; 108 samples from prior author experiments. Excluded because aggregate pretreatment is outside curing scope, not because experiments are self-generated. Historical exclusion wording is superseded.

Primary reference: [10.1038/s41598-026-36197-8](https://doi.org/10.1038/s41598-026-36197-8).

### Adjacent_5

自有实验数据（100 组配比），目标是再生细骨料碳化率 CP，非 CO2 养护混凝土强度/吸碳量。

Primary reference: [10.1080/21650373.2024.2449491](https://doi.org/10.1080/21650373.2024.2449491).

### Adjacent_6

库含碳化再生粗骨料（CRCA）混凝土，但目标是 CO2 排放/强度的 CO2 intensity index 与配合比优化，非 CO2 养护工艺寻优。

Primary reference: [10.1016/j.jcou.2024.102862](https://doi.org/10.1016/j.jcou.2024.102862).

### Adjacent_7

材料体系为活性氧化镁水泥（RMC），目标是水化度与碳化度，非 CO2 养护混凝土强度/吸碳量。

Primary reference: [10.1016/j.jclepro.2023.140054](https://doi.org/10.1016/j.jclepro.2023.140054).

### Adjacent_8

题名落在'碳化/CO2 + 水泥基 + ML'范围内，但**摘要在 OpenAlex / Crossref / Semantic Scholar 中均缺失**，无法判定是否为文献派生库、目标变量与样本量。纯标题层级命中。

Primary reference: [10.1007/s41024-025-00757-8](https://doi.org/10.1007/s41024-025-00757-8).

### Adjacent_9

Newly read publisher abstract: 814 samples for RAC strength/emissions with calculated old-mortar carbonation potential; not a CO2-curing strength cohort.

Primary reference: [10.1016/j.cscm.2026.e06381](https://doi.org/10.1016/j.cscm.2026.e06381).

### Adjacent_10

题名落在'碳化/CO2 + 水泥基 + ML'范围内，但**摘要在 OpenAlex / Crossref / Semantic Scholar 中均缺失**，无法判定是否为文献派生库、目标变量与样本量。纯标题层级命中。

Primary reference: [10.1016/j.jes.2026.105712](https://doi.org/10.1016/j.jes.2026.105712).

### Adjacent_11

题名落在'碳化/CO2 + 水泥基 + ML'范围内，但**摘要在 OpenAlex / Crossref / Semantic Scholar 中均缺失**，无法判定是否为文献派生库、目标变量与样本量。纯标题层级命中。

Primary reference: [10.1007/s11709-020-0635-2](https://doi.org/10.1007/s11709-020-0635-2).

### Adjacent_12

题名落在'碳化/CO2 + 水泥基 + ML'范围内，但**摘要在 OpenAlex / Crossref / Semantic Scholar 中均缺失**，无法判定是否为文献派生库、目标变量与样本量。纯标题层级命中。

Primary reference: [10.1016/j.jclepro.2025.145727](https://doi.org/10.1016/j.jclepro.2025.145727).

### Adjacent_13

题名落在'碳化/CO2 + 水泥基 + ML'范围内，但**摘要在 OpenAlex / Crossref / Semantic Scholar 中均缺失**，无法判定是否为文献派生库、目标变量与样本量。纯标题层级命中。

Primary reference: [10.1007/978-3-032-14170-5_5](https://doi.org/10.1007/978-3-032-14170-5_5).

### Adjacent_14

题名落在'碳化/CO2 + 水泥基 + ML'范围内，但**摘要在 OpenAlex / Crossref / Semantic Scholar 中均缺失**，无法判定是否为文献派生库、目标变量与样本量。纯标题层级命中。

Primary reference: [10.1016/j.istruc.2025.110521](https://doi.org/10.1016/j.istruc.2025.110521).
