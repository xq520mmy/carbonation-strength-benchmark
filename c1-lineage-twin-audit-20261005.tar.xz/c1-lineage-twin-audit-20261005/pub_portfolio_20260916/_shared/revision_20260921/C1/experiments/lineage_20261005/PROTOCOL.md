# C1 bounded lineage and exact-twin audit

Frozen before new model scoring, 2026-10-05. This is a retrospective audit of an already exposed resource, not an independent prospective test.

## Search and evidence

Search window: first public appearance 2025-01-01 through 2026-10-05. Main scope: ML prediction of compressive strength after accelerated CO2/carbonation curing of cementitious materials. Carbonation depth, ordinary concrete strength, uptake-only prediction and reviews are separate boundary records. Journal articles, proceedings and theses are counted separately; versions of the same work are linked. Existing 43-query inventory is an input, not proof of exhaustive coverage. Update primary publisher/repository records and log queries, dates, access failures and exclusions.

Each publication receives an anchor-table relationship: same-table / overlap / independent / indeterminate, plus evidence level. Identical printed moments cannot establish row identity. A different N proves a different full compilation, but does not prove independent experiments or no partial overlap. Shared source citations prove source overlap only when explicitly named as data sources. Absence of an accessible table is indeterminate, not independent. Compilation count K and independent-experiment count are different quantities; unresolved relationships require bounds, not an invented exact K.

## Row identity

Anchor: recovered 198 x 12 numeric workbook and official public Mendeley copy. Hash source bytes and canonical numeric rows. Full-row identity includes all 11 stored inputs and CS; input-vector identity excludes CS. Drop no data columns except nonmeasurement serial identifiers when explicitly present. Do not round numeric values for exact identity. Hash canonical IEEE float.hex strings with -0 normalized to 0; fail on missing/nonfinite cells. Count duplicate groups, participating rows, redundant rows, and unordered pairs separately. Two rows with the same reported measurements need not be proven copies of the same physical specimen.

## Splits and fixed models

All 198 rows, fractions 0.20 and 0.30, seeds 0..49 fixed before scores. Primary stored 11-feature schema; sensitivity is the seven Chu inputs C/CA/FA/W-B/T/P/CC. RF300 and ET300 use defaults apart from 300 trees, seed and n_jobs=1. No tuning or seed selection. Compare row-random, full-row-disjoint GroupShuffleSplit and input-vector-disjoint GroupShuffleSplit. Group test fractions refer to groups, so report achieved row counts rather than call sizes identical.

Paired fixed-Test intervention: retain each row-random Test, purge from Train every full-row twin of any Test row. Add equal-size control removing the same number of non-twin Train rows with seed+100000. Both reduced training sets have identical N. Report paired loss changes, score on the identical Test and separately on twin/non-twin Test strata. This isolates removal of known twins at matched training size; it does not establish all of the row-versus-group gap is caused by duplicates.

Leakage rate denominator is ALL Test rows. Also report rate among Test rows belonging to an exact-duplicate group. Analytic expected rate for pairs under a fixed random Test size n is (66/198)*(198-n)/197 if, and only if, the audit finds exactly 33 size-two groups. Validate against 10,000 split-only replicates (no model fitting).

Source-group results already have a partially traced cohort and must keep their original row membership and assumptions. They are presented alongside this audit, not conflated with the matched 198-row interventions. Do not infer that every provenance split must score worse.

## Reporting

Write all split indices, predictions, counts, data/code/protocol hashes, environment versions and seed-level metrics. Report mean/SD and 2.5/97.5 percentiles across repeated splits as split variability, not independent-sample confidence intervals. Paired differences use the fixed Test and same seed. A seed bootstrap is descriptive Monte Carlo uncertainty, not a new-population inferential CI. Do not assert R2>=.95 is impossible outside random splits: record the frequency in each arm, model and schema. Include zeros and counterexamples. No result-dependent additions to this matrix.
