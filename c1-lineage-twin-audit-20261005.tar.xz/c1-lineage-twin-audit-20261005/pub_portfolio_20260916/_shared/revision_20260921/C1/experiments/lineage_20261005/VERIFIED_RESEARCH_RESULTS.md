# C1: bounded lineage and matched exact-twin interventions

### Bounded publication lineage

The search was bounded by first public appearance from 1 January 2025 to 5 October 2026. It extends the retained 43-query inventory by publisher checks and citation chasing. It identifies eight strength-prediction compilations, two further full research papers with own experimental components, one potentially eligible biochar/SVR paper requiring target verification, one extended abstract, and one thesis. This is an identified-literature frame rather than a proved census of the entire subfield. The registry retains unresolved eligibility, unavailable raw data, and duplicate publication versions.

The official Chu supplement and the public table accompanying Alsharedah and Wani agree in all 2,376 numeric cells, including compressive strength, after removal of the former's serial column and translation of three column headers. Their source bytes differ, but their numeric rows and order are identical. Wang's 198-row table is a probable match based on its extensive printed signature; no raw table was obtained. The printed cement SD of 171.18 is retained as an exception, not repaired until it matches. Numeric identity does not establish the direction of copying or identical physical specimens.

Across the eight identified compilations, the reported N values are 198, 280, 293, 333, 399 and 423. Merging only the row-confirmed Chu/Alsharedah–Wani pair bounds the number of distinct complete compilations by six to seven, depending on the unresolved Wang relationship. The 293-row Xu paper covers broader post-carbonation processes; withholding it from a curing-only frame gives seven works and five to six compilations. These are complete-table counts, not independent experimental origins or mutually disjoint datasets. Hilaloglu explicitly includes Chu among its declared data sources, and Cho–Kim shares named experimental sources with Chu, but neither observation quantifies row overlap. Talip's methods describe newly tested mortar as the ML data origin, countering any universal claim that all relevant work reuses a few literature tables. Exact K independent physical experiments remains unidentified.

### Full-row identity and exact-twin exposure

The 198×12 numeric table contains 165 unique complete rows. Thirty-three duplicate groups each have exactly two members: 66 participating rows, 33 redundant records, and 33 unordered equal-row pairs. The stored eleven-input schema has 84 distinct inputs; the seven inputs used in Chu's modelling have 83. Full-row equality here means every stored input plus strength agrees exactly at the released precision. It does not prove that two rows represent one physical specimen, and missing experimental provenance remains unresolved.

For a uniformly drawn fixed Test of size n, the expected fraction of all Test rows whose complete twin is in Train is (66/198)×(198−n)/197. Thus fixed 40-row and 60-row Tests give 26.734% and 23.350%, respectively. A 10,000-split simulation checks the expression. In the 50 scored splits the means are 26.300% and 23.667%. The denominator is all Test rows; this rate is different from the conditional rate among duplicate-bearing Test rows and from an input-only match rate.

### Prespecified split matrix and matched-size intervention

RF and ExtraTrees each use 300 trees and scikit-learn defaults apart from seed and single-thread fitting. All 198 records are retained. The primary schema is the eleven stored inputs, with Chu's seven inputs a declared sensitivity. Test fractions 0.20 and 0.30 and seeds 0–49 are frozen. Five arms comprise row-random, complete-row-disjoint groups, stored-input-vector-disjoint groups, fixed-Test exact-twin removal, and fixed-Test equal-size removal of non-twin training rows. There is no hyperparameter or seed selection. Group fractions apply to groups; achieved Train/Test row counts vary. These fits do not claim to reproduce each published model's optimized configuration.

In the intervention, each row-random Test is held constant. The first reduced Train removes all complete twins of Test records. The second removes the same number of randomly chosen non-twin Train rows using a fixed secondary RNG. Train N and Test identities are therefore matched. Remaining source and composition similarities are not removed. The paired contrast measures sensitivity to removal of known twins at a fixed training size; it is not the fraction of all split inflation caused by duplication, and it is not a guarantee for a new campaign. All predictions, split indices and code/data hashes are retained.

### Scores and counterexamples

With eleven stored inputs, mean row-random R² is 0.9512–0.9525 across the two models and Test fractions. Full-row grouping lowers the mean to 0.9363–0.9454, while eleven-input grouping gives 0.7108–0.7743. These are different Test cohorts, so the complete gaps cannot be assigned to exact twins. High scores remain possible without complete twins: 26/50 RF and 29/50 ExtraTrees full-row-group splits at nominal 20% Test exceed 0.95. For seven inputs, even the full-row-group RF mean is 0.9509. Consequently, the claim that R²≥0.95 is reproducible only under row-random splits is rejected by this matrix.

| Test fraction | Model | Split unit | Mean R² ± split SD | Seeds R² ≥ 0.95 | Mean Train / Test N |
|---|---|---|---:|---:|---:|
| 20% | ET300 | full (X,y) row | 0.9454 ± 0.0287 | 29/50 | 158.42 / 39.58 |
| 20% | ET300 | 11-input vector | 0.7743 ± 0.2011 | 17/50 | 156.36 / 41.64 |
| 20% | ET300 | row | 0.9525 ± 0.0319 | 34/50 | 158.00 / 40.00 |
| 20% | RF300 | full (X,y) row | 0.9452 ± 0.0240 | 26/50 | 158.42 / 39.58 |
| 20% | RF300 | 11-input vector | 0.7414 ± 0.2374 | 12/50 | 156.36 / 41.64 |
| 20% | RF300 | row | 0.9515 ± 0.0297 | 35/50 | 158.00 / 40.00 |
| 30% | ET300 | full (X,y) row | 0.9363 ± 0.0294 | 19/50 | 138.26 / 59.74 |
| 30% | ET300 | 11-input vector | 0.7498 ± 0.2069 | 6/50 | 135.20 / 62.80 |
| 30% | ET300 | row | 0.9512 ± 0.0211 | 29/50 | 138.00 / 60.00 |
| 30% | RF300 | full (X,y) row | 0.9405 ± 0.0262 | 20/50 | 138.26 / 59.74 |
| 30% | RF300 | 11-input vector | 0.7108 ± 0.2623 | 2/50 | 135.20 / 62.80 |
| 30% | RF300 | row | 0.9525 ± 0.0225 | 32/50 | 138.00 / 60.00 |

At matched Train N and fixed Test, exact-twin removal versus non-twin removal lowers mean R² by 0.0264–0.0406 and raises mean RMSE by 0.889–1.365 MPa across both feature schemas, models and fractions. Individual split effects include zero/positive R² differences; all are retained. This supports a measurable contribution of exact twins to within-table evaluation under these specified learners. It does not establish population prevalence or invalidate all high-performing models in the subfield.

| Test fraction | Features | Model | ΔR² mean ± split SD | ΔRMSE mean (MPa) | R² loss seeds |
|---|---|---|---:|---:|---:|
| 20% | Chu7 | ET300 | -0.0287 ± 0.0293 | +1.068 | 47/50 |
| 20% | Chu7 | RF300 | -0.0280 ± 0.0359 | +0.983 | 47/50 |
| 20% | stored11 | ET300 | -0.0271 ± 0.0266 | +1.026 | 46/50 |
| 20% | stored11 | RF300 | -0.0264 ± 0.0344 | +0.889 | 46/50 |
| 30% | Chu7 | ET300 | -0.0406 ± 0.0369 | +1.365 | 48/50 |
| 30% | Chu7 | RF300 | -0.0399 ± 0.0424 | +1.352 | 48/50 |
| 30% | stored11 | ET300 | -0.0384 ± 0.0333 | +1.346 | 47/50 |
| 30% | stored11 | RF300 | -0.0378 ± 0.0393 | +1.248 | 48/50 |

Test strata were defined from the original row-random Train/Test partition and held fixed under both removals. On Test rows with a complete twin in the original Train, twin removal increased mean RMSE by 3.142–5.202 MPa relative to equal-size non-twin removal across the eight configurations. On the remaining Test rows, the mean increase was 0.146–0.502 MPa; 13–26 of 50 splits per configuration instead improved. Mean twin-stratum Test N was 10.52 at 20% Test and 14.20 at 30%; each stratum's membership was identical under both removals. Thus the larger deterioration is concentrated in previously twin-exposed Test rows, while effects elsewhere are smaller and heterogeneous. Subgroup R² uses its own target variance, and subgroup R²/RMSE changes are not additive components of the overall score.

| Test fraction | Features | Model | Twin ΔRMSE ± split SD (MPa) | Non-twin ΔRMSE ± split SD (MPa) | Non-twin RMSE improvement splits |
|---|---|---|---:|---:|---:|
| 20% | stored11 | RF300 | +3.150 ± 2.160 | +0.146 ± 0.821 | 26/50 |
| 20% | stored11 | ET300 | +3.817 ± 2.047 | +0.189 ± 0.655 | 24/50 |
| 20% | Chu7 | RF300 | +3.142 ± 2.197 | +0.235 ± 0.862 | 21/50 |
| 20% | Chu7 | ET300 | +4.112 ± 2.126 | +0.148 ± 0.605 | 21/50 |
| 30% | stored11 | RF300 | +4.027 ± 2.523 | +0.385 ± 0.735 | 15/50 |
| 30% | stored11 | ET300 | +4.923 ± 2.389 | +0.305 ± 0.677 | 17/50 |
| 30% | Chu7 | RF300 | +3.994 ± 2.586 | +0.502 ± 0.804 | 13/50 |
| 30% | Chu7 | ET300 | +5.202 ± 2.509 | +0.255 ± 0.715 | 21/50 |

This fixed-stratum output completes a prespecified reporting item after overall outcomes were available. It was calculated solely from saved predictions, with no new fit, tuning or selected split. All 800 per-seed stratum rows, MAE/R² details and reverse effects are retained and independently rescored. The original runner's arm-specific exposure flags are not used to redefine the Test strata after purging.

The original input-group arm uses stored eleven-input keys for both feature schemas. It must not be called seven-input-disjoint when evaluated with seven features. An explicit, separately frozen amendment evaluates groups defined by the actual seven model inputs (83 groups). Its 200 additional fits retain the same fractions, seeds and tree parameters; no seven-input train–test matches remain. Means and the continued high-score counterexamples are:

| Test fraction | Model | True seven-input groups | R² ≥ 0.95 seeds |
|---|---|---:|---:|
| 20% | ET300 | 0.8505 ± 0.1213 | 8/50 |
| 20% | RF300 | 0.7943 ± 0.1882 | 6/50 |
| 30% | ET300 | 0.8481 ± 0.0994 | 5/50 |
| 30% | RF300 | 0.7786 ± 0.1840 | 3/50 |

All 2,200 fitted prediction groups were independently rescored from saved predictions, and frozen split membership, equal-size controls, removed-twin identities, source byte hashes, and amendment hashes were verified. Means, SDs and split percentiles describe split sensitivity of this fixed table; repeated splits are not 50 new independent datasets and are not used as a population confidence interval. The older source-held-out experiment uses a partially traced 143-row assessment cohort and different unit assumptions, and remains a separate analysis. The 41-row mixed-age external stress test also remains separate and is not independent 28-day physical validation.


Figures: `figures/graded_lineage.svg`, `figures/matched_twin_intervention.svg`, `figures/split_sensitivity.svg`. Full per-publication primary references and access status: `LINEAGE_REGISTRY.md` and `PUBLICATION_REGISTRY.json`.
