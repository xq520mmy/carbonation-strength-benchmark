"""Build a bounded, evidence-graded publication registry; never infer independence from N."""
from pathlib import Path
import csv, json, hashlib

HERE = Path(__file__).resolve().parent
PROBE = HERE.parents[4] / 'C1_crossdb_audit' / 'probe'

def item(key, doi, title, scope, n, relationship, evidence, source, **kw):
    return dict(id=key, doi=doi, title=title, scope=scope, strength_n=n,
                anchor_relationship=relationship, evidence_grade=evidence,
                primary_url=source, **kw)

records = [
item('Chu2025','10.1016/j.cscm.2025.e04589',
 'Explainable machine learning model for predicting compressive strength of CO2-cured concrete',
 'main_compilation',198,'same-table','exact_numeric_rows',
 'https://doi.org/10.1016/j.cscm.2025.e04589',
 source_reference_count=26, split='row-random 80/20; grid search with CV', reported_test_metric='RF R2=0.9709; GBRT=0.9696; XGB=0.9594',
 raw_table='sources/Chu2025_official_mmc1.xlsx',
 basis='Official supplementary table: 198 rows, 12 numeric measurements after dropping serial. Anchor full-row multiset identity.',
 access='fulltext_and_official_table', first_public_date_status='2025; exact online date not re-extracted'),
item('Wang2026','10.3390/buildings16010089',
 'Explainable AutoML with Uncertainty Quantification for CO2-Cured Concrete Compressive Strength Prediction',
 'main_compilation',198,'indeterminate','probable_same_table_printed_signature',
 'https://www.mdpi.com/2075-5309/16/1/89',
 source_reference_count=None,split='80/20; target-stratified fivefold training CV',reported_test_metric='TabPFN R2=0.959',
 raw_table=None, basis='Matching N, schema, extensive printed moments/extrema strongly suggest the anchor. No raw table was recovered. Cement SD printed 171.18 differs from Chu 171.8; the old claim that ddof explains every difference is withdrawn.',
 access='fulltext; raw data on request',first_public_date='2025-12-24',issue_year=2026),
item('AlsharedahWani2026','10.1038/s41598-026-56278-y',
 'Explainable ensemble machine learning framework with particle swarm optimization for predicting compressive strength of CO2-cured concrete',
 'main_compilation',198,'same-table','exact_numeric_rows',
 'https://www.nature.com/articles/s41598-026-56278-y',
 source_reference_count=26,source_count_caveat='26 initially reviewed studies, not a verified count of contributors to the final table',
 split='row-random 70/30; tenfold CV',reported_test_metric='RF R2=0.955',raw_table='../../public_source_recovery_20261002/1-s2.0-S2214509525003870-mmc1.xlsx',
 deposit_doi='10.17632/2myr3k8n4g.1',
 basis='Public deposit and recovered supplemental table are byte-identical. All 2376 numeric cells match original Chu official supplement, in the same row order, after documented header mapping; source file bytes differ.',
 access='fulltext_and_public_table',first_public_date='2026-06-26'),
item('Han2026','10.1186/s40069-026-00956-8',
 'Machine Learning-Based Prediction of Compressive Strength and CO2 Uptake in CO2-Cured Cementitious Materials',
 'main_compilation',423,'indeterminate','different_full_compilation',
 'https://link.springer.com/article/10.1186/s40069-026-00956-8',
 source_reference_count=15, uptake_n=131,split='row-random 80/20', reported_test_metric='Correlation r>0.95; not reported R2',raw_table=None,
 basis='423 strength records, 131 separate uptake records, chemistry/preconditioning schema. Different complete compilation from the 198-row anchor; raw partial overlap and independent experimental-origin counts unresolved. Own mortar validation is a separate cohort.',
 access='fulltext; no complete machine-readable compiled table recovered'),
item('Hilaloglu2026','10.1016/j.cscm.2026.e05910',
 'Machine learning-based prediction of the compressive strength of CO2-cured concrete: Benchmarking and SHAP interpretability',
 'main_compilation',280,'indeterminate','declared_source_overlap',
 'https://doi.org/10.1016/j.cscm.2026.e05910',
 source_reference_count=25,source_count_caveat='25 reference entries [28,31-54], including two ML compilations, are not 25 independent experimental studies',
 split='row-random 80/20; tenfold training CV', reported_test_metric='Ensemble R2 range 0.950-0.963',raw_table=None,
 author_fulltext_url='https://www.researchgate.net/publication/400948728_Machine_Learning-Based_Prediction_of_the_Compressive_Strength_of_CO-Cured_Concrete_Benchmarking_and_SHAP_Interpretability',
 basis='Author-posted full text explicitly declares data-source references [28,31-54], including Chu as [54]. Numerous named original sources overlap. This establishes compilation dependency/source overlap, not row membership. N=280 and printed range differ. Original numeric rows remain unavailable.',
 access='author full text read; official repository PDF response was 212-byte HTML, retained as BLOCKED'),
item('ChoKim2026','10.4334/JKCI.2026.38.1.091',
 'Development of a Tree-Based Machine Learning Model for Predicting the Compressive Strength of Accelerated Carbonation-Cured Cementitious Composites',
 'main_compilation',333,'indeterminate','declared_source_overlap',
 'https://www.jkci.or.kr/jkci/XmlViewer/f450880',
 institutional_indexed_doi_variant='10.4334/JKCI.2026.38.1.91',source_reference_count=23,
 split='row-random 80/20; fivefold training CV',reported_test_metric='CatBoost R2=0.89; XGB=0.88; RF=0.77; LightGBM=0.68',raw_table=None,
 basis='Official Korean full text and publisher article landing page use DOI suffix .091: 333 records/23 declared sources, includes both Chen-Gao 2019/2020 and Zhang-Shao 2016 source papers also named in Chu. Target moments and age/time schema differ; row-level intersection unknown. Institutional index spelling .91 is retained as a variant, with publisher .091 primary.',
 access='fulltext HTML saved; compiled raw table not recovered'),
item('DaviesZhang2026','10.1007/978-3-032-27698-8_84',
 'Explainable Machine Learning Model for the Prediction of CO2-Cured Concrete Strength',
 'main_compilation',399,'indeterminate','different_full_compilation',
 'https://link.springer.com/chapter/10.1007/978-3-032-27698-8_84',
 publication_type='proceedings_chapter',source_reference_count=37,
 split='80/20; fivefold Bayes search, 100 search repetitions',reported_test_metric='CatBoost R2=0.930',raw_table=None,
 basis='Full OA chapter: 399 observations from 37 articles as declared. Different complete compilation; partial row intersection unresolved. The 2025 HKUST record and 2026 chapter have the same title/authors/N/results and count as one work.',
 linked_version='https://repository.hkust.edu.hk/ir/Record/1783.1-171698',
 version_note='HKUST metadata says Cape Town, 2025-11-05 to 2025-11-07; earlier note saying Hong Kong was incorrect.',
 access='fulltext PDF downloaded',first_public_date_status='2025 conference version / 2026-07-09 publisher chapter'),
item('XuChenLiu2026','10.1016/j.engappai.2026.114441',
 'Prediction and optimization of compressive strength of carbonated cement-based materials using machine learning',
 'main_compilation_broad_process',293,'indeterminate','different_full_compilation',
 'https://www.sciencedirect.com/science/article/abs/pii/S0952197626007220',
 source_reference_count=None,split='not verified in accessible abstract',reported_test_metric='XGB R2=0.936',raw_table=None,
 basis='Publisher abstract reports 293 literature records and cube strength, Bayesian ET/RF/XGB/ANN models. The accessible introduction includes both curing and broader post-carbonation mechanical changes; eligibility for a curing-only frame needs full text. Different N proves a nonidentical full compilation, not independent experimental origin.',
 access='publisher abstract read; full text access blocked'),
item('Talip2026','10.1007/s40243-026-00356-8',
 'Enhancing mechanical properties and CO2 capture in mortar using calcium lime waste through dry pre-conditioning and accelerated CO2 curing',
 'main_own_experiment',None,'independent','reported_own_experimental_origin',
 'https://link.springer.com/article/10.1007/s40243-026-00356-8',
 displayed_summary_n=14,source_reference_count=None,split='70/30; exact split algorithm/seed not stated',reported_test_metric='R2 described; numerical strength score not verified',
 raw_table='sources/Talip2026_table2.html',
 basis='Full text explicitly derives ML data from its own mortar tests. Table2 displays 14 composition/curing summaries, of which 9 are CO2-cured and 5 normal; exact number of training records not separately stated. Different material/schema and own origin are documented; this is an independence statement from methods, not forensic proof of zero coincident numeric values.',
 access='fulltext PDF/HTML and official summary table downloaded',first_public_date='2026-02-12'),
item('Padavala2026','10.1007/s41024-026-00847-1',
 'Carbon capture and storage in concrete using fly ash and silica fume: An experimental and machine learning study',
 'main_own_experiment',None,'indeterminate','own_experiment_claim_abstract_only',
 'https://link.springer.com/article/10.1007/s41024-026-00847-1',
 source_reference_count=None,split='not verified',reported_test_metric='ANN R2=0.96; train/test designation not verified',raw_table=None,
 basis='Publisher abstract describes four newly tested mixes under normal and two CO2 regimes, with ANN/SVM/RF performance prediction. Full text unavailable and exact ML training provenance not established. Publisher data-availability statement says no data generated/analysed, inconsistent with abstract; preserve discrepancy and request full text.',
 access='official preview; subscription full text not accessed',first_public_date='2026-06-03'),
item('ChenBiochar2025','10.1016/j.conbuildmat.2025.142734',
 'Utilization of biochar to enhance the sustainability of accelerated carbonation-cured cement-based materials: Effect of biochar dual-particle-size gradation on mechanical properties and carbon sequestration',
 'eligibility_pending_fulltext',None,'indeterminate','own_experiment_ml_target_unresolved',
 'https://www.sciencedirect.com/science/article/abs/pii/S0950061825028855',
 source_reference_count=None,split='not verified',reported_test_metric='not verified',raw_table=None,
 basis='Publisher abstract/highlights describe new ACC mortar experiments and SVR-assisted optimization, but exact SVR target and training cohort cannot be verified from accessible abstract. Retain as potentially eligible; do not exclude because it weakens a reuse claim.',
 access='publisher abstract; full text pending',first_public_date_status='2025; issue 2025-09-12'),
item('CaiMa2025','10.5703/1288284317986',
 'Proportioning and curing optimization of carbonated calcium silicate-based materials via machine learning and genetic algorithm',
 'extended_abstract_sensitivity',None,'indeterminate','abstract_only',
 'https://docs.lib.purdue.edu/c3_2025/2025/carbon/9/',
 publication_type='extended_abstract',source_reference_count=None,split='not verified',reported_test_metric='not reported in accessible abstract',raw_table=None,
 basis='Primary symposium repository describes ensemble predictions of uptake and strength in carbonated calcium-silicate materials. N and original sources unknown. Document type is extended abstract, counted separately from full research articles.',
 access='official repository HTML saved; linked download HTTP403'),
item('HilalogluThesis2026','10.25781/kaust-6gt1y',
 'CO2 Sequestration in Concrete Using Accelerated Carbonation Curing and Dry Ice: Machine Learning Prediction and Experimental Evaluation of Mechanical and Durability Performance',
 'thesis_sensitivity',None,'indeterminate','abstract_only',
 'https://doi.org/10.25781/kaust-6gt1y',
 publication_type='thesis',source_reference_count=None,split='not verified',reported_test_metric='Ensemble test R2>0.95 stated in abstract',raw_table=None,
 basis='Same first author as Hilaloglu journal paper; ML table relationship unverified. Own experimental component in abstract does not prove ML training table is independently compiled. Potential version relationship is flagged, not counted as a proven duplicate publication.',
 access='repository abstract; full text not recovered'),
item('Bawab2026','10.1016/j.mtcomm.2026.116010',
 'Predicting carbon sequestration potential in concrete: A comparative evaluation of advanced machine learning models',
 'boundary_excluded_uptake_only',None,'not_applicable','publisher_abstract',
 'https://doi.org/10.1016/j.mtcomm.2026.116010',
 basis='Predicts CO2 uptake, not compressive strength.',access='abstract'),
item('Rashid2025','10.7717/peerj-cs.3316',
 'Estimating compressive strength of CO2 incorporated concrete with data augmentation and explainable regression modeling',
 'boundary_excluded_mixing_injection',None,'not_applicable','author_abstract',
 'https://peerj.com/articles/cs-3316/',
 basis='CO2 dosage during mixing, not accelerated carbonation curing; excluded by process scope, not by result.',access='author-posted abstract; official page blocked'),
item('ChenCMES2026','10.32604/cmes.2026.089217',
 'Combined Effects of Carbonation and Fly Ash on the Sulfate Resistance of Recycled Aggregate Concrete: Compressive Strength Evolution and CNN-LSTM Prediction',
 'boundary_excluded_aggregate_pretreatment',None,'not_applicable','publisher_fulltext_process',
 'https://www.techscience.com/CMES/v148n3/69015/html',
 reported_specimens=297,reported_mixes=9,reported_test_metric='CNN-LSTM train R2=0.94; test R2=0.93',
 basis='Primary full text Sections 2.2–2.3 describe recycled aggregate carbonated before batching; concrete specimens then undergo standard curing and sulfate wet-dry exposure. Thus this is aggregate pretreatment, outside the frozen concrete/carbonated-composite curing process scope. The 297 physical cubes are not inferred to be the number of ML training rows.',
 access='publisher fulltext HTML read',first_public_date='2026-09-28'),
item('Sun2025','10.1038/s44296-025-00053-z',
 'Machine learning for efficient CO2 sequestration in cementitious materials: a data-driven method',
 'boundary_excluded_depth',None,'not_applicable','initial_inventory_and_publisher',
 'https://www.nature.com/articles/s44296-025-00053-z',
 basis='Carbonation-depth prediction, not strength; a citing paper describing this as strength modelling is not accepted as primary evidence.',access='initial adjacent inventory'),
]

edges = [
 dict(a='Chu2025',b='AlsharedahWani2026',type='exact_same_numeric_table',directed=False,evidence='CHU_WANI_ROW_IDENTITY.json; all 2376 cells, including target'),
 dict(a='Chu2025',b='Wang2026',type='probable_same_table',directed=False,evidence='Printed signature, with explicit cement-SD exception; no raw table'),
 dict(a='Chu2025',b='Hilaloglu2026',type='declared_compilation_source',directed=True,evidence='Hilaloglu data-source list [28,31-54], Chu is [54]; row intersection unknown'),
 dict(a='Chu2025',b='ChoKim2026',type='declared_original_source_overlap',directed=False,evidence='At least 3 explicit data-source title matches: Chen-Gao 2019, Chen-Gao 2020, Zhang-Shao 2016; no row overlap asserted'),
 dict(a='Hilaloglu2026',b='HilalogluThesis2026',type='possible_version_link',directed=False,evidence='Same author/topic; table identity unverified'),
]

summary = dict(search_cutoff='2026-10-05',initial_queries=43,
 confirmed_full_research_works=10,main_compilation_works=8,
 newly_identified_own_experiment_works=2,eligibility_pending_works=1,
 separate_extended_abstracts=1,separate_theses=1,
 distinct_full_compilation_lower_bound=6,distinct_full_compilation_upper_bound=7,
 compilation_bound_frame='8 identified strength-compilation works including Xu broad post-carbonation process scope: six distinct N values; Chu/Wani exact merge; Wang remains uncertain. Not an independent-experimental-study count.',
 curing_only_compilation_works_excluding_Xu_pending=7,
 curing_only_distinct_compilation_lower_bound=5,curing_only_distinct_compilation_upper_bound=6,
 independent_experimental_origins='Exact K not identified; per-table N/source counts and raw overlap are insufficient. Reported own experimental work retained.',
 coverage='Bounded identified literature; not a demonstrated census of all 2025-2026 publications.',
 unverified_suggestion='Sheng author-only lead: no unique title/DOI resolved; not counted as a publication')

def main():
    historical=json.loads((PROBE/'expanded_search.json').read_text())
    known={r['doi'].lower() for r in records}
    for j,r in enumerate(historical['hits_tier_B_adjacent']):
        if r['doi'].lower() in known:continue
        status='boundary_screening_pending'
        basis=r.get('scope_reason','Initial adjacent hit; eligibility unresolved.')
        if r['doi']=='10.1038/s41598-026-36197-8':
            status='boundary_excluded_aggregate_pretreatment'
            basis='Rechecked primary Nature full text: carbonated recycled aggregates are subsequently used in concrete; 108 samples from prior author experiments. Excluded because aggregate pretreatment is outside curing scope, not because experiments are self-generated. Historical exclusion wording is superseded.'
        if r['doi']=='10.3390/buildings16132602':status='boundary_excluded_aggregate_pretreatment'
        if r['doi']=='10.1016/j.cscm.2026.e06381':
            status='boundary_excluded_emission_accounting'
            basis='Newly read publisher abstract: 814 samples for RAC strength/emissions with calculated old-mortar carbonation potential; not a CO2-curing strength cohort.'
        records.append(item('Adjacent_'+str(j+1),r['doi'],r['title'],status,None,'not_applicable' if status.startswith('boundary_excluded') else 'indeterminate',
                            'historical_adjacent_screen_plus_updates','https://doi.org/'+r['doi'],basis=basis,access='Initial evidence retained; updated primary evidence where noted.'))
    (HERE/'PUBLICATION_REGISTRY.json').write_text(json.dumps(dict(summary=summary,records=records,edges=edges),ensure_ascii=False,indent=2))
    columns=['id','doi','scope','strength_n','anchor_relationship','evidence_grade','split','reported_test_metric','access','primary_url','basis']
    with (HERE/'publication_registry.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');w.writeheader();w.writerows(records)
    lines=['# Bounded publication lineage registry','',
           'Search window: 2025-01-01 through 2026-10-05. This registry supersedes the initial inventory’s overconfident independence and all-SD-match notes; it does not delete the historical records.','',
           'Ten confirmed full research works are identified: eight literature-compilation works and two papers with own experimental components. One further experimental/SVR paper remains eligible pending target verification. One extended abstract and one thesis are separate strata. The two versions of Davies–Zhang count once.','',
           'For the eight identified strength-compilation works, including Xu’s broader post-carbonation process scope, the six reported strength-table sizes are 198, 280, 293, 333, 399 and 423. Chu and Alsharedah–Wani are one numerically identical table. Wang is a strong printed-signature match with a retained exception; therefore the number of distinct complete compilations is bounded by 6–7. A curing-only frame that withholds Xu until full-text process verification has seven works and 5–6 complete compilations. Neither bound is **K independent physical experiments** or a count of mutually row-disjoint tables.','',
           '| Work | N strength | Relationship to anchor | Evidence | Access |','|---|---:|---|---|---|']
    for r in records:
        if r['scope'].startswith('boundary'):continue
        n=r['strength_n'] if r['strength_n'] is not None else 'unknown'
        lines.append(f"| [{r['id']}]({r['primary_url']}) | {n} | {r['anchor_relationship']} | {r['evidence_grade']} | {r['access']} |")
    lines+=['','The same-table relationship is symmetric. Publication/deposit chronology does not establish who physically copied a table or prove misconduct. Identical measurements may reflect legitimate reuse, transcription, or repeated reporting; physical specimen identity requires source-level records.','',
            '## Record evidence','']
    for r in records:
        lines += [f"### {r['id']}",'',r['basis'],'',f"Primary reference: [{r['doi']}]({r['primary_url']}).",'']
    (HERE/'LINEAGE_REGISTRY.md').write_text('\n'.join(lines))
    checks=dict(records=len(records),all_ids_unique=len({r['id'] for r in records})==len(records),
                all_main_classified=all(r['anchor_relationship'] in ['same-table','overlap','independent','indeterminate'] for r in records if r['scope'].startswith('main')),
                every_edge_has_evidence=all(e['evidence'] for e in edges),
                no_different_n_called_independent=all(r['anchor_relationship']!='independent' for r in records if r['evidence_grade']=='different_full_compilation'))
    assert all(v for k,v in checks.items() if isinstance(v,bool))
    (HERE/'REGISTRY_QA.json').write_text(json.dumps(dict(status='PASS',**checks),indent=2))
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':main()
