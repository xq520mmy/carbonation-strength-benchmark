"""Independently rescore saved predictions, verify frozen splits, and plot all outcomes."""
from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.lines import Line2D

HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def keys(a):return [tuple(float(v).hex() if v!=0 else '0x0.0p+0' for v in row) for row in a]

def verify():
    # Resolve the anchor relative to portfolio, without importing either fit implementation.
    portfolio=HERE.parents[4]
    data_path=portfolio/'C1_crossdb_audit/probe/data/scirep_MOESM1.xlsx'
    frame=pd.read_excel(data_path)
    frozen=json.loads((HERE/'FROZEN_MANIFEST.json').read_text())
    assert sha(data_path)==frozen['data_sha256']
    assert sha(HERE/'PROTOCOL.md')==frozen['protocol_sha256']
    assert sha(HERE/'run_exact_twin_audit.py')==frozen['code_sha256']
    full=keys(frame.to_numpy());inputs=keys(frame.iloc[:,:-1].to_numpy())
    assert len(set(full))==165 and len(set(inputs))==84
    chu=pd.read_excel(HERE/'sources/Chu2025_official_mmc1.xlsx').drop(columns=['序号']).rename(columns={
        '高炉矿渣':'blast furnace slag','粉煤灰':'fly ash','CCU-蒸养时间':'CCU-steam curing time'})
    assert chu.columns.tolist()==frame.columns.tolist()
    assert np.array_equal(chu.to_numpy(dtype=float),frame.to_numpy(dtype=float))
    assert sorted(pd.Series(full).value_counts().value_counts().to_dict().items())==[(1,132),(2,33)]
    splits={(x['fraction'],x['seed'],x['arm']):x for x in frozen['splits']}
    y=frame.iloc[:,-1].to_numpy()
    metrics=pd.read_csv(HERE/'split_metrics.csv')
    predictions=pd.read_csv(HERE/'predictions.csv')
    max_err=0.;group_overlap=0;groups_checked=0
    def check_scores(p,m):
        nonlocal max_err
        vals=dict(r2=r2_score(p.y,p.prediction),rmse=np.sqrt(mean_squared_error(p.y,p.prediction)),mae=mean_absolute_error(p.y,p.prediction))
        max_err=max(max_err,max(abs(vals[k]-m[k]) for k in vals))
        assert all(abs(vals[k]-m[k])<1e-9 for k in vals)
    idx=metrics.set_index(['fraction','seed','arm','schema','model'])
    for key,p in predictions.groupby(['fraction','seed','arm','schema','model']):
        f,s,a,sc,model=key;sp=splits[f,s,a];tr=sp['train'];te=sp['test']
        assert not set(tr)&set(te)
        assert sorted((p.row_1based-1).tolist())==sorted(te)
        assert np.allclose(p.y.to_numpy(),y[p.row_1based.to_numpy()-1],rtol=0,atol=1e-12)
        actual=[full[i] in {full[j] for j in tr} for i in p.row_1based-1]
        assert actual==p.full_twin_in_train.tolist()
        if a=='full_row_group':assert not set(full[i] for i in tr)&set(full[i] for i in te)
        if a=='input_vector_group':assert not set(inputs[i] for i in tr)&set(inputs[i] for i in te)
        if a=='row_random_purge_twin':assert not any(actual)
        check_scores(p,idx.loc[key]);groups_checked+=1
    for f in (.2,.3):
        for s in range(50):
            original=splits[f,s,'row_random'];purge=splits[f,s,'row_random_purge_twin'];control=splits[f,s,'row_random_size_control']
            assert original['test']==purge['test']==control['test']
            assert len(purge['train'])==len(control['train'])
            assert set(purge['train'])<=set(original['train']) and set(control['train'])<=set(original['train'])
            removed=set(original['train'])-set(purge['train'])
            te_full={full[i] for i in original['test']}
            assert removed=={i for i in original['train'] if full[i] in te_full}
            removed_control=set(original['train'])-set(control['train'])
            assert not any(full[i] in te_full for i in removed_control)
    amend=json.loads((HERE/'CHU7_GROUP_FROZEN.json').read_text())
    assert sha(HERE/'AMENDMENT_01.md')==amend['amendment_sha256']
    assert sha(HERE/'run_chu7_group_sensitivity.py')==amend['code_sha256']
    seven=keys(frame[['C','CA','FA','W/B','T','P','CC']].to_numpy());assert len(set(seven))==83
    for sp in amend['splits']:
        assert not set(seven[i] for i in sp['train'])&set(seven[i] for i in sp['test'])
    extra=pd.read_csv(HERE/'chu7_group_metrics.csv').set_index(['fraction','seed','model'])
    for key,p in pd.read_csv(HERE/'chu7_group_predictions.csv').groupby(['fraction','seed','model']):check_scores(p,extra.loc[key]);groups_checked+=1
    result=dict(status='PASS',rescored_fit_groups=groups_checked,max_metric_absolute_error=max_err,
                all_fixed_test_and_matched_train_sizes=True,all_split_index_checks=True,
                exact_duplicate_groups=33,full_unique_rows=165,stored11_unique_inputs=84,Chu7_unique_inputs=83,
                original_and_amendment_hashes_unchanged=True,original_Chu_and_deposit_2376_numeric_cells_identical=True)
    (HERE/'INDEPENDENT_RESULTS_QA.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))

def plot():
    figdir=HERE/'figures';figdir.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    m=pd.read_csv(HERE/'split_metrics.csv');p=pd.read_csv(HERE/'paired_twin_intervention.csv')
    fig,axs=plt.subplots(1,2,figsize=(11,4.2))
    for ax,frac in zip(axs,[.2,.3]):
        ss=p[p.fraction==frac]
        labels=[]
        for i,(schema,model) in enumerate([('stored11','RF300'),('stored11','ET300'),('Chu7','RF300'),('Chu7','ET300')]):
            v=ss[(ss.schema==schema)&(ss.model==model)].r2_twin_removal_minus_size_control.to_numpy()
            x=np.linspace(i-.18,i+.18,len(v));ax.scatter(x,v,s=10,color='#4a7497',alpha=.43)
            ax.scatter(i,v.mean(),marker='D',s=38,color='#b84742',zorder=3)
            labels.append(f'{schema}\n{model[:-3]}')
        ax.axhline(0,color='#555',ls='--',lw=1);ax.set_xticks(range(4),labels)
        ax.set_title(f'Test fraction {frac:.0%} ({40 if frac==.2 else 60} fixed rows)')
        ax.set_ylabel(r'$R^2$: twin removal minus equal-size control')
    fig.suptitle('Removing known twins reduces accuracy at matched training size',fontsize=13)
    fig.text(.5,.015,'Each dot is one of 50 prespecified splits; diamonds are means. Split variability is not an independent-population CI.',ha='center',fontsize=8)
    fig.tight_layout(rect=[0,.05,1,.94]);fig.savefig(figdir/'matched_twin_intervention.png',dpi=220);fig.savefig(figdir/'matched_twin_intervention.svg');plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(10.7,4.4))
    arms=['row_random','full_row_group','input_vector_group']
    for ax,frac in zip(axs,[.2,.3]):
        sm=m[(m.fraction==frac)&(m.schema=='stored11')]
        low=0
        for j,model in enumerate(['RF300','ET300']):
            color=['#1f77b4','#9467bd'][j]
            means=[sm[(sm.model==model)&(sm.arm==a)].r2.mean() for a in arms]
            ax.plot(np.arange(3)+(.07 if j else -.07),means,'o-',label=model[:-3],lw=1.3,color=color)
            for i,a in enumerate(arms):
                vals=sm[(sm.model==model)&(sm.arm==a)].r2
                q=vals.quantile([.025,.975]).to_numpy()
                low=min(low,float(q[0]))
                ax.plot([i+(.07 if j else -.07)]*2,q,alpha=.6,lw=1.3,color=color)
        ax.axhline(.95,color='#666',ls='--',lw=1);ax.set_ylim(low-.05,1.04)
        ax.set_xticks(range(3),['Row random','Full-row groups','11-input groups'])
        ax.set_title(f'{frac:.0%} nominal test fraction');ax.set_ylabel(r'$R^2$');ax.legend()
    fig.suptitle('High scores remain possible without exact full-row twins',fontsize=13)
    fig.text(.5,.015,'Points: means; bars: 2.5th–97.5th split percentiles (50 seeds). Grouped Test sizes and cohorts differ.',ha='center',fontsize=8)
    fig.tight_layout(rect=[0,.05,1,.94]);fig.savefig(figdir/'split_sensitivity.png',dpi=220);fig.savefig(figdir/'split_sensitivity.svg');plt.close(fig)
    # Draw relationships only where evidence exists; lack of an edge is not independence.
    fig,ax=plt.subplots(figsize=(12,7));ax.set_xlim(0,12);ax.set_ylim(0,7);ax.axis('off')
    positions={'Chu2025':(1.7,5.2),'AlsharedahWani2026':(5.4,5.2),'Wang2026':(9.6,5.2),'Hilaloglu2026':(1.7,3.6),'ChoKim2026':(5.4,3.6),'Han2026':(9.6,3.6),'XuChenLiu2026':(1.7,2.05),'DaviesZhang2026':(5.4,2.05),'Talip2026':(9.6,2.05)}
    labels={'Chu2025':'Chu 2025\n198 rows; official table','AlsharedahWani2026':'Alsharedah–Wani 2026\n198 rows; public table','Wang2026':'Wang 2026 issue\n198 rows; probable match','Hilaloglu2026':'Hilaloglu 2026\n280; Chu declared source','ChoKim2026':'Cho–Kim 2026\n333; original-source overlap','Han2026':'Han 2026\n423; row overlap unknown','XuChenLiu2026':'Xu–Chen–Liu 2026\n293; broader process scope\nCuring-only eligibility pending','DaviesZhang2026':'Davies–Zhang 2026\n399; row overlap unknown','Talip2026':'Talip 2026\nOwn mortar experiments'}
    nodes={}
    for k,(x,y) in positions.items():
        face='#dfeee7' if k=='Talip2026' else ('#e0edf7' if k in ['Chu2025','AlsharedahWani2026'] else '#f1f0ec')
        nodes[k]=FancyBboxPatch((x-1.4,y-.37),2.8,.74,boxstyle='round,pad=.05',facecolor=face,edgecolor='#637380',lw=1,zorder=3)
        ax.add_patch(nodes[k])
        ax.text(x,y,labels[k],ha='center',va='center',fontsize=9,zorder=4)
    styles={'exact_same_numeric_table':('#24587d','-',2.1),'probable_same_table':('#b08126','--',1.6),'declared_compilation_source':('#777',':',1.7),'declared_original_source_overlap':('#777',':',1.7)}
    reg=json.loads((HERE/'PUBLICATION_REGISTRY.json').read_text())
    for e in reg['edges']:
        if e['a'] not in positions or e['b'] not in positions:continue
        c,ls,lw=styles[e['type']];a=positions[e['a']];b=positions[e['b']]
        rad=.25 if e['b']=='Wang2026' else (-.18 if e['b']=='ChoKim2026' else 0)
        ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>' if e['directed'] else '-',connectionstyle=f'arc3,rad={rad}',color=c,linestyle=ls,lw=lw,patchA=nodes[e['a']],patchB=nodes[e['b']],shrinkA=2,shrinkB=2,zorder=2,mutation_scale=12))
    ax.set_title('Bounded data relationships in carbonation-curing strength ML',fontsize=15,pad=12)
    handles=[Line2D([0],[0],color='#24587d',lw=2,label='Exact numeric table identity'),Line2D([0],[0],color='#b08126',ls='--',lw=1.6,label='Probable printed-statistic match'),Line2D([0],[0],color='#777',ls=':',lw=1.7,label='Declared source relationship; rows unknown')]
    ax.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.18),ncol=1,frameon=False,fontsize=9)
    ax.text(6,.22,'Also retained: Padavala (own-experiment abstract; provenance unresolved), Chen biochar (eligibility pending),\nCai–Ma extended abstract, and Hilaloglu thesis. All details in registry. No edge does not mean independence.',ha='center',va='center',fontsize=8)
    fig.tight_layout();fig.savefig(figdir/'graded_lineage.png',dpi=220);fig.savefig(figdir/'graded_lineage.svg');plt.close(fig)

if __name__=='__main__':verify();plot()
