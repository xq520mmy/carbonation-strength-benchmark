#!/usr/bin/env python3
"""Frozen, exhaustive exact-twin sensitivity matrix; writes only HERE."""
from __future__ import annotations
import os
for v in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ.setdefault(v, '1')
import sys, json, hashlib, platform, time
from pathlib import Path
from collections import Counter
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from joblib import Parallel, delayed

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if p.name == 'pub_portfolio_20260916')
DATA = ROOT/'C1_crossdb_audit/probe/data/scirep_MOESM1.xlsx'
COPY = HERE.parents[1]/'public_source_recovery_20261002/1-s2.0-S2214509525003870-mmc1.xlsx'
SEEDS = list(range(50))
FEATURES = {
    'stored11': ['C','CA','FA','W','blast furnace slag','fly ash','W/B','CCU-steam curing time','T','CC','P'],
    'Chu7': ['C','CA','FA','W/B','T','P','CC'],
}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rowkey(row):
    return '|'.join(float(0.0 if float(x) == 0 else x).hex() for x in row)
def keys(a): return np.array([hashlib.sha256(rowkey(r).encode()).hexdigest() for r in a])
def metrics(y, p):
    return {'r2': float(r2_score(y,p)) if len(y)>1 and np.var(y)>0 else None,
            'rmse':float(np.sqrt(mean_squared_error(y,p))), 'mae':float(mean_absolute_error(y,p))}

def main():
    started=time.time()
    df=pd.read_excel(DATA)
    assert df.shape == (198,12) and df.columns[-1] == 'CS'
    assert np.isfinite(df.to_numpy(float)).all()
    dfcopy=pd.read_excel(COPY)
    assert list(dfcopy.columns)==list(df.columns) and np.array_equal(df.to_numpy(),dfcopy.to_numpy())
    full=keys(df.to_numpy(float)); inp=keys(df.iloc[:,:-1].to_numpy(float))
    counts=Counter(full); groups={k:np.flatnonzero(full==k).tolist() for k,v in counts.items() if v>1}
    identity={'data_sha256':sha(DATA),'public_copy_sha256':sha(COPY),'source_copies_byte_identical':sha(DATA)==sha(COPY),
       'canonical_table_multiset_sha256':hashlib.sha256('\n'.join(sorted(full)).encode()).hexdigest(),
       'rows':len(df),'full_unique':len(counts),'input_unique':len(set(inp)),
       'duplicate_groups':len(groups),'participating_rows':sum(len(v) for v in groups.values()),
       'redundant_rows':sum(len(v)-1 for v in groups.values()),
       'unordered_pairs':sum(len(v)*(len(v)-1)//2 for v in groups.values()),
       'group_size_distribution':dict(Counter(map(len,groups.values()))),
       'identity_caveat':'Identical reported measurements are not proof of identical physical specimens.'}
    assert identity['group_size_distribution']=={2:33}
    pairs=[]
    for k,ii in groups.items():
        for i in ii:
            pairs.append({'row_1based':i+1,'full_row_sha256':k,'twin_rows_1based':','.join(str(j+1) for j in ii if j!=i),**df.iloc[i].to_dict()})
    pd.DataFrame(pairs).to_csv(HERE/'exact_duplicate_rows.csv',index=False)
    pd.DataFrame({'row_1based':np.arange(1,199),'full_row_sha256':full,'input_vector_sha256':inp}).to_csv(HERE/'row_hashes.csv',index=False)
    (HERE/'DATA_IDENTITY.json').write_text(json.dumps(identity,indent=2))
    configs=[]
    for frac in (0.2,0.3):
        for seed in SEEDS:
            tr,te=train_test_split(np.arange(198),test_size=frac,random_state=seed)
            twins=np.isin(full[tr],full[te]); purge=tr[~twins]
            rng=np.random.default_rng(seed+100000)
            remove=rng.choice(tr[~twins],size=int(twins.sum()),replace=False)
            control=tr[~np.isin(tr,remove)]
            assert len(purge)==len(control) and len(purge)>0
            assert not np.isin(full[purge],full[te]).any()
            arms={'row_random':(tr,te),'row_random_purge_twin':(purge,te),'row_random_size_control':(control,te)}
            for name,g in [('full_row_group',full),('input_vector_group',inp)]:
                a,b=next(GroupShuffleSplit(n_splits=1,test_size=frac,random_state=seed).split(df,groups=g))
                assert not np.isin(g[a],g[b]).any()
                arms[name]=(a,b)
            for name,(a,b) in arms.items():
                configs.append({'fraction':frac,'seed':seed,'arm':name,'train':a.tolist(),'test':b.tolist()})
    frozen={'status':'FROZEN_BEFORE_MODEL_FITS','protocol_sha256':sha(HERE/'PROTOCOL.md'),
       'code_sha256':sha(Path(__file__)),'data_sha256':sha(DATA),
       'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,
       'seeds':SEEDS,'features':FEATURES,'models':{'RF300':{'n_estimators':300,'n_jobs':1},'ET300':{'n_estimators':300,'n_jobs':1}},
       'splits':configs,'limitations':'Historical data exposure; repeated-split variability is not an independent-population CI.'}
    (HERE/'FROZEN_MANIFEST.json').write_text(json.dumps(frozen,indent=2))
    rates=[]
    dup=np.array([counts[k]>1 for k in full])
    for frac in (0.2,0.3):
        rr=[]
        for seed in range(10000):
            a,b=train_test_split(np.arange(198),test_size=frac,random_state=seed)
            rr.append(float(np.isin(full[b],full[a]).mean()))
        n=int(np.ceil(198*frac)); expect=66/198*(198-n)/197
        rates.append({'fraction':frac,'test_n':n,'expected_test_twin_rate':expect,'simulation_mean':float(np.mean(rr)),
                      'simulation_sd':float(np.std(rr)),'split_variability_2.5_97.5':np.quantile(rr,[.025,.975]).tolist()})
    (HERE/'TWIN_RATE.json').write_text(json.dumps(rates,indent=2))
    y=df.CS.to_numpy(float)
    tasks=[(c,fn,mn) for c in configs for fn in FEATURES for mn in ('RF300','ET300')]
    def fit_one(c,fn,mn):
        a=np.array(c['train']); b=np.array(c['test']); X=df[FEATURES[fn]].to_numpy(float)
        mk=RandomForestRegressor if mn=='RF300' else ExtraTreesRegressor
        m=mk(n_estimators=300,random_state=c['seed'],n_jobs=1);m.fit(X[a],y[a]);p=m.predict(X[b])
        seen=np.isin(full[b],full[a]); inseen=np.isin(inp[b],inp[a]); d=dup[b]
        out={k:c[k] for k in ('fraction','seed','arm')};out.update({'schema':fn,'model':mn,'train_n':len(a),'test_n':len(b),
            'test_full_twin_n':int(seen.sum()),'test_full_twin_rate':float(seen.mean()),
            'test_input_seen_rate':float(inseen.mean()),'duplicate_group_test_n':int(d.sum()),
            'duplicate_group_test_twin_rate':float(seen[d].mean()) if d.any() else None,**metrics(y[b],p)})
        pred=[{**{k:out[k] for k in ('fraction','seed','arm','schema','model')},'row_1based':int(i+1),'y':float(y[i]),'prediction':float(q),
               'full_twin_in_train':bool(s),'input_seen_in_train':bool(t),'belongs_to_full_duplicate_group':bool(g)}
              for i,q,s,t,g in zip(b,p,seen,inseen,d)]
        for name,mask in [('full_twin',seen),('no_full_twin',~seen)]:
            if mask.any():
                out.update({name+'_'+k:v for k,v in metrics(y[b][mask],p[mask]).items()})
        return out,pred
    result=Parallel(n_jobs=6,verbose=10)(delayed(fit_one)(*t) for t in tasks)
    scores=pd.DataFrame([r[0] for r in result]);scores.to_csv(HERE/'split_metrics.csv',index=False)
    pd.DataFrame([p for r in result for p in r[1]]).to_csv(HERE/'predictions.csv',index=False)
    ag=[]
    for kk,g in scores.groupby(['fraction','schema','model','arm'],sort=True):
        r=dict(zip(['fraction','schema','model','arm'],kk));r['n_seeds']=len(g)
        for col in ('r2','rmse','mae','train_n','test_n','test_full_twin_rate','test_input_seen_rate'):
            a=g[col].to_numpy(float);r[col+'_mean']=float(np.mean(a));r[col+'_sd']=float(np.std(a,ddof=1))
            r[col+'_split_p025']=float(np.quantile(a,.025));r[col+'_split_p975']=float(np.quantile(a,.975))
        r['r2_ge_095_n']=int((g.r2>=.95).sum());ag.append(r)
    pd.DataFrame(ag).to_csv(HERE/'aggregate_metrics.csv',index=False)
    paired=[]
    base=scores[scores.arm=='row_random'].set_index(['fraction','seed','schema','model'])
    purge=scores[scores.arm=='row_random_purge_twin'].set_index(['fraction','seed','schema','model'])
    ctl=scores[scores.arm=='row_random_size_control'].set_index(['fraction','seed','schema','model'])
    for k in base.index:
        paired.append(dict(zip(['fraction','seed','schema','model'],k),test_n=int(base.loc[k,'test_n']),
            purged_n=int(base.loc[k,'train_n']-purge.loc[k,'train_n']),
            r2_twin_removal_minus_size_control=float(purge.loc[k,'r2']-ctl.loc[k,'r2']),
            rmse_twin_removal_minus_size_control=float(purge.loc[k,'rmse']-ctl.loc[k,'rmse']),
            r2_twin_removal_minus_original=float(purge.loc[k,'r2']-base.loc[k,'r2'])))
    pd.DataFrame(paired).to_csv(HERE/'paired_twin_intervention.csv',index=False)
    qa={'status':'COMPLETE','n_model_fits':len(result),'n_prediction_rows':sum(len(r[1]) for r in result),
        'protocol_sha256':sha(HERE/'PROTOCOL.md'),'code_sha256':sha(Path(__file__)),'elapsed_seconds':time.time()-started,
        'all_grouped_full_twin_rates_zero':bool((scores[scores.arm.isin(['full_row_group','input_vector_group','row_random_purge_twin'])].test_full_twin_rate==0).all()),
        'all_matched_control_train_n_equal':bool((purge.train_n==ctl.train_n).all())}
    assert qa['all_grouped_full_twin_rates_zero'] and qa['all_matched_control_train_n_equal']
    (HERE/'RUN_QA.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa),flush=True)

if __name__=='__main__':main()
