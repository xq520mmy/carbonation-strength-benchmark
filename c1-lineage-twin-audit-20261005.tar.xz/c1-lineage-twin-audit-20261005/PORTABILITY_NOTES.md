# Portability limits and verification distinctions

The original fixed-Test producer ran on Python 3.9.6. Under the existing QA Python 3.11.15, its unchanged `--verify-only` command passes membership/source gates and produces byte-identical `fixed_test_strata_metrics.csv`, with matching source-code and every input SHA. Its last strict assertion compares whole summary dictionaries for bit-exact equality and fails on six `statistics.stdev` last-bit differences. The maximum difference is 2.220446049250313e-16, confined to six SD values:

| Summary cell index in saved JSON | Metric | Absolute SD difference |
|---:|---|---:|
| 1 | RMSE | 1.1102230246251565e-16 |
| 5 | MAE | 5.551115123125783e-17 |
| 7 | R² | 3.469446951953614e-18 |
| 7 | MAE | 5.551115123125783e-17 |
| 10 | MAE | 2.220446049250313e-16 |
| 14 | R² | 5.551115123125783e-17 |

This is an observed cross-runtime strict-equality limitation, not a passing historical command. No original code, freeze, CSV or QA JSON was altered. The separately identified independent portable verifier recomputes all 800 row metrics/differences and all 16 summary cells with a stated 1e-12 absolute numerical tolerance, and exact memberships, counts and signs. Use its source-bound PASS for portable saved-result verification. Re-running the original producer on a different Python can expose this last-bit limitation even when the scientific data and CSV bytes agree.

Frozen fitting used NumPy 2.0.2 while actual no-fit QA used 2.4.6. Requirements retain the known frozen numerical pins and separately identify auxiliary versions; the pinned stack was not newly installed or tested as an environment during staging. No claim of bit-identical refitting across Python, NumPy, operating system or architecture is made.

The source scan excludes original raw publisher materials and private search metadata. The registry can be regenerated from the included minimal derived screening input, whose distinct source and derived hashes are recorded. Scientific judgments in that registry are not independently re-established by machine checks: unresolved eligibility, source access and source overlap remain unresolved.
