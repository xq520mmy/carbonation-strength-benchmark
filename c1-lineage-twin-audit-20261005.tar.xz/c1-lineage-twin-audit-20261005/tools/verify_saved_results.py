#!/usr/bin/env python3
"""Independent portable verification of frozen saved outcomes; never imports fit code.

Default: saved-file integrity, all 2200 prediction groups, frozen splits, aggregate
and paired metrics, 800 fixed strata, and publication-registry structure.
--bind-workbooks additionally verifies source bytes, all row/input keys, target
labels, exact numeric cross-provider identity and true seven-input disjointness.
Writes nothing; emit JSON to stdout, optionally redirect outside sealed inputs.
"""
from pathlib import Path
from collections import Counter
import argparse, hashlib, json, math, sys
import numpy as np
import pandas as pd

REL=Path('pub_portfolio_20260916/_shared/revision_20260921/C1/experiments/lineage_20261005')
ARMS=('row_random','row_random_purge_twin','row_random_size_control','full_row_group','input_vector_group')
SCHEMAS=('stored11','Chu7');MODELS=('RF300','ET300')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(v,msg):
    if not v:raise AssertionError(msg)
def canonical(a):
    return [hashlib.sha256('|'.join(float(0 if x==0 else x).hex() for x in row).encode()).hexdigest() for row in a]
def score(y,p):
    y=np.asarray(y,float);p=np.asarray(p,float);require(len(y)>0,'Empty score group')
    e=y-p;sst=float(np.sum((y-np.mean(y))**2))
    return {'r2':1-float(np.sum(e**2))/sst if len(y)>1 and sst>0 else np.nan,
            'rmse':float(np.sqrt(np.mean(e**2))),'mae':float(np.mean(np.abs(e)))}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--bind-workbooks',action='store_true');args=ap.parse_args()
    root=args.root.resolve();exp=root/REL;max_error=0.;summary_max_error=0.;scalars=0
    def close(a,b,label):
        nonlocal max_error,summary_max_error,scalars
        scalars+=1
        if pd.isna(a) and pd.isna(b):return
        require(math.isfinite(float(a)) and math.isfinite(float(b)),label+' nonfinite mismatch')
        error=abs(float(a)-float(b));max_error=max(max_error,error)
        if label=='Strata summary scalar':summary_max_error=max(summary_max_error,error)
        require(error<=1e-12,label+' metric mismatch')
    load=lambda name:pd.read_csv(exp/name,float_precision='round_trip')
    # New release manifest is distinct from the historical scientific freeze.
    manifest=root/'MANIFEST.sha256';verified_files=0
    if manifest.exists():
        for line in manifest.read_text().splitlines():
            digest,rel=line.split('  ',1);p=root/rel
            require(p.is_file() and sha(p)==digest,'Release checksum mismatch: '+rel);verified_files+=1
    source=json.loads((root/'provenance/SOURCE_BYTE_MANIFEST.json').read_text())
    for row in source:require(sha(root/row['release_path'])==row['sha256'],'Historic source bytes changed')
    frozen=json.loads((exp/'FROZEN_MANIFEST.json').read_text());amend=json.loads((exp/'CHU7_GROUP_FROZEN.json').read_text())
    for key,name in [('protocol_sha256','PROTOCOL.md'),('code_sha256','run_exact_twin_audit.py')]:require(sha(exp/name)==frozen[key],'Original frozen seal mismatch')
    for key,name in [('amendment_sha256','AMENDMENT_01.md'),('code_sha256','run_chu7_group_sensitivity.py')]:require(sha(exp/name)==amend[key],'Amendment frozen seal mismatch')
    require(frozen['seeds']==list(range(50)),'Frozen seed coverage')
    rh=load('row_hashes.csv');require(rh.row_1based.tolist()==list(range(1,199)),'Canonical row IDs')
    full=rh.full_row_sha256.tolist();inputs=rh.input_vector_sha256.tolist();counts=Counter(full)
    require(len(counts)==165 and Counter(counts.values())=={1:132,2:33},'Duplicate counts')
    require(len(set(inputs))==84,'Stored input unique count')
    dup=load('exact_duplicate_rows.csv');require(len(dup)==66,'Duplicate participating rows')
    require(set(dup.row_1based)=={i+1 for i,h in enumerate(full) if counts[h]>1},'Duplicate IDs')
    for r in dup.itertuples():
        require(r.full_row_sha256==full[r.row_1based-1],'Duplicate hash')
        twins={i+1 for i,h in enumerate(full) if h==r.full_row_sha256 and i+1!=r.row_1based}
        require(set(int(x) for x in str(r.twin_rows_1based).split(','))==twins,'Duplicate pair IDs')
    splits={(float(s['fraction']),int(s['seed']),s['arm']):s for s in frozen['splits']}
    extra_splits={(float(s['fraction']),int(s['seed'])):s for s in amend['splits']}
    require(set(splits)=={(f,s,a) for f in (.2,.3) for s in range(50) for a in ARMS},'All 500 frozen split keys')
    require(set(extra_splits)=={(f,s) for f in (.2,.3) for s in range(50)},'All 100 amendment split keys')
    seven=None;bound_y=None
    if args.bind_workbooks:
        provider=root/'pub_portfolio_20260916/C1_crossdb_audit/probe/data/scirep_MOESM1.xlsx'
        copy=root/'pub_portfolio_20260916/_shared/revision_20260921/C1/public_source_recovery_20261002/1-s2.0-S2214509525003870-mmc1.xlsx'
        chu=exp/'sources/Chu2025_official_mmc1.xlsx';ident=json.loads((exp/'CHU_WANI_ROW_IDENTITY.json').read_text())
        require(sha(provider)==sha(copy)==frozen['data_sha256']==amend['data_sha256'],'Provider byte binding')
        require(sha(chu)==ident['Chu_official_sha256'],'Chu byte binding')
        table=pd.read_excel(provider);official=pd.read_excel(chu).drop(columns=['序号']).rename(columns={'高炉矿渣':'blast furnace slag','粉煤灰':'fly ash','CCU-蒸养时间':'CCU-steam curing time'})
        require(table.shape==(198,12) and table.columns[-1]=='CS','Provider shape')
        require(list(table.columns)==list(official.columns),'Mapped Chu headers')
        numeric=table.to_numpy(float);require(np.isfinite(numeric).all(),'Finite source')
        require(np.array_equal(numeric,official.to_numpy(float)),'2376-cell source identity')
        require(canonical(numeric)==full and canonical(numeric[:,:-1])==inputs,'All 198 canonical source hashes')
        seven=canonical(table[['C','CA','FA','W/B','T','P','CC']].to_numpy(float));require(len(set(seven))==83,'Seven-input groups')
        bound_y=numeric[:,-1]
        require(np.array_equal(dup[list(table.columns)].to_numpy(float),numeric[dup.row_1based.to_numpy()-1]),'Duplicate numeric rows source binding')
    for (f,s,a),sp in splits.items():
        tr=sp['train'];te=sp['test'];require(len(set(tr))==len(tr) and len(set(te))==len(te),'Unique split indices')
        require(set(tr).isdisjoint(te) and set(tr+te)<=set(range(198)),'Valid split indices')
        if a not in ARMS[1:3]:require(set(tr+te)==set(range(198)),'Complete split rows')
        if a=='full_row_group':require(not {full[i] for i in tr}&{full[i] for i in te},'Full-row disjoint')
        if a=='input_vector_group':require(not {inputs[i] for i in tr}&{inputs[i] for i in te},'Stored11-input disjoint')
        if a=='row_random':require(len(te)==(40 if f==.2 else 60),'Fixed Test size')
    for (f,s),sp in extra_splits.items():
        require(set(sp['train']).isdisjoint(sp['test']) and set(sp['train']+sp['test'])==set(range(198)),'Amendment partition')
        require(len(sp['train'])==len(set(sp['train'])) and len(sp['test'])==len(set(sp['test'])),'Amendment unique indices')
        if seven:require(not {seven[i] for i in sp['train']}&{seven[i] for i in sp['test']},'True Chu7 input disjointness')
    membership={}
    for f in (.2,.3):
        for s in range(50):
            base=splits[f,s,'row_random'];purge=splits[f,s,'row_random_purge_twin'];control=splits[f,s,'row_random_size_control']
            require(base['test']==purge['test']==control['test'],'Identical intervention Test order')
            test_hash={full[i] for i in base['test']};train_hash={full[i] for i in base['train']}
            removed={i for i in base['train'] if full[i] in test_hash}
            require(set(purge['train'])==set(base['train'])-removed,'Purged every exact twin')
            require(set(control['train'])<=set(base['train']) and removed<=set(control['train']),'Control retains all twins')
            require(len(purge['train'])==len(control['train']),'Matched Train N')
            membership[f,s]={'twin':[i for i in base['test'] if full[i] in train_hash],'non_twin':[i for i in base['test'] if full[i] not in train_hash]}
    pred=load('predictions.csv');metrics=load('split_metrics.csv');extra=load('chu7_group_predictions.csv');extra_metrics=load('chu7_group_metrics.csv')
    require(len(pred)==100752 and len(metrics)==2000 and len(extra_metrics)==200,'Saved matrix dimensions')
    labels={}
    for rows in (pred,extra):
        require(np.isfinite(rows[['y','prediction']].to_numpy()).all(),'Finite saved predictions')
        for row,y in rows[['row_1based','y']].drop_duplicates().itertuples(index=False,name=None):
            if row in labels:close(y,labels[row],'Cross-group target identity')
            else:labels[row]=y
            if bound_y is not None:close(y,bound_y[int(row)-1],'Target source binding')
    require(set(labels)==set(range(1,199)),'Complete saved target coverage')
    idx=metrics.set_index(['fraction','seed','arm','schema','model']);require(idx.index.is_unique,'Metric keys unique')
    grouped={};checked=0
    for key,g in pred.groupby(['fraction','seed','arm','schema','model']):
        f,s,a,sc,m=key;require(sc in SCHEMAS and m in MODELS,'Model/schema')
        sp=splits[f,s,a];rows=g.row_1based.to_numpy()-1;require(len(set(rows))==len(rows) and set(rows)==set(sp['test']),'Prediction Test IDs')
        r=idx.loc[key];require(r.train_n==len(sp['train']) and r.test_n==len(sp['test']),'Saved split counts')
        train_hash={full[i] for i in sp['train']};input_hash={inputs[i] for i in sp['train']}
        seen=np.array([full[i] in train_hash for i in rows]);input_seen=np.array([inputs[i] in input_hash for i in rows]);duplicate=np.array([counts[full[i]]>1 for i in rows])
        require(np.array_equal(seen,g.full_twin_in_train.to_numpy()) and np.array_equal(input_seen,g.input_seen_in_train.to_numpy()) and np.array_equal(duplicate,g.belongs_to_full_duplicate_group.to_numpy()),'Saved exposure flags')
        for name,value in [('test_full_twin_n',seen.sum()),('test_full_twin_rate',seen.mean()),('test_input_seen_rate',input_seen.mean()),('duplicate_group_test_n',duplicate.sum()),('duplicate_group_test_twin_rate',seen[duplicate].mean() if duplicate.any() else np.nan)]:close(value,r[name],name)
        for name,value in score(g.y,g.prediction).items():close(value,r[name],name)
        for label,mask in [('full_twin',seen),('no_full_twin',~seen)]:
            if mask.any():
                for name,value in score(g.y.to_numpy()[mask],g.prediction.to_numpy()[mask]).items():close(value,r[label+'_'+name],label+'_'+name)
        grouped[key]=g.set_index('row_1based');checked+=1
    require(checked==2000,'All original prediction groups')
    exidx=extra_metrics.set_index(['fraction','seed','model']);require(exidx.index.is_unique,'Amendment metric keys unique')
    for key,g in extra.groupby(['fraction','seed','model']):
        f,s,m=key;sp=extra_splits[f,s];r=exidx.loc[key]
        require(m in MODELS and set(g.arm)=={'Chu7_input_vector_group'},'Amendment model/arm')
        require(g.row_1based.nunique()==len(g) and set(g.row_1based-1)==set(sp['test']),'Amendment prediction Test IDs')
        require(r.train_n==len(sp['train']) and r.test_n==len(sp['test']) and r.model_input_seen_rate==0,'Amendment sizes/overlap')
        for name,value in score(g.y,g.prediction).items():close(value,r[name],'amend_'+name)
        checked+=1
    require(checked==2200,'All 2200 groups')
    ag=load('aggregate_metrics.csv');require(len(ag)==40,'Aggregate cells')
    for r in ag.to_dict('records'):
        g=metrics[(metrics.fraction==r['fraction'])&(metrics.schema==r['schema'])&(metrics.model==r['model'])&(metrics.arm==r['arm'])]
        require(set(g.seed)==set(range(50)) and len(g)==r['n_seeds']==50,'50 seeds in every aggregate')
        for col in ('r2','rmse','mae','train_n','test_n','test_full_twin_rate','test_input_seen_rate'):
            for suffix,value in [('mean',g[col].mean()),('sd',g[col].std(ddof=1)),('split_p025',g[col].quantile(.025)),('split_p975',g[col].quantile(.975))]:close(value,r[col+'_'+suffix],col+' aggregate')
        require(int((g.r2>=.95).sum())==r['r2_ge_095_n'],'High-score counterexample counts')
    paired=load('paired_twin_intervention.csv');require(len(paired)==400,'Paired contrast coverage')
    for r in paired.itertuples():
        k=(r.fraction,r.seed);base=idx.loc[(*k,'row_random',r.schema,r.model)];a=idx.loc[(*k,'row_random_purge_twin',r.schema,r.model)];b=idx.loc[(*k,'row_random_size_control',r.schema,r.model)]
        require(r.test_n==base.test_n and r.purged_n==base.train_n-a.train_n,'Paired sizes')
        close(a.r2-b.r2,r.r2_twin_removal_minus_size_control,'Paired R2');close(a.rmse-b.rmse,r.rmse_twin_removal_minus_size_control,'Paired RMSE');close(a.r2-base.r2,r.r2_twin_removal_minus_original,'Paired original R2')
    for r in load('paired_summary.csv').itertuples():
        g=paired[(paired.fraction==r.fraction)&(paired.schema==r.schema)&(paired.model==r.model)];v=g.r2_twin_removal_minus_size_control
        require(len(g)==r.n_seeds==50 and int((v<0).sum())==r.loss_seeds,'Paired summary complete')
        for a,b in [(v.mean(),r.delta_r2_mean),(v.std(ddof=1),r.delta_r2_sd),(g.rmse_twin_removal_minus_size_control.mean(),r.delta_rmse_mean),(v.quantile(.025),r.delta_r2_split_p025),(v.quantile(.975),r.delta_r2_split_p975)]:close(a,b,'Paired summary')
    strata=load('fixed_test_strata_metrics.csv');require(len(strata)==800,'Strata row count');require(not strata.duplicated(['fraction','seed','schema','model','fixed_original_test_stratum']).any(),'Unique strata keys')
    for r in strata.to_dict('records'):
        f,s,sc,m,label=r['fraction'],r['seed'],r['schema'],r['model'],r['fixed_original_test_stratum'];ids=[i+1 for i in membership[f,s][label]]
        require([int(x) for x in r['test_rows_1based'].split('|')]==ids,'Original fixed-stratum membership')
        base=splits[f,s,'row_random'];purge=splits[f,s,'row_random_purge_twin']
        require(r['test_n']==len(ids) and r['total_test_n']==len(base['test']) and r['original_train_n']==len(base['train']) and r['matched_train_n']==len(purge['train']),'Stratum count fields')
        scores={}
        for arm in ARMS[:3]:
            g=grouped[f,s,arm,sc,m].loc[ids];scores[arm]=score(g.y,g.prediction)
            for metric,v in scores[arm].items():close(v,r[arm+'_'+metric],'Stratum '+metric)
        for metric in ('r2','rmse','mae'):
            delta=scores[ARMS[1]][metric]-scores[ARMS[2]][metric];close(delta,r['purge_minus_equalN_control_'+metric],'Stratum difference')
            improvement=delta>0 if metric=='r2' else delta<0
            require(improvement==r['purge_improved_'+metric],'Stratum reverse effect')
    for _,g in strata.groupby(['fraction','schema','model','fixed_original_test_stratum']):require(len(g)==50 and set(g.seed)==set(range(50)),'50 seeds in all 16 strata cells')
    fixed_qa=json.loads((exp/'FIXED_TEST_STRATA_QA.json').read_text())
    require(sha(exp/'fixed_test_strata_metrics.csv')==fixed_qa['output_csv_sha256'],'Strata original output seal')
    require(sha(exp/'fixed_test_strata_audit.py')==fixed_qa['source_code_sha256'],'Strata original code seal')
    summary_count=0
    for r in fixed_qa['summary']:
        g=strata[(strata.fraction==r['fraction'])&(strata.schema==r['schema'])&(strata.model==r['model'])&(strata.fixed_original_test_stratum==r['stratum'])]
        require(len(g)==r['n_splits']==50,'Strata summary N')
        close(g.test_n.mean(),r['test_n_mean'],'Strata N mean');close(g.test_n.min(),r['test_n_min'],'Strata N min');close(g.test_n.max(),r['test_n_max'],'Strata N max')
        for metric in ('r2','rmse','mae'):
            v=g['purge_minus_equalN_control_'+metric];a=r['delta_'+metric]
            require(v.notna().sum()==a['defined_n'] and int((v<0).sum())==a['negative_n'] and int((v==0).sum())==a['zero_n'] and int((v>0).sum())==a['positive_n'],'Strata summary signs')
            for value,saved in [(v.mean(),a['mean']),(v.std(ddof=1),a['split_sd']),(v.quantile(.025),a['split_p025']),(v.quantile(.975),a['split_p975'])]:close(value,saved,'Strata summary scalar')
            require(int(g['purge_improved_'+metric].sum())==r['purge_improved_'+metric+'_n'],'Strata summary reverse counts')
        summary_count+=1
    require(summary_count==16,'All fixed-stratum summary cells')
    identity=json.loads((exp/'DATA_IDENTITY.json').read_text())
    require(identity['canonical_table_multiset_sha256']==hashlib.sha256('\n'.join(sorted(full)).encode()).hexdigest(),'Canonical table multiset seal')
    for r in json.loads((exp/'TWIN_RATE.json').read_text()):
        n=int(math.ceil(198*r['fraction']));require(n==r['test_n'],'Twin-rate denominator')
        close((66/198)*(198-n)/197,r['expected_test_twin_rate'],'Analytic twin rate')
        rates=[]
        for seed in range(10000):
            order=np.random.RandomState(seed).permutation(198);te=order[:n];tr=order[n:];train_hash={full[i] for i in tr}
            rates.append(np.mean([full[i] in train_hash for i in te]))
        close(np.mean(rates),r['simulation_mean'],'Split-only simulation mean');close(np.std(rates),r['simulation_sd'],'Split-only simulation SD')
        for v,w in zip(np.quantile(rates,[.025,.975]),r['split_variability_2.5_97.5']):close(v,w,'Split-only simulation percentile')
    registry=json.loads((exp/'PUBLICATION_REGISTRY.json').read_text());records=registry['records'];summary=registry['summary'];ids={r['id'] for r in records}
    require(len(records)==len(ids)==30,'Registry rows');require(all(e['a'] in ids and e['b'] in ids and e['evidence'] for e in registry['edges']),'Registry edges')
    require((summary['distinct_full_compilation_lower_bound'],summary['distinct_full_compilation_upper_bound'])==(6,7),'Bounded compilation count')
    require(all(r['anchor_relationship']!='independent' for r in records if r['evidence_grade']=='different_full_compilation'),'Different N not physical independence')
    result={'status':'PASS','no_refit':True,'historical_source_files_checked':len(source),'release_payload_hashes_checked':verified_files,'original_split_count':500,'amendment_split_count':100,'prediction_groups_checked':checked,'prediction_rows_checked':len(pred)+len(extra),'fixed_strata_rows_checked':800,'fixed_strata_summary_cells_checked':summary_count,'split_only_twin_simulations_checked':20000,'all_50_seeds_retained':True,'scalar_checks':scalars,'max_absolute_numeric_error':max_error,'absolute_numeric_tolerance':1e-12,'max_fixed_strata_summary_error':summary_max_error,'exact_duplicate_groups':33,'registry_records':30,'source_workbooks_bound':args.bind_workbooks,'true_seven_input_disjointness_recomputed':seven is not None,'numeric_source_cells_compared':2376 if seven else 0,'limitations':['No model fitting or population validation.','Without --bind-workbooks labels/keys are internally consistent but not independently bound to provider bytes.','Distinct-compilation bounds are not counts of independent physical experiments.'],'runtime':{'python':sys.version.split()[0],'numpy':np.__version__,'pandas':pd.__version__}}
    print(json.dumps(result,indent=2,allow_nan=False))

if __name__=='__main__':main()
