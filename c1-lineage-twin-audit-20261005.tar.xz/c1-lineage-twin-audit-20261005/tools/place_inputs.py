#!/usr/bin/env python3
"""Path-only adapter: hash-check user-supplied or explicitly fetched lawful inputs.

No upload, fitting, workbook transformation, or overwrite. Workbooks are absent
from this release. Run only in an extracted local copy, never in the sealed bundle.
"""
from pathlib import Path
import argparse, hashlib, json, urllib.request

RELEASE = Path(__file__).resolve().parents[1]
EXP = Path('pub_portfolio_20260916/_shared/revision_20260921/C1/experiments/lineage_20261005')
SPECS = {
    'provider': {
        'sha256': 'f9e9e195e680d39ea89ebcaf9c50dbf90118c47dc63afcb675f22f7feb9b406b',
        'url': 'https://data.mendeley.com/public-files/datasets/2myr3k8n4g/files/3bdf2537-862a-46b0-9b57-367921bd1568/file_downloaded',
        'doi': '10.17632/2myr3k8n4g.1',
        'targets': ['pub_portfolio_20260916/C1_crossdb_audit/probe/data/scirep_MOESM1.xlsx',
                    'pub_portfolio_20260916/_shared/revision_20260921/C1/public_source_recovery_20261002/1-s2.0-S2214509525003870-mmc1.xlsx'],
    },
    'chu': {
        'sha256': 'd1293c14ead7c9982193dd99dcd7abd7853688999cc99e77c63d862edf07058e',
        'url': 'https://ars.els-cdn.com/content/image/1-s2.0-S2214509525003870-mmc1.xlsx',
        'doi': '10.1016/j.cscm.2025.e04589',
        'targets': [str(EXP / 'sources/Chu2025_official_mmc1.xlsx')],
    },
}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=RELEASE)
    for label in SPECS:
        ap.add_argument('--'+label+'-local',type=Path)
        ap.add_argument('--download-'+label,action='store_true')
    args=ap.parse_args();root=args.root.resolve();result=[]
    assert (root/'provenance/SOURCE_BYTE_MANIFEST.json').is_file(), 'Not a release root'
    for label,spec in SPECS.items():
        local=getattr(args,label+'_local');download=getattr(args,'download_'+label)
        if local and download:ap.error('Select local input or download, not both')
        if local:data=local.read_bytes()
        elif download:
            req=urllib.request.Request(spec['url'],headers={'User-Agent':'c1-lineage-portable-inputs/1.0'})
            with urllib.request.urlopen(req,timeout=45) as response:data=response.read(2_000_001)
            assert len(data)<=2_000_000,'Unexpected download size'
        else:
            targets=[root/p for p in spec['targets']]
            if all(p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==spec['sha256'] for p in targets):
                result.append({'input':label,'status':'existing_verified'});continue
            result.append({'input':label,'status':'absent_not_fetched'});continue
        assert hashlib.sha256(data).hexdigest()==spec['sha256'],label+' hash mismatch; nothing installed'
        # Preflight every destination before any write for this input.
        for rel in spec['targets']:
            p=root/rel
            if p.exists():assert p.is_file() and p.read_bytes()==data,'Existing input differs; refusing overwrite'
        for rel in spec['targets']:
            p=root/rel
            if not p.exists():
                p.parent.mkdir(parents=True,exist_ok=True)
                with p.open('xb') as f:f.write(data)
        result.append({'input':label,'status':'installed_verified','sha256':spec['sha256'],'targets':spec['targets']})
    print(json.dumps({'status':'completed','inputs':result,'no_model_fit':True,'no_upload':True},indent=2))

if __name__=='__main__':main()
