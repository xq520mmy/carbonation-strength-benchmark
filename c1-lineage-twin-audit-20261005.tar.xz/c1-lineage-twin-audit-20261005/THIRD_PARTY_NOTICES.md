# Third party notices

## Anchor data

Provider: wani, suhaib (2026), Compressive Strength of CO2-Cured Concrete, Mendeley Data, V1, DOI [10.17632/2myr3k8n4g.1](https://doi.org/10.17632/2myr3k8n4g.1), CC BY 4.0 as recorded by the retained public fetch helper. Official file URL: https://data.mendeley.com/public-files/datasets/2myr3k8n4g/files/3bdf2537-862a-46b0-9b57-367921bd1568/file_downloaded . Expected SHA-256: `f9e9e195e680d39ea89ebcaf9c50dbf90118c47dc63afcb675f22f7feb9b406b`.

The workbook itself is excluded. Saved predictions retain source strength labels; duplicate-row CSV retains 66 selected source rows; canonical row hashes, split definitions and analysis outputs are derived from this data. These derived values are not new measurements. Attribution and the [CC BY 4.0 terms](https://creativecommons.org/licenses/by/4.0/) remain applicable to provider material. Models and calculations are our analyses; do not imply provider endorsement.

## Chu official source table

Article: Chu et al., Explainable machine learning model for predicting compressive strength of CO2-cured concrete, DOI [10.1016/j.cscm.2025.e04589](https://doi.org/10.1016/j.cscm.2025.e04589). Official publisher supplementary file: https://ars.els-cdn.com/content/image/1-s2.0-S2214509525003870-mmc1.xlsx . Expected SHA-256: `d1293c14ead7c9982193dd99dcd7abd7853688999cc99e77c63d862edf07058e`.

This workbook is not redistributed and no license for it is inferred from the Mendeley deposit. Obtain it lawfully from the publisher under applicable terms. The independent identity check removes a serial-number column and maps three header labels only; all 2,376 numeric cells must remain exactly identical to the anchor. Numeric identity does not establish physical specimen identity, direction of reuse or misconduct.

## Literature and code

Publisher PDFs, HTML, screenshots, abstracts/full-text quotations, restricted downloads and private communications are excluded. Registry entries contain citations, factual classifications, access limitations and our paraphrases. Absence of accessible rows is not evidence of independence.

Third-party software is referenced in requirements, not vendored. Original project source and analysis-output licensing must be confirmed by the responsible author before public distribution. This staging task does not grant a new software license or change rights in earlier releases.
