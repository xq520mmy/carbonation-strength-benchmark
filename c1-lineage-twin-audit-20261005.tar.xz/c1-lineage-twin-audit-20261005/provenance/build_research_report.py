"""Write evidence-derived tables and a reviewable manuscript branch; keep v12 unchanged."""
from pathlib import Path
import hashlib,json
import pandas as pd
HERE=Path(__file__).resolve().parent

def main():
    a=pd.read_csv(HERE/'aggregate_metrics.csv')
    paired=pd.read_csv(HERE/'paired_twin_intervention.csv')
    registry=json.loads((HERE/'PUBLICATION_REGISTRY.json').read_text())
    strata=json.loads((HERE/'FIXED_TEST_STRATA_QA.json').read_text())
    root_strata=json.loads((HERE/'ROOT_FIXED_TEST_STRATA_QA.json').read_text())
    assert strata['status']=='PASS' and root_strata['status']=='PASS'
    assert strata['output_csv_sha256']==root_strata['input_csv_sha256']==hashlib.sha256((HERE/'fixed_test_strata_metrics.csv').read_bytes()).hexdigest()
    stables=['| Test fraction | Features | Model | Twin ΔRMSE ± split SD (MPa) | Non-twin ΔRMSE ± split SD (MPa) | Non-twin RMSE improvement splits |',
             '|---|---|---|---:|---:|---:|']
    for f in [.2,.3]:
        for schema in ['stored11','Chu7']:
            for model in ['RF300','ET300']:
                cells={x['stratum']:x for x in strata['summary'] if (x['fraction'],x['schema'],x['model'])==(f,schema,model)}
                assert set(cells)=={'twin','non_twin'} and all(x['n_splits']==50 for x in cells.values())
                twin=cells['twin']['delta_rmse'];non=cells['non_twin']['delta_rmse']
                stables.append(f"| {f:.0%} | {schema} | {model} | {twin['mean']:+.3f} ± {twin['split_sd']:.3f} | {non['mean']:+.3f} ± {non['split_sd']:.3f} | {cells['non_twin']['purge_improved_rmse_n']}/50 |")
    primary=a[(a.schema=='stored11')&a.arm.isin(['row_random','full_row_group','input_vector_group'])]
    table=['| Test fraction | Model | Split unit | Mean R² ± split SD | Seeds R² ≥ 0.95 | Mean Train / Test N |',
           '|---|---|---|---:|---:|---:|']
    labels={'row_random':'row','full_row_group':'full (X,y) row','input_vector_group':'11-input vector'}
    for r in primary.itertuples():
        table.append(f'| {r.fraction:.0%} | {r.model} | {labels[r.arm]} | {r.r2_mean:.4f} ± {r.r2_sd:.4f} | {r.r2_ge_095_n}/50 | {r.train_n_mean:.2f} / {r.test_n_mean:.2f} |')
    ptable=['| Test fraction | Features | Model | ΔR² mean ± split SD | ΔRMSE mean (MPa) | R² loss seeds |',
            '|---|---|---|---:|---:|---:|']
    means=[]
    for (f,s,m),d in paired.groupby(['fraction','schema','model']):
        v=d.r2_twin_removal_minus_size_control;rm=d.rmse_twin_removal_minus_size_control
        means.append(dict(fraction=f,schema=s,model=m,delta_r2_mean=float(v.mean()),delta_r2_sd=float(v.std()),
                          delta_rmse_mean=float(rm.mean()),loss_seeds=int((v<0).sum()),n_seeds=len(v),
                          delta_r2_split_p025=float(v.quantile(.025)),delta_r2_split_p975=float(v.quantile(.975))))
        ptable.append(f'| {f:.0%} | {s} | {m} | {v.mean():+.4f} ± {v.std():.4f} | {rm.mean():+.3f} | {(v<0).sum()}/50 |')
    pd.DataFrame(means).to_csv(HERE/'paired_summary.csv',index=False)
    xtable=['| Test fraction | Model | True seven-input groups | R² ≥ 0.95 seeds |','|---|---|---:|---:|']
    for (f,m),d in pd.read_csv(HERE/'chu7_group_metrics.csv').groupby(['fraction','model']):
        xtable.append(f'| {f:.0%} | {m} | {d.r2.mean():.4f} ± {d.r2.std():.4f} | {(d.r2>=.95).sum()}/50 |')
    section=r'''### Bounded publication lineage

The search was bounded by first public appearance from 1 January 2025 to 5 October 2026. It extends the retained 43-query inventory by publisher checks and citation chasing. It identifies eight strength-prediction compilations, two further full research papers with own experimental components, one potentially eligible biochar/SVR paper requiring target verification, one extended abstract, and one thesis. This is an identified-literature frame rather than a proved census of the entire subfield. The registry retains unresolved eligibility, unavailable raw data, and duplicate publication versions.

The official Chu supplement and the public table accompanying Alsharedah and Wani agree in all 2,376 numeric cells, including compressive strength, after removal of the former's serial column and translation of three column headers. Their source bytes differ, but their numeric rows and order are identical. Wang's 198-row table is a probable match based on its extensive printed signature; no raw table was obtained. The printed cement SD of 171.18 is retained as an exception, not repaired until it matches. Numeric identity does not establish the direction of copying or identical physical specimens.

Across the eight identified compilations, the reported N values are 198, 280, 293, 333, 399 and 423. Merging only the row-confirmed Chu/Alsharedah–Wani pair bounds the number of distinct complete compilations by six to seven, depending on the unresolved Wang relationship. The 293-row Xu paper covers broader post-carbonation processes; withholding it from a curing-only frame gives seven works and five to six compilations. These are complete-table counts, not independent experimental origins or mutually disjoint datasets. Hilaloglu explicitly includes Chu among its declared data sources, and Cho–Kim shares named experimental sources with Chu, but neither observation quantifies row overlap. Talip's methods describe newly tested mortar as the ML data origin, countering any universal claim that all relevant work reuses a few literature tables. Exact K independent physical experiments remains unidentified.

### Full-row identity and exact-twin exposure

The 198×12 numeric table contains 165 unique complete rows. Thirty-three duplicate groups each have exactly two members: 66 participating rows, 33 redundant records, and 33 unordered equal-row pairs. The stored eleven-input schema has 84 distinct inputs; the seven inputs used in Chu's modelling have 83. Full-row equality here means every stored input plus strength agrees exactly at the released precision. It does not prove that two rows represent one physical specimen, and missing experimental provenance remains unresolved.

For a uniformly drawn fixed Test of size n, the expected fraction of all Test rows whose complete twin is in Train is (66/198)×(198−n)/197. Thus fixed 40-row and 60-row Tests give 26.734% and 23.350%, respectively. A 10,000-split simulation checks the expression. In the 50 scored splits the means are 26.300% and 23.667%. The denominator is all Test rows; this rate is different from the conditional rate among duplicate-bearing Test rows and from an input-only match rate.

### Prespecified split matrix and matched-size intervention

RF and ExtraTrees each use 300 trees and scikit-learn defaults apart from seed and single-thread fitting. All 198 records are retained. The primary schema is the eleven stored inputs, with Chu's seven inputs a declared sensitivity. Test fractions 0.20 and 0.30 and seeds 0–49 are frozen. Five arms comprise row-random, complete-row-disjoint groups, stored-input-vector-disjoint groups, fixed-Test exact-twin removal, and fixed-Test equal-size removal of non-twin training rows. There is no hyperparameter or seed selection. Group fractions apply to groups; achieved Train/Test row counts vary. These fits do not claim to reproduce each published model's optimized configuration.

In the intervention, each row-random Test is held constant. The first reduced Train removes all complete twins of Test records. The second removes the same number of randomly chosen non-twin Train rows using a fixed secondary RNG. Train N and Test identities are therefore matched. Remaining source and composition similarities are not removed. The paired contrast measures sensitivity to removal of known twins at a fixed training size; it is not the fraction of all split inflation caused by duplication, and it is not a guarantee for a new campaign. All predictions, split indices and code/data hashes are retained.

### Scores and counterexamples

With eleven stored inputs, mean row-random R² is 0.9512–0.9525 across the two models and Test fractions. Full-row grouping lowers the mean to 0.9363–0.9454, while eleven-input grouping gives 0.7108–0.7743. These are different Test cohorts, so the complete gaps cannot be assigned to exact twins. High scores remain possible without complete twins: 26/50 RF and 29/50 ExtraTrees full-row-group splits at nominal 20% Test exceed 0.95. For seven inputs, even the full-row-group RF mean is 0.9509. Consequently, the claim that R²≥0.95 is reproducible only under row-random splits is rejected by this matrix.

TABLE_SPLIT

At matched Train N and fixed Test, exact-twin removal versus non-twin removal lowers mean R² by 0.0264–0.0406 and raises mean RMSE by 0.889–1.365 MPa across both feature schemas, models and fractions. Individual split effects include zero/positive R² differences; all are retained. This supports a measurable contribution of exact twins to within-table evaluation under these specified learners. It does not establish population prevalence or invalidate all high-performing models in the subfield.

TABLE_PAIRED

Test strata were defined from the original row-random Train/Test partition and held fixed under both removals. On Test rows with a complete twin in the original Train, twin removal increased mean RMSE by 3.142–5.202 MPa relative to equal-size non-twin removal across the eight configurations. On the remaining Test rows, the mean increase was 0.146–0.502 MPa; 13–26 of 50 splits per configuration instead improved. Mean twin-stratum Test N was 10.52 at 20% Test and 14.20 at 30%; each stratum's membership was identical under both removals. Thus the larger deterioration is concentrated in previously twin-exposed Test rows, while effects elsewhere are smaller and heterogeneous. Subgroup R² uses its own target variance, and subgroup R²/RMSE changes are not additive components of the overall score.

TABLE_STRATA

This fixed-stratum output completes a prespecified reporting item after overall outcomes were available. It was calculated solely from saved predictions, with no new fit, tuning or selected split. All 800 per-seed stratum rows, MAE/R² details and reverse effects are retained and independently rescored. The original runner's arm-specific exposure flags are not used to redefine the Test strata after purging.

The original input-group arm uses stored eleven-input keys for both feature schemas. It must not be called seven-input-disjoint when evaluated with seven features. An explicit, separately frozen amendment evaluates groups defined by the actual seven model inputs (83 groups). Its 200 additional fits retain the same fractions, seeds and tree parameters; no seven-input train–test matches remain. Means and the continued high-score counterexamples are:

TABLE_SEVEN

All 2,200 fitted prediction groups were independently rescored from saved predictions, and frozen split membership, equal-size controls, removed-twin identities, source byte hashes, and amendment hashes were verified. Means, SDs and split percentiles describe split sensitivity of this fixed table; repeated splits are not 50 new independent datasets and are not used as a population confidence interval. The older source-held-out experiment uses a partially traced 143-row assessment cohort and different unit assumptions, and remains a separate analysis. The 41-row mixed-age external stress test also remains separate and is not independent 28-day physical validation.
'''.replace('TABLE_SPLIT','\n'.join(table)).replace('TABLE_PAIRED','\n'.join(ptable)).replace('TABLE_STRATA','\n'.join(stables)).replace('TABLE_SEVEN','\n'.join(xtable))
    (HERE/'VERIFIED_RESEARCH_RESULTS.md').write_text('# C1: bounded lineage and matched exact-twin interventions\n\n'+section+
       '\n\nFigures: `figures/graded_lineage.svg`, `figures/matched_twin_intervention.svg`, `figures/split_sensitivity.svg`. Full per-publication primary references and access status: `LINEAGE_REGISTRY.md` and `PUBLICATION_REGISTRY.json`.\n')
    source=HERE.parents[1]/'manuscript_dce/C1_DCE_retarget_draft.md'
    text=source.read_text()
    text=text.replace('and report R² between 0.92 and 0.96 under their respective row-wise evaluation protocols;',
                      'and report high held-out scores under their respective row-wise evaluation protocols (Chu RF R²=0.9709, Alsharedah–Wani RF R²=0.955, and Wang TabPFN R²=0.959);')
    text=text.replace('Our distinct object is a carbonation-curing 198-row table reused across three publications: we document the evidence of reuse, recover source labels and pressure evidence, and score frozen models on explicitly pressure-audited external records.',
                      'Our distinct object is a 198-row carbonation-curing compilation confirmed numerically identical in two public tables and probably reused in a third study: we grade that evidence, recover source labels and pressure information, and score frozen models on explicitly pressure-audited external records.')
    text=text.replace('# A provenance-aware case study of transferability limits in carbonation-cured concrete strength models',
        '# Data lineage and exact-row shortcuts in a reused carbonation-cured concrete strength benchmark',1)
    abstract='Literature-derived strength models require evidence that high scores extend beyond reused records. We combine a bounded publication-lineage audit with controlled interventions on a 198-row carbonation-cured concrete benchmark. Two official/public tables agree in all 2,376 numeric cells; a third is a probable printed-statistic match. The broader identified literature contains multiple nonidentical compilations and own experimental work, so universal reuse or an exact count of independent experiments is not established. The benchmark contains 33 size-two exact-row groups. Expected Test exposure to a complete Train twin is 26.7% at an 80/20 split and 23.4% at 70/30. Across 50 fixed seeds, two 300-tree learners and two feature schemas, removing known Train twins while holding Test and training size constant against non-twin removal reduces mean R² by 0.026–0.041 and increases RMSE by 0.89–1.37 MPa. High R² remains possible in duplicate-disjoint splits; exact twins therefore explain a measurable component rather than all evaluation optimism. Separate provenance-held-out analysis gives pooled ExtraTrees R²=0.825, falling to 0.347 under conservative source attribution. A frozen 41-row mixed-age external stress test yields R²=−0.082 and does not constitute independent 28-day physical validation. The contribution is an evidence-graded lineage registry, a reproducible matched-size intervention, and explicit limits on the engineering transfer claims supported by this resource.'
    start=text.index('## Abstract\n')+len('## Abstract\n');end=text.index('\n## Impact statement',start)
    text=text[:start]+'\n'+abstract+'\n'+text[end:]
    text=text.replace('The three-way comparison is based on published summary statistics rather than independent row-by-row comparison of three recovered model-input matrices.',
                      'The original three-way comparison used printed statistics; the incremental official-table audit below establishes exact numeric identity for the Chu and Alsharedah–Wani tables, while Wang remains a probable match.')
    text=text.replace('the three-way comparison is based on published summary statistics rather than independent row-by-row comparison of three recovered model-input matrices.',
                      'the original three-way comparison used printed statistics. The incremental official-table audit below establishes exact numeric identity for the Chu and Alsharedah–Wani tables, while Wang remains a probable match.')
    text=text.replace('This data-independent factor explains the apparent standard-deviation discrepancies;',
                      'This data-independent factor explains many of the standard-deviation differences, with the printed Wang cement exception retained;')
    text=text.replace('This is treated as a transposition in the printed table rather than as falsification.',
                      'A digit transposition is one plausible explanation, but is unverified; the printed value is retained as an unresolved exception.')
    insert='## 6A. Incremental lineage and exact-twin audit\n\n'+section+'\n\n'
    text=text.replace('## 7. Engineering decision implications and evidence limits',insert+'## 7. Engineering decision implications and evidence limits',1)
    text=text.replace('## 8. Conclusions for engineering use\n',
        '## 8. Conclusions for engineering use\n\nThe incremental audit confirms a complete numeric-table match for two publications and a probable third match, while retaining other compilations and own experimental work in the bounded literature frame. In the anchor, 33 complete twin pairs contribute measurable evaluation sensitivity: matched-size removal lowers mean R² by 0.026–0.041. Counterexamples disprove the stronger claim that R²≥0.95 requires row-random splitting. This contrast concerns one reused table and specified learners; it does not identify independent experimental origins across the entire subfield.\n',1)
    # New claims are a working branch. References for newly discussed publications are explicit,
    # rather than pretending these were in the original bibliography.
    refs=['### Incremental audit references','']
    for r in registry['records']:
        if r['scope'].startswith('main') or r['scope'] in ['eligibility_pending_fulltext','extended_abstract_sensitivity','thesis_sensitivity']:
            refs.append(f"{r['id']}. {r['title']}. [{r['doi']}]({r['primary_url']}).")
    text=text.replace('## Figure captions','\n'.join(refs)+'\n\n## Figure captions',1)
    # Rebase all five inherited figures to their real location from this nested branch.
    text=text.replace('(../figures/','(../../../figures/')
    availability_note='Working-branch availability note (remove only after a verified release update): the new bounded lineage registry, exact-row audit, matched-size twin interventions, and seven-input grouping amendment are currently local research artifacts under `C1/experiments/lineage_20261005`. They are not included in public release v1.2.0. The release claim below applies to the earlier studies only; a final submission must provide a verified deposit for these new additions.\n\n'
    assert '## Data Availability Statement\n\n' in text
    text=text.replace('## Data Availability Statement\n\n','## Data Availability Statement\n\n'+availability_note,1)
    text += '\n\n![Evidence-graded links distinguish exact numeric identity, probable printed signatures and declared source overlap; disconnected nodes have unresolved row relationships.](../figures/graded_lineage.png){width=155mm}\n\n**Figure 6.** Bounded lineage links. Exact equality is established for Chu and Alsharedah–Wani; Wang is a probable printed match. Dotted source relationships do not assert row identity. Own experiments and unresolved records remain in the registry.\n\n![For each learner, feature schema and Test fraction, all fifty paired R² differences after removal of complete twins versus equal-size non-twin removal are displayed; red diamonds denote means.](../figures/matched_twin_intervention.png){width=155mm}\n\n**Figure 7.** Fixed-Test, matched-size exact-twin intervention. Each dot is one prespecified split and each diamond a mean. Positive individual differences are retained. Repeated-split variability is not a new-population confidence interval.\n\n![Mean R² and split percentiles for row, full-row-group and eleven-input-group evaluation show both deterioration and high-score counterexamples.](../figures/split_sensitivity.png){width=155mm}\n\n**Figure 8.** Stored eleven-input split sensitivity, with 2.5th–97.5th split percentiles. Grouped row counts and Test cohorts differ. These gaps cannot all be attributed to exact twins.\n'
    branch=HERE/'manuscript_working';branch.mkdir(exist_ok=True)
    out=branch/'C1_lineage_incremental_working_draft.md';out.write_text(text)
    seal=dict(status='VERIFIED_INCREMENTAL_RESEARCH_WORKING_BRANCH_NOT_SUBMISSION_READY',source_manuscript_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
              output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),abstract_words=len(abstract.split()),
              publication_claim_limits='Not a census; raw-row overlap mostly unknown; physical-origin K unidentified',
              new_research_public_deposit_status='Local only; not part of v1.2.0',
              remaining='Full editorial consolidation, target venue choice, DOCX figure/table integration and visual QA, author-confirmed declarations, new B2/D1 evidence')
    (branch/'WORKING_BRANCH_STATUS.json').write_text(json.dumps(seal,indent=2));print(json.dumps(seal))

if __name__=='__main__':main()
